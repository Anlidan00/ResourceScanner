"""Bounded item-knowledge reader."""
import struct
MAX_CAPACITY = 1 << 18
ITEM_TRIGGER_MASK = 7

class Unavailable(ValueError):
    pass

def exact(read, address, size):
    if not 65536 <= address < 140737488289792 or not 0 <= size <= 4 * 1024 * 1024:
        raise Unavailable('Read address/size outside bounded contract')
    data = read(address, size)
    if len(data) != size:
        raise Unavailable('Short read')
    return bytes(data)

def u64(read, address):
    return struct.unpack('<Q', exact(read, address, 8))[0]

def ptr(read, address):
    value = u64(read, address)
    if not 65536 <= value < 140737488289792:
        raise Unavailable('Unavailable pointer')
    return value

def context(read, base, application, current_world_token, controller_vtable_rva):
    """Token must come from caller's validated active-world/map UI scope.

    It is NOT the saved FOW-ready bit. Calling only with an opaque stable token
    does not establish world readiness; caller must prove its own producer.
    """
    if current_world_token is None:
        raise Unavailable('No current loaded-world scope')
    controller = ptr(read, application + 217728)
    if u64(read, controller) != base + controller_vtable_rva:
        raise Unavailable('Not the client-controller type')
    if ptr(read, controller + 40) != application:
        raise Unavailable('Controller owner changed')
    client = ptr(read, controller + 440)
    outer = ptr(read, client + 4707664)
    state = ptr(read, outer + 8)
    manager = ptr(read, application + 1680)
    if ptr(read, client + 136) != manager:
        raise Unavailable('Client and addressed hero manager differ')
    selected = exact(read, manager + 1151678, 3)
    loaded = exact(read, manager + 1105710, 3)
    if selected[2] != 1 or not 1 <= selected[0] <= 16 or selected[1] not in (0, 1) or (loaded[:2] != selected[:2]) or (loaded[2] not in (2, 3)):
        raise Unavailable('Addressed hero not loaded')
    if exact(read, manager + 1128672, 1) != b'\x01':
        raise Unavailable('Current personal knowledge has not been seeded')
    header = exact(read, state, 216)
    if header[210] != 1:
        raise Unavailable('Not single-personal-map client mode')
    if struct.unpack_from('<Q', header, 160)[0] != 1:
        raise Unavailable('Unexpected personal map count')
    personal = struct.unpack_from('<Q', header, 152)[0]
    if not 65536 <= personal < 140737488289792:
        raise Unavailable('No client personal map')
    ph = exact(read, personal, 144)
    if ph[138] != 1:
        raise Unavailable('Personal map not active')
    if struct.unpack_from('<H', header, 192)[0] == 0:
        raise Unavailable('No initialized world-knowledge revision')
    token = (current_world_token, application, controller, client, outer, state, manager, selected, loaded, personal)
    revisions = (struct.unpack_from('<I', header, 144)[0], struct.unpack_from('<H', header, 192)[0], struct.unpack_from('<I', ph, 128)[0], struct.unpack_from('<H', ph, 136)[0])
    return (token, revisions, state + 16, personal)
MAX_TURN_READ_BYTES = 32 * 1024 * 1024

def verify_critical(read, base, image):
    if image is None:raise Unavailable('Module layout unavailable')
    return _ProjectionReference(image.controller(read,base))

class _ProjectionReference:
    MAX_CAPACITY = MAX_CAPACITY
    Unavailable = Unavailable
    exact = staticmethod(exact)
    def __init__(self,vtable_rva):self.vtable_rva=vtable_rva
    def context(self,read,base,application,current_world_token):
        return context(read,base,application,current_world_token,self.vtable_rva)

def project_map(read, address, item_ids, reference):
    exact = reference.exact
    bad = reference.Unavailable
    head = exact(read, address, 88)
    bits, capacity = struct.unpack_from('<QQ', head, 8)
    keys = struct.unpack_from('<Q', head, 40)[0]
    values = struct.unpack_from('<Q', head, 64)[0]
    used = struct.unpack_from('<I', head, 84)[0]
    if capacity > reference.MAX_CAPACITY or (capacity and capacity & capacity - 1):
        raise bad('Unsupported hash capacity')
    if used > capacity or (capacity and used == capacity) or (not capacity and used):
        raise bad('Invalid/full hash table')
    structural = (address, bits, capacity, keys, values, used)

    def finish(occupancy, occupied, flags):
        after = exact(read, address, 88)
        b, c = struct.unpack_from('<QQ', after, 8)
        k = struct.unpack_from('<Q', after, 40)[0]
        v = struct.unpack_from('<Q', after, 64)[0]
        count = struct.unpack_from('<I', after, 84)[0]
        if structural != (address, b, c, k, v, count):
            raise bad('Map structure changed during projection')
        return (structural, occupancy, occupied, flags)
    if not used:
        return finish(b'', (), tuple(((iid, 0) for iid in item_ids)))
    bit_data = exact(read, bits, (capacity + 63) // 64 * 8)
    key_data = exact(read, keys, capacity * 4)
    occupied = []
    seen = set()
    targets = set(item_ids)
    found = {}
    for index in range(capacity):
        if not bit_data[index >> 3] & 1 << (index & 7):
            continue
        key = struct.unpack_from('<I', key_data, index * 4)[0]
        if key in seen:
            raise bad('Duplicate occupied key')
        seen.add(key)
        occupied.append((index, key))
        if key in targets:
            found[key] = struct.unpack('<I', exact(read, values + index * 8, 4))[0]
    if len(occupied) != used:
        raise bad('Occupied-bit/count mismatch')
    return finish(bit_data, tuple(occupied), tuple(((iid, found.get(iid, 0)) for iid in item_ids)))

def capture_projected(read, base, application, world_token, item_ids, reference):
    """Verify owners, occupied keys and target flags across two reads."""
    item_ids = tuple(item_ids)
    if len(item_ids) != len(set(item_ids)) or any((type(i) is not int or not 0 <= i <= 4294967295 for i in item_ids)):
        raise reference.Unavailable('Invalid target IDs')
    a = reference.context(read, base, application, world_token)
    first = (project_map(read, a[2], item_ids, reference), project_map(read, a[3], item_ids, reference))
    b = reference.context(read, base, application, world_token)
    if a[0] != b[0] or a[2:] != b[2:]:
        raise reference.Unavailable('World/hero owner changed')
    second = (project_map(read, a[2], item_ids, reference), project_map(read, a[3], item_ids, reference))
    c = reference.context(read, base, application, world_token)
    if a[0] != c[0] or a[2:] != c[2:]:
        raise reference.Unavailable('World/hero owner changed')
    if first != second:
        raise reference.Unavailable('Target knowledge or map structure changed')
    world = dict(first[0][3])
    personal = dict(first[1][3])
    flags = {iid: (world[iid], personal[iid]) for iid in item_ids}
    return dict(context_token=a[0], revisions=c[1], revision_diagnostics=(a[1], b[1], c[1]), known_item_ids=sorted((iid for iid, (w, p) in flags.items() if (w | p) & 7)), raw_flags=flags, snapshot_kind='structural_and_target_projection_double_read_two_poll_required_not_atomic')
