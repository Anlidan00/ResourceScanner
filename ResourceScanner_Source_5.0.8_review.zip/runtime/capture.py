"""Game state acquisition scoped to the current map frame."""
import struct
import game_sources
import knowledge_sources as knowledge
from process_memory import ReadOnlyGameBase
from fog_save import read_mask

class GameMemory(ReadOnlyGameBase):
    def __init__(self,pid,birth):
        super().__init__(pid)
        try:
            low,high=game_sources.process_creation_time(self)
            self.birth=low|(high<<32);self.bound_ui=None
            if self.birth!=birth:raise ValueError('Parent creation identity differs')
        except Exception:self.close();raise
    def bind(self,frame):
        frame.world_scope()
        if (frame.process_id,frame.birth)!=(self.pid,self.birth):raise ValueError('Frame and game differ')
        app,ui=frame.application,frame.ui
        if (game_sources.pointer(self.read,app+0x5b0)!=ui or
                game_sources.pointer(self.read,ui)!=app+0x468 or
                game_sources.pointer(self.read,ui+0x68)!=ui):raise ValueError('Game UI owner changed')
        self.application,self.bound_ui=app,ui
        return self.hero()
    def hero(self):
        if self.application is None or self.bound_ui is None:raise ValueError('No current bound game owner')
        app,ui=self.application,self.bound_ui
        if (game_sources.pointer(self.read,app+0x5b0)!=ui or
                game_sources.pointer(self.read,ui)!=app+0x468 or
                game_sources.pointer(self.read,ui+0x68)!=ui):raise ValueError('Bound game UI changed')
        return game_sources.selected_hero(self.read,game_sources.pointer(self.read,app+0x690))

class FogCapture:
    def __init__(self):self.key=None;self.bits=None;self.metadata=None
    def clear(self):self.key=self.bits=self.metadata=None
    def update(self,game,hero,stores):
        path=game_sources.character_for(hero,stores);stat=path.stat();key=(hero,str(path),stat.st_size,stat.st_mtime_ns)
        if self.key!=key:
            bits,metadata=read_mask(path)
            if game.hero()!=hero:raise ValueError('Addressed hero changed during mask read')
            self.bits,self.metadata,self.key=bits,metadata,key
        if game.hero()!=hero:raise ValueError('Addressed hero changed')
        return self.bits,self.metadata

class KnowledgeCapture:
    def __init__(self,item_ids):
        self.items=tuple(i for i in item_ids if i);self.previous=None;self.game=None;self.checked=False;self.reference=None
        if len(self.items)!=len(set(self.items)):raise ValueError('Duplicate catalog item identity')
    def clear(self):self.previous=None
    def update(self,game,frame,frame_reader,hero):
        if self.game is not game:self.game=game;self.checked=False;self.clear()
        read_bytes=0
        def bounded(address,size):
            nonlocal read_bytes
            if type(size)is not int or not 0<=size<=4*1024*1024:raise knowledge.Unavailable('Invalid knowledge read size')
            read_bytes+=size
            if read_bytes>32*1024*1024:raise knowledge.Unavailable('Knowledge capture read bound')
            return b''.join(game.read(address+i,min(4096,size-i))for i in range(0,size,4096))
        try:
            if not self.checked:self.reference=knowledge.verify_critical(bounded,game.base,getattr(game,'image',None));self.checked=True
            scope=frame.world_scope()
            if game.hero()!=hero:raise knowledge.Unavailable('FOW and knowledge address different heroes')
            result=knowledge.capture_projected(bounded,game.base,game.application,scope,self.items,self.reference)
            after=frame_reader.read()
            if after.world_scope()!=scope or game.hero()!=hero:raise knowledge.Unavailable('Source context changed during knowledge capture')
            key=(scope,hero,result['context_token'],tuple(sorted(result['raw_flags'].items())))
            ready=self.previous==key;self.previous=key
            return dict(ready=ready,addressed_hero=hero,context_token=result['context_token'],known_item_ids=result['known_item_ids']if ready else[],read_bytes=read_bytes)
        except (OSError,ValueError,struct.error):self.clear();raise

class CaptureSession:
    """Invalidate source caches on identity changes, never on update counters."""
    def __init__(self):self.number=0;self.scope=self.hero=self.context=None
    def invalidate(self):self.scope=self.hero=self.context=None
    def begin(self,scope,hero):
        changed=self.scope!=scope or self.hero!=hero
        if changed:
            self.number+=1;self.scope,self.hero,self.context=scope,hero,None
        return changed
    def knowledge_context(self,context):
        if context is None:raise ValueError('Missing proven knowledge context')
        changed=self.context is not None and self.context!=context
        self.context=context
        if changed:self.number+=1
        return changed
