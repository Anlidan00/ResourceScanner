# Resource Scanner 5.0.8

Source review package for the Windows x64 Enshrouded mod published at:

https://www.nexusmods.com/enshrouded/mods/285

- `native/`: C++20 Scanner core and its Windows/Vulkan integration.
- `loader/`: exact retained Vulkan proxy source and generated export forwarders used by the published loader.
- `runtime/`: Python helper source, compatibility profile and item IDs shipped in 5.0.8.
- `installer/`: exact published C# installer source, translations and original admission-based packaging script.
- `scripts/`: portable review builds, dependency retrieval and source verification.
- `release/`: published artifact hashes, installed-payload hashes and release-bound source hashes.

See [BUILD.md](BUILD.md) for dependencies, build commands and the relationship between the source and uploaded installer. See [SECURITY_REVIEW.md](SECURITY_REVIEW.md) for operational behavior relevant to manual review.

Game artwork, creature portraits and the packed world catalog are not hosted in this source repository. The installer review build reuses the validated payload from the existing published installer without executing it. No game installation or save files are accessed by that review build.

The development process used OpenAI Codex for code and translations. Third-party software, fonts and method-icon notices are retained in [Third_Party_Licenses.txt](Third_Party_Licenses.txt) and the accompanying license files. Upstream source archives are pinned in `dependencies.lock.json`.
