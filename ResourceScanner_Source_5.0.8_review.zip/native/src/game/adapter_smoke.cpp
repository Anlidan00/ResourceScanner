#include <rs/game/adapter.hpp>
#include <nlohmann/json.hpp>
#include <fstream>
#include <map>
#include <vector>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <limits>
namespace {
struct Memory {
    std::map<std::uintptr_t,std::vector<std::uint8_t>> blocks;
    void add(std::uintptr_t p,std::size_t n){blocks[p].resize(n);}
    template<class T>void put(std::uintptr_t p,T v){bool found=false;for(auto&[base,b]:blocks)if(p>=base&&p+sizeof(T)<=base+b.size()){std::memcpy(b.data()+p-base,&v,sizeof(v));found=true;}if(!found)std::terminate();}
    static bool copy(void* user,std::uintptr_t p,void* out,std::uint64_t n)noexcept {
        auto& blocks=static_cast<Memory*>(user)->blocks;auto* target=static_cast<std::uint8_t*>(out);
        while(n){auto it=blocks.upper_bound(p);bool found=false;
            while(it!=blocks.begin()){--it;if(p>=it->first&&p-it->first<it->second.size()){found=true;break;}}
            if(!found)return false;const auto take=std::min<std::uint64_t>(n,it->second.size()-(p-it->first));
            std::memcpy(target,it->second.data()+p-it->first,static_cast<std::size_t>(take));p+=take;target+=take;n-=take;}
        return true;
    }
};
std::uintptr_t pointer(const nlohmann::json& j){return std::stoull(j.get<std::string>(),nullptr,16);}
int real_capture(const nlohmann::json& tree){
    Memory memory;
    for(auto&[key,value]:tree.at("memory").items()){
        const auto separator=key.find(':');const auto address=std::stoull(key.substr(0,separator),nullptr,16);
        auto raw=value.get<std::string>();auto& bytes=memory.blocks[address];bytes.resize(raw.size()/2);
        for(std::size_t i=0;i<bytes.size();++i)bytes[i]=static_cast<std::uint8_t>(std::stoul(raw.substr(2*i,2),nullptr,16));}
    const auto state=tree["requested"]["state"].get<std::uintptr_t>(),builder=tree["requested"]["backend"].get<std::uintptr_t>(),ui_frame=tree["requested"]["ui_context_frame"].get<std::uintptr_t>();
    const auto root=tree["scalar"]["commit_root"].get<std::uintptr_t>(),viewport=tree["scalar"]["viewport"].get<std::uintptr_t>(),arena=tree["arena_owner"].get<std::uintptr_t>();
    rs::game::MemoryReader reader{&memory,Memory::copy};unsigned checks{};
    auto capture=[&](){return rs::game::capture_from_commit(reader,root,builder,state,ui_frame,10000);};
    auto frame=capture();
    if(!frame.map_open||!frame.projection_ready||!frame.hud_bounds_ready||!frame.world_ready||frame.native_language_id!=9){std::puts("actual captured map rejected");return 20;}++checks;
    if(std::abs(frame.map_content.top-124.6222229f)>.001f||std::abs(frame.map_content.bottom-1269.8666992f)>.001f)return 21;++checks;
    // Captured arena/list pointers differ, as do the initialization/current UI
    // timestamps. Their genuine bytes are retained, never normalized to fit.
    if(tree["scalar"]["state_time"]==tree["scalar"]["ui_time"]||arena==tree["scalar"]["canvas"].get<std::uintptr_t>())return 22;++checks;
    const Memory original=memory;
    memory.put(state-0x18,std::uint32_t{0x280});
    auto extended=rs::game::capture_from_commit(reader,root,builder,state,ui_frame,10000,0x280);
    if(!extended.map_open||!extended.projection_ready||capture().projection_ready)return 46;++checks;memory=original;
    memory.put(state+0x3c,std::numeric_limits<float>::infinity());
    if(capture().projection_ready)return 47;++checks;memory=original;
    if(tree["viewport_records"].size()>=10){
        auto blocked=[](const rs::game::Frame& f,float x,float y){for(std::uint32_t i=0;i<f.ui_blocker_count&&i<f.ui_blockers.size();++i){auto r=f.ui_blockers[i];if(x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom)return true;}return false;};
        if(!frame.ui_blockers_ready||frame.ui_blocker_count!=4||!blocked(frame,70,200)||!blocked(frame,2350,200)||!blocked(frame,70,1050)||!blocked(frame,1500,800)||blocked(frame,1280,500))return 40;++checks;
        for(std::uint32_t i=0;i<frame.ui_blocker_count;++i){auto r=frame.ui_blockers[i];if(!(r.right>r.left&&r.bottom>r.top&&r.left>=frame.map_content.left&&r.top>=frame.map_content.top&&r.right<=frame.map_content.right&&r.bottom<=frame.map_content.bottom))return 41;++checks;}
        auto left=std::find_if(tree["nodes"].begin(),tree["nodes"].end(),[](auto& n){return n["literal"].template get<std::uint64_t>()==0x7CDBAF8FF444C1B8ULL;});
        const auto left_view=(*left)["viewport"].get<std::uintptr_t>();memory.put(left_view+0x80,std::uint32_t{0});auto stale=capture();
        if(!stale.projection_ready||!stale.world_ready||blocked(stale,70,200)||!blocked(stale,2350,200))return 42;++checks;memory=original;
        auto right=std::find_if(tree["nodes"].begin(),tree["nodes"].end(),[](auto& n){return n["literal"].template get<std::uint64_t>()==0x9DD5F4A51595D5FEULL;});
        memory.put((*right)["address"].get<std::uintptr_t>(),std::uintptr_t{0});auto failed=capture();
        if(!failed.projection_ready||!failed.world_ready||failed.ui_blockers_ready||failed.ui_blocker_count)return 43;++checks;memory=original;
        auto title=std::find_if(tree["nodes"].begin(),tree["nodes"].end(),[](auto& n){return n["literal"].template get<std::uint64_t>()==0xDFC334B43D1B81A0ULL;});
        const auto body=(*title)["parent"].get<std::uintptr_t>();memory.put(body,std::uintptr_t{0});failed=capture();
        if(!failed.projection_ready||failed.ui_blockers_ready||failed.ui_blocker_count)return 44;++checks;memory=original;
        const auto viewport_root=std::find_if(tree["nodes"].begin(),tree["nodes"].end(),[&](auto& n){return n["address"].template get<std::uintptr_t>()==body;});
        const auto parent_address=(*viewport_root)["parent"].get<std::uintptr_t>();
        auto full=std::find_if(tree["nodes"].begin(),tree["nodes"].end(),[&](auto& n){return n["address"].template get<std::uintptr_t>()==parent_address;});
        for(unsigned i=0;i<4;++i)memory.put(body+0x114+4*i,(*full)["rect"][i].get<float>());
        failed=capture();if(!failed.projection_ready||!failed.world_ready||failed.ui_blockers_ready||failed.ui_blocker_count)return 45;++checks;memory=original;
    }
    auto rejected=[&](){++checks;return !capture().projection_ready;};
    memory.put(builder,std::uintptr_t{0});if(!rejected())return 23;memory=original;
    memory.put(builder+0x10,std::uintptr_t{0});if(!rejected())return 24;memory=original;
    memory.put(state-0x28,std::uint64_t{0});if(!rejected())return 25;memory=original;
    memory.put(state-0x18,std::uint32_t{0x261});if(!rejected())return 26;memory=original;
    memory.put(viewport+0x10,arena+8);if(!rejected())return 27;memory=original;
    memory.put(viewport+0x18,builder+8);if(!rejected())return 28;memory=original;
    memory.put(viewport+0x80,std::uint32_t{0});if(!rejected())return 29;memory=original;
    memory.put(state+0x18,std::uintptr_t{0});if(!rejected())return 30;memory=original;
    memory.put(state+0x38,0.f);if(!rejected())return 31;memory=original;
    const auto ui=ui_frame-16;std::uintptr_t view{},owner{},game_ui{};
    Memory::copy(&memory,ui_frame+0x48,&view,8);Memory::copy(&memory,view,&owner,8);Memory::copy(&memory,owner+0x38,&game_ui,8);
    for(auto screen:{0u,1u,4u,51u}){memory.put(game_ui+0x1cd8,static_cast<std::uint8_t>(screen));if(!rejected())return 32;memory=original;}
    memory.put(owner+0xc,std::uint8_t{3});if(!rejected())return 33;memory=original;
    memory.put(ui+0x68,std::uintptr_t{0});if(!rejected())return 34;
    std::printf("PASS %u actual Root-captured tree/projection/ownership/header/lifecycle checks (%zu original nodes; initialization clock deliberately stale)\n",checks,tree["nodes"].size());return 0;
}
}
rs::game::Frame saved_capture(const rs::game::MemoryReader& reader,std::uintptr_t base,std::uintptr_t state,std::uint64_t now) {
    auto get=[&](std::uintptr_t p,std::uintptr_t&v){return reader.copy&&reader.copy(reader.user,p,&v,8)&&v>=0x10000;};
    std::uintptr_t root{},frame{},builder{},commit{};
    if(!get(base+0x281E498,root)||!get(root+0x10,frame)||frame<0x10010||!get(root+0x18,builder)||!get(frame-0x10+0xE90,commit))return {};
    return rs::game::capture_from_commit(reader,commit,builder,state,frame,now);
}
int main(int argc,char** argv){
    if(argc!=2)return 2;std::ifstream in(argv[1],std::ios::binary);std::string text((std::istreambuf_iterator<char>(in)),{});
    if(text.starts_with("\xEF\xBB\xBF"))text.erase(0,3);auto tree=nlohmann::json::parse(text);Memory m;
    if(tree.contains("memory"))return real_capture(tree);
    constexpr std::uintptr_t base=0x10000000,root=0x20000000,ui=0x20100000,ui_frame=ui+0x10,frame=0x20200000,app=0x21000000,
        state=0x22000060,viewport=0x23000000,view=0x24000000,state_owner=0x25000000,ctx=view,owner=state_owner,game_ui=0x28000000,loca=0x29000000,builder=0x2A000000,commit_root=0x2B000000,viewport_list=0x2C000000;
    m.add(base+0x281E498,8);m.put(base+0x281E498,root);m.add(root,0x100);m.add(ui,0x1000);m.add(app,0x36000);
    m.add(state-0x60,0x300);m.add(viewport,0x100);m.add(view,0x32000);m.add(state_owner,0x40);
    m.add(game_ui,0x1d00);m.add(loca,0x100);m.add(builder,0x20);m.add(frame,0x100);m.add(viewport_list,0x20);
    m.put(root+0x10,ui_frame);m.put(root+0x18,builder);m.put(builder,frame);m.put(builder+0x10,viewport_list);m.put(ui+0xE90,commit_root);m.put(root+0xd0,ctx);m.put(ui,app+0x468);m.put(ui+0x68,ui);m.put(app+0x5b0,ui);
    m.put(ui_frame+0x48,view);m.put(view,state_owner);m.put(state_owner+0xc,std::uint8_t{7});m.put(ctx,owner);m.put(owner+0x38,game_ui);
    m.put(game_ui+0x1cd8,std::uint8_t{5});m.put(ctx+0x31e70,std::uint8_t{1});m.put(ui+0xf5c,std::uint32_t{9});m.put(app+0x35290,loca);m.put(loca+0xd8,std::uint32_t{9});
    const auto generation=tree["viewport_generation_u32"].get<std::uint32_t>();
    auto root_element=pointer(tree["nodes"][0]["ptr"]);std::uintptr_t map{};
    m.put(viewport_list,std::uint64_t{1000});m.put(state-0x38,std::uint64_t{1000});m.put(viewport_list+8,viewport);m.put(state,std::uint64_t{8000});m.put(ui_frame+8,std::uint64_t{9000});
    m.put(state-0x28,std::uint64_t{0x236F8649B9BF0F5BULL});m.put(state-0x18,std::uint32_t{0x260});
    m.put(state+0x38,10240.f);m.put(state+0x3c,10240.f);m.put(viewport+0x10,frame);m.put(viewport+0x18,builder);m.put(viewport+0x50,root_element);
    m.put(viewport+0x20,tree["transform"]["scale"].get<float>());m.put(viewport+0x24,0.f);m.put(viewport+0x28,0.f);m.put(viewport+0x80,generation);
    std::map<std::uintptr_t,std::vector<std::uintptr_t>> children;
    for(auto& node:tree["nodes"]){auto p=pointer(node["ptr"]);m.add(p,0x128);children[pointer(node["parent"])].push_back(p);}
    for(auto& node:tree["nodes"]){auto p=pointer(node["ptr"]);m.put(p,pointer(node["parent"]));m.put(p+8,pointer(node["previous"]));m.put(p+0x10,pointer(node["next"]));
        // Reconstruct the source-linked first/last using the captured child list.
        std::uintptr_t first{},last{};for(auto child:children[p]){
            auto it=std::find_if(tree["nodes"].begin(),tree["nodes"].end(),[&](auto& n){return pointer(n["ptr"])==child;});
            if(pointer((*it)["previous"])==0)first=child;if(pointer((*it)["next"])==0)last=child;}
        m.put(p+0x18,first);m.put(p+0x20,last);m.put(p+0x28,node["child_count"].get<std::uint64_t>());
        auto literal=pointer(node["literal_id"]);m.put(p+0x38,literal);m.put(p+0x48,frame);m.put(p+0x50,viewport);m.put(p+0x68,generation);
        for(unsigned i=0;i<4;++i)m.put(p+0x114+i*4,node["rect_logical_xywh"][i].get<float>());
        if(literal==0x6A533A7BC1DBE699ULL)map=p;
    }
    m.put(state+0x18,map);rs::game::MemoryReader reader{&m,Memory::copy};unsigned checks{};
    auto valid=saved_capture(reader,base,state,10000);
    if(!valid.projection_ready||!valid.hud_bounds_ready||!valid.map_open||valid.native_language_id!=9){std::puts("valid tree rejected");return 3;}++checks;
    if(std::abs(valid.map_content.top-124.6222229f)>.001f||std::abs(valid.map_content.bottom-1269.8666992f)>.001f)return 4;++checks;
    m.put(base+0x281E498,std::uintptr_t{0});auto committed=rs::game::capture_from_commit(reader,commit_root,builder,state,ui_frame,10000);
    if(!committed.projection_ready||committed.map_content.top!=valid.map_content.top)return 10;++checks;
    m.put(base+0x281E498,root);
    for(unsigned screen:{0u,1u,4u,51u}){m.put(game_ui+0x1cd8,static_cast<std::uint8_t>(screen));auto f=saved_capture(reader,base,state,10000);if(f.map_open||f.projection_ready)return 5;++checks;}
    m.put(game_ui+0x1cd8,std::uint8_t{5});
    for(unsigned page:{0u,2u,8u}){m.put(ctx+0x31e70,static_cast<std::uint8_t>(page));auto f=saved_capture(reader,base,state,10000);if(f.map_open)return 6;++checks;}
    m.put(ctx+0x31e70,std::uint8_t{1});m.put(state-0x38,std::uint64_t{999});if(saved_capture(reader,base,state,10000).projection_ready)return 7;++checks;
    m.put(state-0x38,std::uint64_t{1000});m.put(viewport+0x10,std::uintptr_t{0});if(saved_capture(reader,base,state,10000).projection_ready)return 8;++checks;
    m.put(viewport+0x10,frame);m.put(root+0x10,std::uintptr_t{0});if(saved_capture(reader,base,state,10000).map_open)return 9;++checks;
    std::printf("PASS %u source tree/geometry/lifecycle checks (%zu cached native layout nodes)\n",checks,tree["nodes"].size());return 0;
}
