"""Bind actual authorized read-only map evidence to the private adapter fix."""
from pathlib import Path
import hashlib,json,struct,subprocess
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final08'
def ref(path):return dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
parent=json.loads((ROOT/'build_final07/NATIVE_QA_SUMMARY.json').read_text())
old=json.loads((ROOT/'build_final07/BUILD_RECEIPT.json').read_text());new=json.loads((BUILD/'BUILD_RECEIPT.json').read_text())
changed=sorted(name for name,sha in old['source_files'].items()if new['source_files'].get(name)!=sha)
assert changed==['src/game/adapter.cpp','src/game/adapter_smoke.cpp'],changed
for item in parent['input_bindings'].values():assert ref(Path(item['path']))['sha256']==item['sha256']
capture_path=ROOT/'diagnostics/map07_51620_bulk.json';capture=json.loads(capture_path.read_text())
assert len(capture['nodes'])==257 and {n['generation']for n in capture['nodes']}=={capture['scalar']['viewport_generation']}
run=subprocess.run([str(BUILD/'rs_game_adapter_smoke.exe'),str(capture_path)],cwd=BUILD,capture_output=True,text=True,timeout=30);assert run.returncode==0,run.stdout+run.stderr
game=ROOT.parent/'terrain/private/enshrouded.exe';raw=game.read_bytes();nt=struct.unpack_from('<I',raw,60)[0];opt=nt+24;nsec=struct.unpack_from('<H',raw,nt+6)[0];optlen=struct.unpack_from('<H',raw,nt+20)[0]
def data(rva,size):
    for i in range(nsec):
        p=opt+optlen+40*i;_,va,length,off=struct.unpack_from('<IIII',raw,p+8)
        if va<=rva and rva+size<=va+length:return raw[off+rva-va:off+rva-va+size]
    raise ValueError(rva)
windows=[dict(rva=rva,bytes_hex=data(rva,size).hex(),meaning=meaning)for rva,size,meaning in [
    (0xC1EA57,0x11,'MapState initializer flag test; existing state skips initialization block and clock write.'),
    (0x119F650,5,'Initializer flag is header byte body-10, not current-frame state.'),
    (0xC1EB5D,0x16,'Body[0] receives UI timestamp INSIDE initialization-only branch.'),
    (0x119040C,0x10,'Backend+10 points viewport-list record; record+8 is viewport linked-list head.'),
    (0x11A3D1D,0x11,'UiElement record arena owner is supplied by viewport+10.'),
    (0x11A3D9B,7,'Backing-record+60 stores arena owner; returned UiElement=record+18 ->element+48.'),
    (0x118564B,0xB,'Resource-header stamp copies qword[Backend+10], a separate list record value.'),
    (0x118577B,0x29,'Resource header stores key+38, byte size+48, and allocation stamp+28; body begins+60.')]]
proof=dict(result='PASS_ACTUAL_MAP_CAPTURE_PROJECTION_ADAPTER_CORRECTION_OFFLINE',
    parent=ref(ROOT/'build_final07/NATIVE_QA_SUMMARY.json'),receipt=ref(BUILD/'BUILD_RECEIPT.json'),
    game_source=ref(game),source_windows=windows,whole_game_version_gate=False,
    actual_read_only_capture=ref(capture_path),capture_method=ref(ROOT/'src/game/diag_capture.py'),
    capture_scope=dict(pid=capture['pid'],process_birth=capture['birth'],bytes_read=capture['bytes_read'],maximum_bytes=2097152,
        process_rights='PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION',game_calls=False,process_writes=False,control=False),
    concrete_old_failures=dict(initialization_time=capture['scalar']['state_time'],current_ui_time=capture['scalar']['ui_time'],
        distinct_arena_owner=capture['arena_owner'],distinct_viewport_list=capture['scalar']['canvas']),
    corrections=['Remove false cross-clock equality; retain individual clock rereads only for in-capture coherence.',
        'Use Backend[0] as arena identity and Backend[10] separately as viewport-list owner; check both on reread.',
        'Require exact source MapState header key and size, plus prior current viewport/list membership/backlinks/generation and Play/Map/page guards.'],
    prior_semantic_withdrawal=['COMMIT_CAPTURE_SOURCE canvas_frame=Backend+10 must be understood as viewport-list record, NOT UiElement arena owner.',
        'MapState body[0] is initialization timestamp, NOT a current-frame freshness predicate.'],
    actual_capture_fixture=dict(executable=ref(BUILD/'rs_game_adapter_smoke.exe'),exit_code=run.returncode,stdout=run.stdout,
        positive_flags=15,checks=18,original_nodes=257,original_generation=capture['scalar']['viewport_generation'],
        geometry=dict(clip_top=124.62222290039062,clip_bottom=1269.86669921875),captured_bytes_normalized=False),
    changed_compiled_own_sources=changed,all_other_prior_compiled_own_sources_exact=True,
    frozen_vulkan_proxy=ref(ROOT/'build_final07/vulkan-1.dll'),only_core_replacement_required=True,
    actual_game_test_of_this_core_pending=True)
(BUILD/'MAP_CAPTURE_CORRECTION.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
summary=dict(parent);summary.update(result='PASS_ACTUAL_MAP_TREE_ADAPTER_OFFLINE_PENDING_GAME',
    modules=[dict(role='core',installed_path='ResourceScanner/ResourceScannerCore.dll',**ref(BUILD/'ResourceScannerCore.dll')),
        dict(role='loader',installed_path='vulkan-1.dll',**ref(ROOT/'build_final07/vulkan-1.dll'))],
    reports=[ref(BUILD/'BUILD_RECEIPT.json'),ref(BUILD/'MAP_CAPTURE_CORRECTION.json'),ref(ROOT/'build_final07/NATIVE_QA_SUMMARY.json')],
    boundaries=['Proxy07 has actual game renderer success; its exact bytes are retained.',
        'Adapter08 accepts an unmodified coherent actual-game map snapshot and rejects 15 malformed ownership/header/lifecycle cases.',
        'This Core still awaits Root-owned actual flags15/helper-ready3 verification before release.'])
(BUILD/'NATIVE_QA_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(dict(summary=ref(BUILD/'NATIVE_QA_SUMMARY.json'),proof=ref(BUILD/'MAP_CAPTURE_CORRECTION.json'),modules=summary['modules']),indent=2))
