// Our production bridge compiled into an inert API/provider host, never a game.
#include <windows.h>
#include <map>
#include <vector>
#include <cstring>
#include <cstdio>
#include <thread>
#include <stdexcept>
#include <immintrin.h>
namespace fixture {
std::map<std::uintptr_t,std::vector<std::uint8_t>> memory;
std::uint32_t* output{};bool window_ok=true,cursor_ok=true,foreground=true;std::uint64_t now=10000;
float mouse_x=500,mouse_y=400;DWORD window_pid=77;unsigned dispatches{},original_drains{};DWORD dispatch_thread{};
BOOL WINAPI read(HANDLE,LPCVOID address,LPVOID out,SIZE_T n,SIZE_T*done){
    const auto p=reinterpret_cast<std::uintptr_t>(address);if(done)*done=0;
    if(output&&p==reinterpret_cast<std::uintptr_t>(output)&&n==4){std::memcpy(out,output,4);if(done)*done=4;return TRUE;}
    for(auto&[base,bytes]:memory)if(p>=base&&p+n>=p&&p+n<=base+bytes.size()){std::memcpy(out,bytes.data()+p-base,n);if(done)*done=n;return TRUE;}
    return FALSE;
}
BOOL WINAPI is_window(HWND hwnd){return window_ok&&hwnd==reinterpret_cast<HWND>(0x1234);}
DWORD WINAPI window_thread(HWND,DWORD*pid){if(pid)*pid=window_pid;return 88;}
HWND WINAPI foreground_window(){return reinterpret_cast<HWND>(foreground?0x1234:0x9999);}
BOOL WINAPI cursor(LPPOINT p){if(!cursor_ok)return FALSE;p->x=static_cast<LONG>(mouse_x)+100;p->y=static_cast<LONG>(mouse_y)+200;return TRUE;}
BOOL WINAPI to_client(HWND,LPPOINT p){p->x-=100;p->y-=200;return TRUE;}
ULONGLONG WINAPI ticks(){return now;}
}
#define ReadProcessMemory fixture::read
#define IsWindow fixture::is_window
#define GetWindowThreadProcessId fixture::window_thread
#define GetForegroundWindow fixture::foreground_window
#define GetCursorPos fixture::cursor
#define ScreenToClient fixture::to_client
#define GetTickCount64 fixture::ticks
#include "tracking.cpp"
#undef ReadProcessMemory
#undef IsWindow
#undef GetWindowThreadProcessId
#undef GetForegroundWindow
#undef GetCursorPos
#undef ScreenToClient
#undef GetTickCount64
namespace rs::platform {void log(std::string_view,std::string_view)noexcept{}}
namespace fixture {
using namespace rs::game;using namespace rs::game::tracking_detail;
constexpr std::uintptr_t base=0x10000000,app=0x20000000,ui=0x21000000,view=0x22000000,owner=0x23000000,game_ui=0x24000000,
    state=0x25000060,node=0x26000000,viewport=0x27000000,arena=0x28000000,builder=0x29000000,list=0x2A000000,
    root=0x2B000000,controller=0x2C000000,client=0x2D000000,world=0x2E000000,manager=0x30000000,input=0x32000000;
std::array<std::int64_t,3> expected_xyz{};bool dispatch_fault{},dispatch_drop{};
template<class T>void put(std::uintptr_t p,T value){for(auto&[start,bytes]:memory)if(p>=start&&p+sizeof(T)<=start+bytes.size()){std::memcpy(bytes.data()+p-start,&value,sizeof(value));return;}throw std::runtime_error("Fixture write");}
void add(std::uintptr_t p,std::size_t n){memory[p].resize(n);}
void __fastcall original(std::uintptr_t p){if(p!=app)throw std::runtime_error("Wrong original app");++original_drains;}
void __fastcall submitted(std::uintptr_t p,const Packet*packet){
    if(dispatch_fault)RaiseException(0xE055AA11,0,0,nullptr);
    if(!draining||p!=controller||packet->kind!=0x42||packet->valid!=1||packet->xyz!=expected_xyz)throw std::runtime_error("Packet/thread route");
    for(auto x:packet->pad)if(x)throw std::runtime_error("Packet padding");for(auto x:packet->tail)if(x)throw std::runtime_error("Packet tail");
    if(dispatch_drop)return; // A VOID consumer can decline allocation without reporting it.
    ++dispatches;dispatch_thread=GetCurrentThreadId();
}
Frame frame(){Frame f{};f.process_id=77;f.process_creation_time=88;f.sequence=100;f.scope_start_sequence=90;f.sampled_at_ms=now;
    f.source=Availability::compatible;f.map_open=f.projection_ready=f.hud_bounds_ready=f.world_ready=true;
    f.application_address=app;f.ui_address=ui;f.map_state_address=state;f.map_content={0,100,1920,1000};f.tracking_generation=epoch;return f;}
TrackingHit hit(){TrackingHit h{};h.scope=frame();h.native_window=0x1234;h.source_point_id=7;h.x=123.125f;h.y=783.328125f;h.z=-234.5f;h.source_flags=1;
    h.area_count=2;h.areas[0]={{480,380,520,420},0,TrackingShape::circle};h.areas[1]={{518,398,534,414},0,TrackingShape::circle};return h;}
void setup(){
    stop();memory.clear();output=nullptr;window_ok=cursor_ok=foreground=true;window_pid=77;now=10000;mouse_x=500;mouse_y=400;
    dispatches=original_drains=0;dispatch_thread=0;dispatch_fault=dispatch_drop=false;
    add(base+0x281E498,8);add(app,0x36000);add(ui,0x1000);add(view,0x32000);add(owner,0x100);add(game_ui,0x1D00);
    add(state-0x60,0x300);add(node,0x128);add(viewport,0x100);add(arena,0x100);add(builder,0x20);add(list,0x20);
    add(root,0x100);add(controller,0x210);add(client,0x480000);add(world,0x100);add(manager,0x120000);add(input,0x30);
    put(base+0x281E498,root);put(root+0x10,ui+0x10);put(root+0x18,builder);put(root+0xD0,view);
    put(app+0x5B0,ui);put(ui+0x68,ui);put(ui,app+0x468);put(ui+0x58,view);put(view,owner);put(owner+0x38,game_ui);
    put(owner+0xC,std::uint8_t{7});put(game_ui+0x1CD8,std::uint8_t{5});put(view+0x31E70,std::uint8_t{1});
    put(state-0x28,std::uint64_t{0x236F8649B9BF0F5B});put(state-0x18,std::uint32_t{0x260});put(state-0x38,std::uint64_t{333});put(state+0x18,node);
    put(node+0x38,std::uint64_t{0x6A533A7BC1DBE699});put(node+0x48,arena);put(node+0x50,viewport);put(node+0x68,std::uint32_t{444});
    put(viewport+0x10,arena);put(viewport+0x18,builder);put(viewport+0x80,std::uint32_t{444});put(builder,arena);put(builder+0x10,list);put(list,std::uint64_t{333});put(list+8,viewport);put(input+8,node);
    put(app+0x35280,controller);put(controller,base+0x1D48EE0);put(controller+0x28,app);put(controller+0x1B8,client);put(client+0x47D4E0,world);put(app+0x690,manager);put(client+0x88,manager);
    put(manager+0x1192BE,std::uint8_t{3});put(manager+0x1192BF,std::uint8_t{1});put(manager+0x1192C0,std::uint8_t{1});
    put(manager+0x10DF2E,std::uint8_t{3});put(manager+0x10DF2F,std::uint8_t{1});put(manager+0x10DF30,std::uint8_t{2});
    game_base=base;pid=77;birth=88;active=true;process_commands=original;dispatch=submitted;
    observe_request(state,ui+0x10,builder);auto current=frame();observe_frame(current);
    auto h=hit();coordinates(h.x,h.y,h.z,expected_xyz);
}
bool button(std::uint32_t&status,std::uint8_t selector=2,std::uintptr_t caller=base+0xD3C013){output=&status;return handle_button(caller,input,&status,selector);}
}
int main(){
    using namespace fixture;unsigned checks{};
    auto require=[&](bool value){++checks;if(!value){std::printf("FAIL tracking case %u\n",checks);throw std::runtime_error("assertion");}};
    try{
        // Primary GAME C20530/C205xx uses MULSS 2^32 and truncating signed
        // conversion. It agrees with our bounded conversion, including signed
        // primary Q16.16 source heights and genuine zero (no coordinate flip).
        for(float value:{1420.5068359375f,783.328125f,-123.125f,0.f,123.456f,1000000.f,-1000000.f}){
            std::array<std::int64_t,3> xyz{};require(coordinates(value,value,value,xyz));
            const auto native=_mm_cvttss_si64(_mm_mul_ss(_mm_set_ss(value),_mm_set_ss(4294967296.f)));
            require(xyz[0]==native&&xyz[1]==native&&xyz[2]==native);
        }
        setup();auto h=hit();require(publish_tracking_hit(h));require(dispatches==0);
        std::uint32_t status=1;require(button(status)&&status==0&&pending.load()&&dispatches==0);
        clear_tracking_hit();for(auto s:{2u,0u,2u}){status=s;require(button(status)&&status==0);}
        const auto thread=GetCurrentThreadId();commands_hook(app);require(dispatches==1&&dispatch_thread==thread&&original_drains==1&&!pending.load());
        commands_hook(app);require(dispatches==1&&original_drains==2);status=4;require(button(status)&&status==0);status=2;require(!button(status)&&status==2);
        for(auto end:{3u,4u,5u}){setup();require(publish_tracking_hit(hit()));status=1;require(button(status));status=end;require(button(status)&&status==0);status=2;require(!button(status));}
        setup();require(publish_tracking_hit(hit()));status=1;require(button(status));status=4;require(button(status));require(publish_tracking_hit(hit()));status=1;require(!button(status)&&status==1);commands_hook(app);require(dispatches==1);
        setup();require(publish_tracking_hit(hit()));status=1;require(!button(status,1)&&status==1);require(!button(status,2,base+1)&&status==1);mouse_x=700;require(!button(status)&&status==1&&!pending.load());
        setup();h=hit();h.areas[0]={{480,380,520,420},8,TrackingShape::rounded_rectangle};mouse_x=481;mouse_y=381;require(publish_tracking_hit(h));status=1;require(!button(status));mouse_x=484;mouse_y=384;require(button(status));
        for(unsigned bad=0;bad<13;++bad){setup();h=hit();switch(bad){case 0:h.source_flags=0;break;case 1:h.source_flags=2;break;case 2:h.y=std::nanf("");break;
            case 3:h.scope.map_open=false;break;case 4:h.scope.process_id=78;break;case 5:h.scope.process_creation_time=89;break;case 6:h.scope.scope_start_sequence=0;break;
            case 7:h.scope.sampled_at_ms=now-251;break;case 8:window_ok=false;break;case 9:foreground=false;break;case 10:window_pid=78;break;case 11:h.area_count=3;break;case 12:h.scope.world_ready=false;break;}
            require(!publish_tracking_hit(h));status=1;require(!button(status)&&status==1&&!pending.load()&&dispatches==0);}
        setup();h=hit();h.y=0;coordinates(h.x,h.y,h.z,expected_xyz);require(publish_tracking_hit(h));status=1;require(button(status));commands_hook(app);require(dispatches==1);
        for(unsigned changed=0;changed<9;++changed){setup();require(publish_tracking_hit(hit()));status=1;require(button(status));switch(changed){
            case 0:put(client+0x47D4E0,world+8);break;case 1:put(manager+0x1192BE,std::uint8_t{4});break;case 2:put(manager+0x10DF2E,std::uint8_t{4});break;
            case 3:put(game_ui+0x1CD8,std::uint8_t{1});break;case 4:put(view+0x31E70,std::uint8_t{2});break;case 5:put(controller+0x28,app+8);break;
            case 6:now+=501;break;case 7:{auto f=frame();f.map_open=false;observe_frame(f);break;}case 8:put(app+0x35280,controller+8);break;}
            commands_hook(app);require(!pending.load()&&dispatches==0);}
        setup();require(publish_tracking_hit(hit()));status=1;require(button(status));dispatch_fault=true;commands_hook(app);require(!pending.load()&&dispatches==0);
        setup();require(publish_tracking_hit(hit()));status=1;require(button(status));dispatch_drop=true;commands_hook(app);require(!pending.load()&&dispatches==0&&original_drains==1);
        // A proposed queue/gesture transition is never committed if the game's
        // output cannot be suppressed. These are only fixture-owned pages.
        setup();require(publish_tracking_hit(hit()));alignas(4) std::array<std::uint8_t,8> unaligned{};
        std::uint32_t one=1;std::memcpy(unaligned.data()+1,&one,4);output=reinterpret_cast<std::uint32_t*>(unaligned.data()+1);
        require(!handle_button(base+0xD3C013,input,output,2)&&!pending.load());std::memcpy(&status,unaligned.data()+1,4);require(status==1);
        commands_hook(app);require(dispatches==0);status=1;require(button(status)&&pending.load());
        DWORD old_protection{};auto* readonly=static_cast<std::uint32_t*>(VirtualAlloc(nullptr,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
        require(readonly!=nullptr);*readonly=4;require(VirtualProtect(readonly,4096,PAGE_READONLY,&old_protection)!=FALSE);output=readonly;
        require(!handle_button(base+0xD3C013,input,readonly,2)&&*readonly==4&&pending.load());
        // Failed release suppression keeps the already-owned gesture. A later
        // writable release is still consumed; it cannot leak a vanilla click.
        status=2;require(button(status)&&status==0);status=4;require(button(status)&&status==0);commands_hook(app);require(dispatches==1);
        require(VirtualFree(readonly,0,MEM_RELEASE)!=FALSE);
        setup();require(publish_tracking_hit(hit()));readonly=static_cast<std::uint32_t*>(VirtualAlloc(nullptr,4096,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE));
        require(readonly!=nullptr);*readonly=1;require(VirtualProtect(readonly,4096,PAGE_READONLY,&old_protection)!=FALSE);output=readonly;
        require(!handle_button(base+0xD3C013,input,readonly,2)&&*readonly==1&&!pending.load());commands_hook(app);require(dispatches==0);
        // Neither failed initial suppression nor its later release owns RMB.
        status=4;require(!button(status)&&status==4);require(VirtualFree(readonly,0,MEM_RELEASE)!=FALSE);
        setup();require(publish_tracking_hit(hit()));status=1;require(button(status));h=hit();h.scope.scope_start_sequence=91;require(publish_tracking_hit(h));commands_hook(app);require(dispatches==0);
        setup();h=hit();h.scope.world_guid[0]=1;require(publish_tracking_hit(h));status=1;require(button(status));h.scope.world_guid[0]=2;require(publish_tracking_hit(h));commands_hook(app);require(dispatches==0);
        setup();require(publish_tracking_hit(hit()));cursor_ok=false;status=1;require(!button(status)&&status==1&&!pending.load());
        setup();require(publish_tracking_hit(hit()));put(list+8,std::uintptr_t{0});status=1;require(!button(status)&&status==1&&!pending.load());
        setup();require(publish_tracking_hit(hit()));h=hit();h.source_flags=0;require(!publish_tracking_hit(h));status=1;require(!button(status)&&status==1);
        setup();h=hit();{auto closed=frame();closed.map_open=false;observe_frame(closed);auto reopened=frame();observe_frame(reopened);}
        require(!publish_tracking_hit(h));status=1;require(!button(status)&&!pending.load());require(publish_tracking_hit(hit()));require(button(status));
        setup();h=hit();{auto changed=frame();changed.hero_guid[0]=3;observe_frame(changed);}require(!publish_tracking_hit(h));
        h=hit();h.scope.hero_guid[0]=4;require(!publish_tracking_hit(h));h.scope.hero_guid[0]=3;require(publish_tracking_hit(h));
        for(unsigned change=0;change<2;++change){setup();h=hit();if(change==0)put(client+0x47D4E0,world+8);
            else{put(manager+0x1192BE,std::uint8_t{4});put(manager+0x10DF2E,std::uint8_t{4});}
            auto current=frame();observe_frame(current);require(current.tracking_generation!=h.scope.tracking_generation);require(!publish_tracking_hit(h));
            h=hit();h.scope=current;require(publish_tracking_hit(h));status=1;require(button(status));}
        setup();h=hit();put(client+0x47D4E0,std::uintptr_t{0});{auto current=frame();observe_frame(current);require(!current.tracking_generation);}
        require(!publish_tracking_hit(h)); // optional read loss does not admit an old hit
        for(unsigned change=0;change<2;++change){setup();require(publish_tracking_hit(hit()));
            if(change==0)put(client+0x47D4E0,world+8);else{put(manager+0x1192BE,std::uint8_t{4});put(manager+0x10DF2E,std::uint8_t{4});}
            status=1;require(!button(status)&&status==1&&!pending.load());commands_hook(app);require(dispatches==0);}
        setup();Request r{};Context c{};require(!invoke(c,r)); // engine never called outside native drain
        stop();std::printf("PASS tracking production-host %u assertions; native provider only, no game access\n",checks);return 0;
    }catch(const std::exception&e){std::printf("FAIL %s\n",e.what());return 1;}
}
