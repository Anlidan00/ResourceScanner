"""5.0.3 dynamic2x/config zoom delta; bind existing native/UI evidence."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final14'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)
def main():
    parent_path=ROOT/'build_final13/NATIVE_QA_SUMMARY.json';parent=json.loads(parent_path.read_text())
    prior=json.loads((ROOT/'build_final13/BUILD_RECEIPT.json').read_text())
    snapshot_path=BUILD/'SOURCE_INPUTS_BEFORE_BUILD.json';snapshot=json.loads(snapshot_path.read_text())
    expected=['CMakeLists.txt','src/platform/lifecycle.cpp','src/platform/paths.cpp','src/game/zoom_out.cpp','src/game/zoom_out.hpp','src/game/zoom_out_smoke.cpp']
    changed=sorted(name for name,value in snapshot['source_files'].items()if prior['source_files'].get(name)!=value)
    assert changed==sorted(expected),changed
    assert set(snapshot['source_files'])==set(prior['source_files'])
    for name in ['CMakeLists.txt','src/platform/lifecycle.cpp','src/platform/paths.cpp']:
        assert hashlib.sha256((ROOT/name).read_bytes().replace(b'5.0.3',b'5.0.2')).hexdigest()==prior['source_files'][name],name
    assert snapshot['source_files']['src/ui.cpp']=='d9ca113d66d5c8beb89720966cfed83531d21ad723321ab57dc346a8d31388b6'
    run=subprocess.run([str(BUILD/'rs_world_zoom_smoke.exe')],cwd=BUILD,capture_output=True,text=True,timeout=15);assert run.returncode==0
    source503=dict(result='PRIMARY_GAME_WORLD_ZOOM_SOURCE_WITH_5_0_3_DYNAMIC_2X_STARTUP_POLICY',
        primary_game_source=ref(ROOT/'src/game/ZOOM_SOURCE.json'),unchanged_optional_signature_header=ref(ROOT/'src/game/zoom_profile.hpp'),
        prior_0_25_level_superseded=True,extra_level='0.5f * originalLevels.back()',current_native_table=[16,8,4,2],current_extra_level=1,
        source_guards='Four positive finite strictly descending native levels, max1024; half-last normal, positive, strictly smaller, exact double equals native last.',
        setting=dict(file='ResourceScanner/settings.ini',section='Scanner',key='ExtraZoomOut',default=1,enabled=1,disabled=0,cadence='startup/restart'),
        off='Early successful disabled return before source-profile/target reads and any creation/enabling of zoom hooks. Base Scanner observers/render unchanged.',
        restoration='Unchanged atomic8B fifth/count/padding exchange and compare-restore in native SEH/C++ finally. No persistent game config or minimap edit.',
        sources={name:snapshot['source_files'][name]for name in ['src/game/zoom_out.cpp','src/game/zoom_out.hpp','src/game/zoom_out_smoke.cpp']},
        no_game_access=True)
    profile_path=BUILD/'ZOOM_SOURCE_503.json';profile_path.write_text(json.dumps(source503,indent=2),encoding='utf8')
    tests=[dict(command=['rs_world_zoom_smoke.exe'],exit_code=run.returncode,stdout=run.stdout,cases=36)]
    receipt=dict(result='PASS_FRESH_5_0_3_ZOOM_ONLY_SOURCE_BUILD_WITH_SCOPED_REGRESSION',product='ResourceScanner',version='5.0.3',
        source_files=snapshot['source_files'],compiled_input_files=snapshot['compiled_input_files'],
        prebuild_inputs=ref(snapshot_path),compile_commands=ref(BUILD/'compile_commands.json'),
        source_binding='Exact source hashes before and after fresh compilation; six expected files differ from13, including three version-only sources.',
        upstream_provenance=ref(ROOT/'third_party/PROVENANCE.json'),tests=tests,
        actual_game_math=ref(BUILD/'ZOOM_2X_MATH_REVIEW.json'),
        inherited_unchanged_native_tests=dict(receipt=ref(ROOT/'build_final12/BUILD_RECEIPT.json'),
            excludes='Old rs_world_zoom_smoke; replaced by36 new unit cases and768 exactGAMEclamp checks.',other_cases=13),
        artifacts=[ref(BUILD/'ResourceScannerCore.dll')],no_game_tests=True,no_installed_file_access=True,installer_payload_permitted=False,release_ready=False)
    receipt_path=BUILD/'BUILD_RECEIPT.json';receipt_path.write_text(json.dumps(receipt,indent=2),encoding='utf8')
    carry=dict(result='PASS_DYNAMIC_2X_AND_STARTUP_OPTION_DELTA_UNCHANGED_UI_NATIVE_RENDER_PROTOCOLS',
        parent=ref(parent_path),receipt=ref(receipt_path),changed_sources=changed,version_only_sources=expected[:3],
        zoom_source=ref(profile_path),actual_math=ref(BUILD/'ZOOM_2X_MATH_REVIEW.json'),
        math_test_source=ref(ROOT/'src/game/test_zoom2x_source_math.py'),
        unchanged='All other own sources/headers/assets/fonts/generators/licenses equal Core13: UI d9ca, Vulkan09 ownership, adapter11 geometry/HUD, Frame/State IPC, fonts.',
        retained_proxy=ref(ROOT/'build_final07/vulkan-1.dll'),prior_ui_peer=ref(ROOT/'qa/ui_overview13/REPORT.json'),
        narrow_independent_zoom_peer_pending=True,installer_payload_permitted=False)
    carry_path=BUILD/'ZOOM_503_SOURCE_CARRY.json';carry_path.write_text(json.dumps(carry,indent=2),encoding='utf8')
    bindings=dict(parent['input_bindings']);bindings['world_zoom_source']=ref(profile_path)
    summary=dict(parent);summary.update(result='PASS_5_0_3_DYNAMIC_2X_OPTIONAL_WORLD_ZOOM_NATIVE_OFFLINE',version='5.0.3',source_files=snapshot['source_files'],input_bindings=bindings,
        modules=[dict(role='core',installed_path='ResourceScanner/ResourceScannerCore.dll',**ref(BUILD/'ResourceScannerCore.dll')),
                 dict(role='loader',installed_path='vulkan-1.dll',**ref(ROOT/'build_final07/vulkan-1.dll'))],
        reports=[ref(receipt_path),ref(carry_path),ref(profile_path),ref(parent_path),ref(ROOT/'qa/ui_overview13/REPORT.json')],
        validation_limits=['This exact Core14 was not installed or game-tested by the native owner; independent zoom review and coordinator admission are separate gates.',
            '36 compiled zoom/config/restore cases and768 exact cachedGAME clamp checks cover this delta. No broad14-fixture repeat;13 unaffected cases inherited by exact source equality.',
            'Startup setting changes take effect after restart; no live setting UI or game configuration write is added.'],
        boundaries=['Maximum additional zoom-out exactly2x native current minimum, computed dynamically from the existing native four-level table.',
            'ExtraZoomOut=0 bypasses only zoom hooks/effects; base Scanner source/render code is exact13.',
            'Only native zoom sources/test and three5.0.3 version strings changed. UI d9ca/proxy07c49/fonts/assets/protocols retained.',
            'Private candidate flags remain false pending coordinator admission.'],
        no_game_tests=True,root_owned_game_test_pending=False,installer_payload_permitted=False,release_ready=False)
    path=BUILD/'NATIVE_QA_SUMMARY.json';path.write_text(json.dumps(summary,indent=2),encoding='utf8')
    print(summary['result'],sha(path),sha(BUILD/'ResourceScannerCore.dll'))
if __name__=='__main__':main()
