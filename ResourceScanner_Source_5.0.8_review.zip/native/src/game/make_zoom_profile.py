"""Generate optional zoom compatibility facts from the cached GAME only."""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parents[2]
GAME=ROOT.parent/'terrain/private/enshrouded.exe'
SPANS=[(0xC1E810,49),(0xC1EA09,28),(0xC1EB00,69),(0xC1EB45,24),(0x119F650,5),
       (0xC1ED96,32),(0xC2022B,42),(0xD40D80,65),(0xD40E09,102),
       (0xD80204,40),(0xD802BE,102),(0xD3B88F,57),(0xC1F4F4,26)]
def main():
    raw=GAME.read_bytes();nt=struct.unpack_from('<I',raw,60)[0];opt=nt+24
    ns=struct.unpack_from('<H',raw,nt+6)[0];ops=struct.unpack_from('<H',raw,nt+20)[0]
    def read(rva,n):
        for i in range(ns):
            _,va,size,ptr=struct.unpack_from('<IIII',raw,opt+ops+i*40+8)
            if va<=rva and rva+n<=va+size:return raw[ptr+rva-va:ptr+rva-va+n]
        raise ValueError('Unbacked source RVA')
    lines=['#pragma once','#include <cstdint>','#include <cstddef>','namespace rs::game::zoom_profile {',
           'struct Span {std::uint32_t rva;const std::uint8_t* bytes;std::size_t size;};']
    signatures=[]
    for i,(rva,n) in enumerate(SPANS):
        b=read(rva,n);signatures.append(dict(rva=rva,bytes_hex=b.hex()))
        lines.append(f'inline constexpr std::uint8_t bytes_{i}[]={{'+','.join(f'0x{x:02x}'for x in b)+'};')
    lines.append('inline constexpr Span spans[]={')
    lines += [f'{{0x{rva:x},bytes_{i},{n}}},'for i,(rva,n)in enumerate(SPANS)]
    lines+=['};','}']
    (Path(__file__).parent/'zoom_profile.hpp').write_text('\n'.join(lines)+'\n',encoding='utf8')
    proof=dict(result='PRIMARY_GAME_SOURCE_WORLD_MAP_EXTRA_ZOOM',source_sha256=hashlib.sha256(raw).hexdigest(),
        source_path=str(GAME.resolve()),no_original_mod_code=True,whole_version_gate=False,signatures=signatures,
        world_renderer=dict(rva='C1E810',abi='u8(element)',world_only_dispatch='Existing Map=5/page1 native source profile; C1EA09 requests exact MapState.',
            scope='C1EDAE calls D7FFD0 BEFORE world renderer returns; C20250 calls D3B300 inside C201B0 from C1EDA9.'),
        initializer=dict(rva='D40D80',abi='void(state,options,zoomIndex)',world_call_return='C1EB5D',
            width_height='state+38/+3C; options+0/+4',levels='state+40, five float capacity; count byte+54',
            capacity_proof='C1EB00 initial max4 copied; C1EB1B rejects count5 overflow at C1F4F4 with capacity literal5.',
            baseline_capture='map09_44496_all_bulk.json: [16,8,4,2], count4, unused fifth0.',
            base_scale='state+58 =2048/min(worldWidth,worldHeight), D40E13..38'),
        zoom_math=dict(update='D802BE..324 uses min(first,last)*base as lower clamp, max(first,last)*base as upper clamp.',
            discrete_and_pan='D80204..228 and D3B88F..8BF clamp zoomIndex to count-1 and read selected array entry.',
            additional_level=.25,baseline_minimum=2.,additional_zoom_out_factor=8.,
            full_world_example='Captured10240m world: base=.2, extra image dimension=10240*.2*.25=512 logical pixels.'),
        restoration='Only aligned 8-byte state+50 fifth/count/padding word changes. Entire original word restored by compare-exchange in C++/SEH finally; first4 levels and header identity checked.',
        nested='Thread-local stack of scopes. An inner scope sees outer count5 and makes no second edit; restores its own previous scope pointer.',
        no_persistent_config_writes=True,insert_independent=True,minimap_unchanged=True,
        failure='Optional signature mismatch bypasses feature. Other adapter/renderer remain available; invalid state remains byte-exact.',
        game_test_pending=True)
    (Path(__file__).parent/'ZOOM_SOURCE.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
    print(proof['result'])
if __name__=='__main__':main()
