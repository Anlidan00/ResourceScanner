"""Extract only independently researched GAME instruction signatures.

No overlay/mod binary is read. These signatures are feature compatibility checks,
not executable code, trampolines, or a whole-version gate.
"""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parents[2]
CACHED=ROOT.parent/'terrain/private/enshrouded.exe'
SPANS=[(0x1185580,64),(0x11903B0,32),(0xC1EA09,28),(0xC1ED96,19),
       (0xD3B463,54),(0xD3B4A7,49),(0x119B0C0,8),(0xCF2940,96),
       (0xC1ECEF,62),(0xA3F220,24),(0x1190512,21),
       (0xC4FC40,128),(0xBD9E48,96),(0xBC230B,80),
       (0xA44560,24),(0x11FAA40,24),(0xBC1E40,83),(0xA3F520,15),
       (0xA4167F,59),(0xA43302,28),(0xBC24DB,26),(0xA30020,57),
       (0xA4320F,63),(0x1185631,61),(0x118577F,48),(0x11B4C3F,66)]
def main():
    raw=CACHED.read_bytes();nt=struct.unpack_from('<I',raw,60)[0];opt=nt+24
    ns=struct.unpack_from('<H',raw,nt+6)[0];ops=struct.unpack_from('<H',raw,nt+20)[0]
    def read(rva,n):
        for i in range(ns):
            vs,va,size,ptr=struct.unpack_from('<IIII',raw,opt+ops+i*40+8)
            if va<=rva and rva+n<=va+size:return raw[ptr+rva-va:ptr+rva-va+n]
        raise ValueError('Unbacked source RVA')
    profile=[];lines=['#pragma once','#include <cstdint>','#include <cstddef>','namespace rs::game::source_profile {','struct Span {std::uint32_t rva;const std::uint8_t* bytes;std::size_t size;};']
    for i,(rva,n)in enumerate(SPANS):
        data=read(rva,n);profile.append(dict(rva=rva,bytes_hex=data.hex()))
        lines.append(f'inline constexpr std::uint8_t bytes_{i}[]={{'+','.join(f'0x{x:02x}'for x in data)+'};')
    lines.append('inline constexpr Span spans[]={')
    for i,(rva,n)in enumerate(SPANS):lines.append(f'{{0x{rva:x},bytes_{i},{n}}},')
    lines+=['};','}']
    (Path(__file__).parent/'source_profile.hpp').write_text('\n'.join(lines)+'\n',encoding='utf8')
    (Path(__file__).parent/'SOURCE_PROFILE.json').write_text(json.dumps(dict(result='GAME_SOURCE_LAYOUT_SIGNATURES_ONLY',
        source_sha256=hashlib.sha256(raw).hexdigest(),source=str(CACHED),whole_version_gate=False,signatures=profile,
        projection='native world-image element rect and actual world metre dimensions; x increases right,z increases up',
        hooks=[dict(rva=0x1185580,abi='uintptr(element,u64key,u64size,uintptrtype,u32flags)'),dict(rva=0x11903B0,abi='u32(root,backendBuilder)')],
        scope='Only game executable reverse-engineering facts. No previous overlay executable or routine was read.'),indent=2),encoding='utf8')
    (Path(__file__).parent/'COMMIT_CAPTURE_SOURCE.json').write_text(json.dumps(dict(
        result='SOURCE_TYPED_DUAL_FRAME_COMMIT_CAPTURE',source_sha256=hashlib.sha256(raw).hexdigest(),
        no_original_mod_inputs=True,no_game_access=True,
        ui_context_frame=dict(producer='A43200: RCX=UiSystem; callback atA4331A receives UiSystem+10 and the backendBuilder',
            fields={'timestamp':'UiSystem+18 == ui_context_frame+8','user_data_view':'ui_context_frame+48'},
            root_constructor='A30020: transientRoot+10=ui_context_frame; +18=backendBuilder'),
        context_binding=dict(callback='BC1E40',prologue='four8-bytepushes; RBP=postpushRSP-0x78; finalRSP=postpushRSP-0x178',
            arithmetic='RBP=finalRSP+0x100; localRoot=finalRSP+0x60; [RBP+0x30]==Root+0xD0',
            instructions='A3F520 copies ui_context_frame+48 pair; BC1E84 reads firstpointer; BC1E87 stores toRBP+30',
            derived='ctx=firstpointer atui_context_frame+48; uiStateOwner=[ctx]; gameUI=[uiStateOwner+38]'),
        canvas_frame=dict(producer='11B4C47/119040C: canvas_frame=[backendBuilder+10]',
            fields={'request_counter':'canvas_frame+0','viewport_head':'canvas_frame+8'},
            distinct_from='ui_context_frame; never deriveUiSystem by subtracting10fromcanvas_frame'),
        commit=dict(caller='A416AB RCX=[UiSystem+E90]; RDX=backendBuilder fromRBP; A416B5 calls11903B0',
            timing='A43200 callback returns afterBC24E9 clears281E498; commit follows, so do not reread transientRoot here',
            anchor='Capture ui_context_frame+backendBuilder during provenMapState request. Atcommit require SAMEbackend, live UiSystemself/Appbacklinks, [UiSystem+E90]==actualRCX.'),
        map_state=dict(request='1185580 MapState key236F8649B9BF0F5B,size260; sourceC1EA09..25',
            time='body+0 contains timestamp fromA3F220 (ui_context_frame+8), notviewport',
            current_layout='body-38 requeststamp==*[canvas_frame]; mapRoot=body+18; mapRoot.viewport=+50; viewport.frame=+10,viewport.backend=+18',
            geometric_projection='worldImage literal3F267F93B50D2258 currentrect; body38/3C actualworldmetres; Xright/Zup'),
        limitations=['Actual in-game observer scheduling and render integration are not tested by user request.','Only independently sourced GAME instruction facts are represented; no old overlay function is used.']
    ),indent=2),encoding='utf8')
if __name__=='__main__':main()
