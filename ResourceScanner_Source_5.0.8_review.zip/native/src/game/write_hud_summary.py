"""Private native-control rectangle correction, with captured GAME layout."""
from pathlib import Path
import hashlib,json,struct,subprocess
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final10'
def ref(path):return dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
parent_path=ROOT/'build_final09/NATIVE_QA_SUMMARY.json';parent=json.loads(parent_path.read_text());old=json.loads((ROOT/'build_final09/BUILD_RECEIPT.json').read_text());new=json.loads((BUILD/'BUILD_RECEIPT.json').read_text())
changed=sorted(name for name,value in old['source_files'].items()if new['source_files'].get(name)!=value)
assert changed==['include/rs/game/frame.hpp','src/game/adapter.cpp','src/game/adapter_smoke.cpp','src/ui.cpp'],changed
assert new['source_files']['src/ui.cpp']=='39ee1248f1458b15b1b0c3a1c3741dd16d9c3f929a5ebb102dce1fa2d4050471'
for name in ['src/platform/vulkan_render.cpp','src/platform/vulkan_dispatch.hpp','src/platform/vulkan_proxy.cpp','src/platform/shared_frame.cpp','src/game/state.cpp']:
    assert old['source_files'][name]==new['source_files'][name],name
bindings=dict(parent['input_bindings']);bindings['ui_source']=ref(ROOT/'src/ui.cpp')
for item in bindings.values():assert ref(Path(item['path']))['sha256']==item['sha256']
capture_path=ROOT/'diagnostics/map09_44496_all_bulk.json';capture=json.loads(capture_path.read_text())
assert len(capture['nodes'])==279 and len(capture['viewport_records'])==10 and {n['generation']for n in capture['nodes']}=={capture['scalar']['viewport_generation']}
run=subprocess.run([str(BUILD/'rs_game_adapter_smoke.exe'),str(capture_path)],cwd=BUILD,capture_output=True,text=True,timeout=30);assert run.returncode==0,run.stdout+run.stderr
game=ROOT.parent/'terrain/private/enshrouded.exe';raw=game.read_bytes();nt=struct.unpack_from('<I',raw,60)[0];opt=nt+24;nsec=struct.unpack_from('<H',raw,nt+6)[0];olen=struct.unpack_from('<H',raw,nt+20)[0]
def data(rva,size):
    for i in range(nsec):
        p=opt+olen+40*i;_,va,length,off=struct.unpack_from('<IIII',raw,p+8)
        if va<=rva and rva+size<=va+length:return raw[off+rva-va:off+rva-va+size]
    raise ValueError(rva)
windows=[dict(rva=rva,bytes_hex=data(rva,size).hex(),meaning=meaning)for rva,size,meaning in [
    (0xC22CED,0x35,'mapMarkerSubmenuParent literal and key7CDBAF8FF444C1B8.'),
    (0xC2193D,7,'doMapMarkerFiltering literal.'),(0xC219E2,0x2E,'doMapMarkerFiltering key9DD5F4A51595D5FE and native widget creation.'),
    (0xCE6020,0x6B,'doWorldStats literal and key1342A8EA1B9CD903.'),
    (0xD37155,0x39,'Map-point card titleGroup literal and keyDFC334B43D1B81A0.'),
    (0x119040C,0x10,'Same proven backend viewport-list traversal; list-head+8.')]]
proof=dict(result='PASS_OPTIONAL_NATIVE_UI_CONTROL_RECTS_AND_UI_MARKER_ENVELOPE_OFFLINE',
    parent=ref(parent_path),receipt=ref(BUILD/'BUILD_RECEIPT.json'),game_source=ref(game),source_windows=windows,
    capture=ref(capture_path),read_only_capture_scope=dict(pid=capture['pid'],birth=capture['birth'],bytes=capture['bytes_read'],no_game_calls=True,no_process_writes=True),
    collector=ref(ROOT/'src/game/hud_blockers.hpp'),ui_envelope_peer=ref(ROOT/'qa/ui_blockers10/REPORT.json'),
    frame_tail=dict(after='hero_guid',fields=['std::array<Rect,32> ui_blockers','uint32_t ui_blocker_count','bool ui_blockers_ready'],geometry='client pixels',wire_protocol_changed=False),
    selection=['Current-generation finite leaf control/input rectangle union within left mapMarkerSubmenuParent.',
        'Current-generation finite leaf control/input rectangle union within right doMapMarkerFiltering.',
        'Exact current doWorldStats group rectangle.',
        'Exact current map-point popup card body: literal1 parent of titleGroup, directly under that same native viewport root.'],
    excluded_from_selection=['Fullscreen viewport roots','Full-height control layout ancestors','Map image/background','Arbitrary native POI influence-radius containers'],
    guards=['Same current backend/arena/list and stable UI/app/commit owner links.',
        'Bounded native viewport list, per-viewport generation/scale/origin/root and full tree parent/sibling links.',
        'Selected node rectangle/identity/owner/generation and viewport snapshots reread before commit.',
        'Optional failure clears only blocker output; base map projection/world/HUD readiness remains independent.'],
    actual_fixture=dict(executable=ref(BUILD/'rs_game_adapter_smoke.exe'),exit_code=run.returncode,stdout=run.stdout,checks=26,
        unmodified_nodes=279,same_generation=capture['scalar']['viewport_generation'],positive_map_flags=15,blocker_count=4,
        tested_regions=['People/Places controls','Marker filter','World stats','Native point popup'],central_map_not_blocked=True),
    changed_prior_compiled_sources=changed,new_compiled_header=ref(ROOT/'src/game/hud_blockers.hpp'),
    sourceFlags_and_sharedIPC_unchanged=True,vulkan09_exact_source_carry=True,retained_proxy=ref(ROOT/'build_final07/vulkan-1.dll'),
    actual_game_test_this_candidate_pending=True)
(BUILD/'HUD_BLOCKERS_REVIEW.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
summary=dict(parent);summary.update(result='PASS_NATIVE_UI_BLOCKERS_OFFLINE_PENDING_GAME',source_files=new['source_files'],input_bindings=bindings,
    modules=[dict(role='core',installed_path='ResourceScanner/ResourceScannerCore.dll',**ref(BUILD/'ResourceScannerCore.dll')),
        dict(role='loader',installed_path='vulkan-1.dll',**ref(ROOT/'build_final07/vulkan-1.dll'))],
    reports=[ref(BUILD/'BUILD_RECEIPT.json'),ref(BUILD/'HUD_BLOCKERS_REVIEW.json'),ref(ROOT/'qa/ui_blockers10/REPORT.json'),ref(parent_path)],
    boundaries=['Actual game09 proved renderer, map flags15 and independent FOW/knowledge readiness; exact Vulkan09 source is retained.',
        'Optional control rectangles protect four source-proven widget scopes; arbitrary future UI/POI artwork is not generically classified.',
        'This exact Core10 still awaits Root-owned visual/hover game verification before release.'])
(BUILD/'NATIVE_QA_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(dict(summary=ref(BUILD/'NATIVE_QA_SUMMARY.json'),proof=ref(BUILD/'HUD_BLOCKERS_REVIEW.json'),modules=summary['modules']),indent=2))
