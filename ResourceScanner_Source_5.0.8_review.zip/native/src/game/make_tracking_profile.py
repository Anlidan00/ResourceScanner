"""Optional source-layout signatures for our own tracking bridge, GAME only."""
from pathlib import Path
import struct,json,hashlib
ROOT=Path(__file__).resolve().parents[2];GAME=ROOT.parent/'terrain/private/enshrouded.exe'
SPANS=[(0xA3A670,52),(0xD3BFDD,54),(0xA301B0,32),(0x846830,64),(0x846B18,55),
       (0x8546D0,32),(0x854ADB,39),(0x852760,58),(0x853012,97),(0x854671,1),(0x854528,4),
       (0x150E4F0,4),(0x83AEA2,98),(0xE0D8AE,23),(0xE01340,64)]
def main():
    raw=GAME.read_bytes();nt=struct.unpack_from('<I',raw,60)[0];opt=nt+24
    count=struct.unpack_from('<H',raw,nt+6)[0];ops=struct.unpack_from('<H',raw,nt+20)[0]
    def read(rva,n):
        for i in range(count):
            _,va,size,pointer=struct.unpack_from('<IIII',raw,opt+ops+i*40+8)
            if va<=rva and rva+n<=va+size:return raw[pointer+rva-va:pointer+rva-va+n]
        raise ValueError('Unbacked source signature')
    lines=['#pragma once','#include <cstdint>','#include <cstddef>','namespace rs::game::tracking_profile {',
           'struct Span {std::uint32_t rva;const std::uint8_t*bytes;std::size_t size;};']
    rows=[]
    for i,(rva,n)in enumerate(SPANS):
        b=read(rva,n);rows.append(dict(rva=rva,bytes_hex=b.hex()))
        lines.append(f'inline constexpr std::uint8_t bytes_{i}[]={{'+','.join(f'0x{x:02x}'for x in b)+'};')
    lines.append('inline constexpr Span spans[]={');lines +=[f'{{0x{rva:x},bytes_{i},{n}}},'for i,(rva,n)in enumerate(SPANS)];lines+=['};','}']
    (Path(__file__).parent/'tracking_profile.hpp').write_text('\n'.join(lines)+'\n',encoding='utf8')
    proof=dict(result='PRIMARY_GAME_OPTIONAL_TRACKING_LAYOUT_SIGNATURES',game_sha256=hashlib.sha256(raw).hexdigest(),signatures=rows,
        no_original_mod_inputs=True,whole_game_version_gate=False,
        input='A3A670 calls original first; onlybutton2 atWORLD D3C013 with exactcurrentMapRoot view canbe consumed.',
        native_thread='846830 is actual App UI-command drain; normal0x42 fallback calls kind3controller8546D0->client852760. Our40Bstackcommand is consumed on that same callback thread.',
        buffer_safety='Own1slot immutable queue; NO writes to nativeUiCommandbuffers orB058B0, NO raw ECS writes/reimplementation.',
        outcome='VOID consumer; submitted means attempted. Native null-allocation branch remains vanilla; no fabricated success status.',
        common_profile='Base adapter SOURCE_PROFILE must succeed before tracking start; it supplies current Play/Map/page,UI/App/frame/layout facts.',
        hero='Existing primary selected pair+valid atmanager1192BE andloaded pair+state at10DF2E. SourcewriterE01340.. closes loadedpairlayout.',
        unavailable='Optional incompatibility disables this bridge only; Scanner/zoom and vanillaRMB remain normal.')
    (Path(__file__).parent/'TRACKING_PROFILE.json').write_text(json.dumps(proof,indent=2),encoding='utf8');print(proof['result'])
if __name__=='__main__':main()
