#include "tracking_internal.hpp"
#include "tracking_profile.hpp"
#include <rs/platform/paths.hpp>
#include <windows.h>
#include <MinHook.h>
#include <intrin.h>
#include <mutex>
#include <atomic>

namespace rs::game::tracking_detail {
namespace {
constexpr std::uintptr_t published_root=0x281E498;
struct Reader {
    MemoryReader source{};unsigned bytes{};
    bool copy(std::uintptr_t p,void*out,std::size_t n)noexcept{
        if(p<0x10000||p>0x00007FFFFFFEFFFFULL||n>512||p+n<p||(bytes+=static_cast<unsigned>(n))>8192)return false;
        return source.copy&&source.copy(source.user,p,out,n);
    }
    template<class T>bool get(std::uintptr_t p,T&v)noexcept{return copy(p,&v,sizeof(v));}
    bool pointer(std::uintptr_t p,std::uintptr_t&v)noexcept{return get(p,v)&&v>=0x10000&&v<=0x00007FFFFFFEFFFFULL;}
};
bool own_copy(void*,std::uintptr_t p,void*out,std::uint64_t n)noexcept{SIZE_T done{};return ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(p),out,static_cast<SIZE_T>(n),&done)&&done==n;}
}
bool capture_context(const MemoryReader&source,std::uintptr_t base,const SourceRequest&request,std::uintptr_t app,
                     std::uintptr_t input_view,bool published,Context&out)noexcept{
    out={};if(!base||request.ui_frame<0x10010||!request.state||!request.backend||!request.epoch)return false;
    Reader read{source};
    struct Witness {std::uintptr_t arena{},viewport{};std::uint64_t stamp{};std::uint32_t generation{};bool operator==(const Witness&)const=default;};
    auto capture=[&](Context&c,Witness&w)noexcept{
        c={};c.app=app;c.ui=request.ui_frame-0x10;c.map_state=request.state;c.epoch=request.epoch;
        std::uintptr_t value{},view{},owner{},game_ui{},viewport{},arena{},node_arena{},viewport_arena{},builder{},list{},root{},root2{};
        std::uint64_t key{},literal{},stamp{},current_stamp{};std::uint32_t size{},generation{},view_generation{};std::uint8_t play{},screen{},page{};
        if(!read.pointer(app+0x5B0,value)||value!=c.ui||!read.pointer(c.ui+0x68,value)||value!=c.ui||
           !read.pointer(c.ui,value)||value!=app+0x468||!read.pointer(request.ui_frame+0x48,view)||
           !read.pointer(view,owner)||!read.pointer(owner+0x38,game_ui)||!read.get(owner+0xC,play)||play!=7||
           !read.get(game_ui+0x1CD8,screen)||screen!=5||!read.get(view+0x31E70,page)||page!=1)return false;
        if(!read.get(request.state-0x28,key)||key!=0x236F8649B9BF0F5BULL||!read.get(request.state-0x18,size)||size!=0x260||
           !read.pointer(request.state+0x18,c.map_node)||!read.get(c.map_node+0x38,literal)||literal!=0x6A533A7BC1DBE699ULL||
           !read.pointer(c.map_node+0x48,node_arena)||!read.pointer(c.map_node+0x50,viewport)||
           !read.pointer(request.backend,arena)||arena!=node_arena||!read.pointer(viewport+0x10,viewport_arena)||viewport_arena!=arena||
           !read.pointer(viewport+0x18,builder)||builder!=request.backend||!read.pointer(request.backend+0x10,list)||
           !read.get(request.state-0x38,stamp)||!read.get(list,current_stamp)||stamp!=current_stamp||
           !read.get(c.map_node+0x68,generation)||!read.get(viewport+0x80,view_generation)||generation!=view_generation)return false;
        std::uintptr_t cursor{};if(!read.get(list+8,cursor))return false;bool attached=false;
        for(unsigned i=0;i<64&&cursor;++i){if(cursor==viewport){attached=true;break;}std::uintptr_t next{};if(!read.get(cursor+8,next)||next==cursor)return false;cursor=next;}
        if(!attached)return false;w={arena,viewport,stamp,generation};
        if(input_view&&(!read.pointer(input_view+8,value)||value!=c.map_node))return false;
        if(published&&(!read.pointer(base+published_root,root)||!read.pointer(root+0x10,value)||value!=request.ui_frame||
            !read.pointer(root+0x18,value)||value!=request.backend||!read.pointer(root+0xD0,value)||value!=view||
            !read.get(base+published_root,root2)||root2!=root))return false;
        std::uintptr_t other{};std::uint8_t other_active{};
        if(!read.get(app+0x35278,other)||(other&&(!read.get(other+0x20,other_active)||other_active)))return false;
        if(!read.pointer(app+0x35280,c.controller)||!read.get(c.controller,value)||value!=base+0x1D48EE0||
           !read.pointer(c.controller+0x28,value)||value!=app||!read.pointer(c.controller+0x1B8,c.client)||
           !read.pointer(c.client+0x47D4E0,c.world)||!read.pointer(app+0x690,c.manager)||
           !read.pointer(c.client+0x88,value)||value!=c.manager||
           !read.copy(c.manager+0x1192BE,c.selected.data(),3)||!read.copy(c.manager+0x10DF2E,c.loaded.data(),3))return false;
        return c.selected[2]==1&&c.selected[0]>=1&&c.selected[0]<=16&&c.selected[1]<=1&&
            c.loaded[0]==c.selected[0]&&c.loaded[1]==c.selected[1]&&(c.loaded[2]==2||c.loaded[2]==3);
    };
    Context first{},second{};Witness a{},b{};if(!capture(first,a)||!capture(second,b)||!(first==second)||!(a==b))return false;out=first;return true;
}
namespace {
std::mutex mutex;
Coordinator coordinator;
SourceRequest observed{};Frame latest{};std::uint64_t epoch{1};
Context last_context{};bool have_context{};
std::uintptr_t game_base{};std::uint32_t pid{};std::uint64_t birth{};
std::atomic_bool active{},pending{};
using ButtonQuery=std::uint32_t*(__fastcall*)(std::uintptr_t,std::uint32_t*,std::uint8_t,std::uint8_t,std::uint8_t);
using ProcessCommands=void(__fastcall*)(std::uintptr_t);
struct alignas(8) Packet {std::uint8_t kind{0x42};std::array<std::uint8_t,7>pad{};std::array<std::int64_t,3>xyz{};std::uint8_t valid{1};std::array<std::uint8_t,7>tail{};};
static_assert(sizeof(Packet)==40&&offsetof(Packet,xyz)==8&&offsetof(Packet,valid)==32);
using Dispatch=void(__fastcall*)(std::uintptr_t,const Packet*);
ButtonQuery query_button{};ProcessCommands process_commands{};Dispatch dispatch{};
std::array<void*,2> targets{};bool created{};
thread_local bool draining{};
void invalidate_locked()noexcept{coordinator.reset();pending=false;}
bool window_cursor(std::uintptr_t handle,Cursor&out)noexcept{
    out={};auto hwnd=reinterpret_cast<HWND>(handle);DWORD owner{};
    if(!hwnd||!IsWindow(hwnd)||!GetWindowThreadProcessId(hwnd,&owner)||owner!=pid||GetForegroundWindow()!=hwnd)return false;
    POINT point{};if(!GetCursorPos(&point)||!ScreenToClient(hwnd,&point))return false;
    out={static_cast<float>(point.x),static_cast<float>(point.y),true};return true;
}
bool invoke(const Context&context,const Request&request)noexcept{
    if(!active.load()||!draining||!dispatch)return false;
    Packet packet{};packet.xyz=request.xyz;
    __try {dispatch(context.controller,&packet);return true;}
    __except(EXCEPTION_EXECUTE_HANDLER){return false;}
}
bool write_consumed(std::uint32_t*result)noexcept{
    if(reinterpret_cast<std::uintptr_t>(result)&3)return false;
    __try {*result=0;return true;}__except(EXCEPTION_EXECUTE_HANDLER){return false;}
}
// Called after the original query. The original result/stack output is kept for
// every caller except the exact current WORLD-map right-button ownership path.
bool handle_button(std::uintptr_t caller,std::uintptr_t view,std::uint32_t*result,std::uint8_t button)noexcept{
    if(!active.load()||button!=2||caller!=game_base+0xD3C013||!result)return false;
    SourceRequest request{};TrackingHit hit{};bool have_hit{};
    {std::lock_guard lock(mutex);request=observed;request.epoch=epoch;if(auto*h=coordinator.hit()){hit=*h;have_hit=true;}}
    if(!request.ui_frame)return false;
    std::uintptr_t app_owner{};
    if(!own_copy(nullptr,request.ui_frame-0x10,&app_owner,8)||app_owner<0x468)return false;
    Context context{};if(!capture_context({nullptr,own_copy},game_base,request,app_owner-0x468,view,true,context))return false;
    Cursor cursor{};if(have_hit)window_cursor(hit.native_window,cursor);
    std::uint32_t status{};if(!own_copy(nullptr,reinterpret_cast<std::uintptr_t>(result),&status,4))return false;
    const auto now=GetTickCount64();bool consume{};
    {std::lock_guard lock(mutex);if(!active.load()||context.epoch!=epoch||!have_context||!(context==last_context))return false;
        auto next=coordinator;consume=next.button(status,context,cursor,now,pid,birth);
        if(consume&&!write_consumed(result))return false;
        coordinator=next;pending=coordinator.pending();}
    return consume;
}
std::uint32_t*__fastcall button_hook(std::uintptr_t view,std::uint32_t*out,std::uint8_t button,std::uint8_t mode,std::uint8_t mask){
    const auto caller=reinterpret_cast<std::uintptr_t>(_ReturnAddress());auto* result=query_button(view,out,button,mode,mask);
    if(result==out)handle_button(caller,view,result,button);return result;
}
void drain(std::uintptr_t app)noexcept{
    if(!active.load()||!pending.load())return;
    SourceRequest source{};Request preview{};
    {std::lock_guard lock(mutex);if(auto*p=coordinator.queued())preview=*p;else{pending=false;return;}
        source=observed;source.epoch=epoch;}
    Context context{};const bool valid=preview.context.app==app&&capture_context({nullptr,own_copy},game_base,source,app,0,false,context);
    Request request{};bool accepted{};
    {std::lock_guard lock(mutex);if(!valid||context.epoch!=epoch){invalidate_locked();}
        else accepted=coordinator.take(context,GetTickCount64(),request);pending=coordinator.pending();}
    if(!accepted){platform::log("tracking","Queued tracking command discarded: native map/world/hero context changed or expired");return;}
    // VOID native consumer: submitted means attempted, never proven allocation.
    platform::log("tracking",invoke(context,request)?"Tracking command submitted to native UI command consumer":"Tracking command discarded: native consumer unavailable");
}
void __fastcall commands_hook(std::uintptr_t app){
    process_commands(app);if(draining)return;draining=true;
    __try {drain(app);}__finally {draining=false;}
}
}
void observe_request(std::uintptr_t state,std::uintptr_t ui_frame,std::uintptr_t backend)noexcept{
    std::lock_guard lock(mutex);observed={state,ui_frame,backend,epoch};if(!state||!ui_frame||!backend)invalidate_locked();
}
void observe_frame(Frame&frame)noexcept{
    SourceRequest source{};{std::lock_guard lock(mutex);source=observed;source.epoch=epoch;}
    Context context{};bool valid=active.load()&&frame.map_open&&frame.projection_ready&&frame.world_ready&&
        capture_context({nullptr,own_copy},game_base,source,frame.application_address,0,false,context);
    std::lock_guard lock(mutex);
    valid=valid&&source.epoch==epoch&&source.state==observed.state&&source.ui_frame==observed.ui_frame&&source.backend==observed.backend;
    auto previous=last_context;previous.epoch=context.epoch;
    if(!frame.map_open||!frame.projection_ready||!frame.world_ready||
       frame.application_address!=latest.application_address||frame.ui_address!=latest.ui_address||frame.map_state_address!=latest.map_state_address||
       frame.world_guid!=latest.world_guid||frame.hero_guid!=latest.hero_guid||
       (valid&&have_context&&!(context==previous))){
        if(++epoch==0)++epoch;invalidate_locked();}
    if(valid){context.epoch=epoch;last_context=context;have_context=true;}
    frame.tracking_generation=valid?epoch:0;latest=frame;observed.epoch=epoch;
}
bool start(std::uintptr_t base)noexcept{
    if(active.load())return true;if(!base)return false;
    for(auto&s:tracking_profile::spans){std::array<std::uint8_t,192> actual{};
        if(s.size>actual.size()||!own_copy(nullptr,base+s.rva,actual.data(),s.size)||std::memcmp(actual.data(),s.bytes,s.size))return false;}
    FILETIME created_at{},exited{},kernel{},user{};if(!GetProcessTimes(GetCurrentProcess(),&created_at,&exited,&kernel,&user))return false;
    game_base=base;pid=GetCurrentProcessId();birth=(std::uint64_t(created_at.dwHighDateTime)<<32)|created_at.dwLowDateTime;
    dispatch=reinterpret_cast<Dispatch>(base+0x8546D0);
    const auto initialized=MH_Initialize();if(initialized!=MH_OK&&initialized!=MH_ERROR_ALREADY_INITIALIZED)return false;
    if(!created){targets={reinterpret_cast<void*>(base+0xA3A670),reinterpret_cast<void*>(base+0x846830)};
        if(MH_CreateHook(targets[0],reinterpret_cast<void*>(button_hook),reinterpret_cast<void**>(&query_button))!=MH_OK)return false;
        if(MH_CreateHook(targets[1],reinterpret_cast<void*>(commands_hook),reinterpret_cast<void**>(&process_commands))!=MH_OK){MH_RemoveHook(targets[0]);return false;}
        created=true;}
    if(MH_EnableHook(targets[0])!=MH_OK||MH_EnableHook(targets[1])!=MH_OK){for(auto*t:targets)MH_DisableHook(t);return false;}
    active=true;platform::log("tracking","Native world-map RMB command bridge enabled");return true;
}
void stop()noexcept{active=false;if(created)for(auto*t:targets)MH_DisableHook(t);std::lock_guard lock(mutex);invalidate_locked();observed={};latest={};last_context={};have_context=false;}
} // namespace rs::game::tracking_detail

namespace rs::game {
bool publish_tracking_hit(const TrackingHit&hit)noexcept{
    using namespace tracking_detail;if(!active.load()){clear_tracking_hit();return false;}
    Cursor ignored{};if(!window_cursor(hit.native_window,ignored)){clear_tracking_hit();return false;}
    const auto now=GetTickCount64();std::lock_guard lock(mutex);
    const auto incompatible=[](const auto&a,const auto&b)noexcept{bool aa=false,bb=false;for(auto x:a)aa=aa||x;for(auto x:b)bb=bb||x;return aa&&bb&&a!=b;};
    if(!active.load()||!latest.map_open||!latest.projection_ready||!latest.world_ready||!age(now,latest.sampled_at_ms,hover_ttl)||
       hit.scope.tracking_generation!=epoch||hit.scope.tracking_generation!=latest.tracking_generation||
       incompatible(hit.scope.world_guid,latest.world_guid)||incompatible(hit.scope.hero_guid,latest.hero_guid)||
       latest.application_address!=hit.scope.application_address||latest.ui_address!=hit.scope.ui_address||latest.map_state_address!=hit.scope.map_state_address){coordinator.clear_hit();return false;}
    const bool result=coordinator.publish(hit,now,pid,birth,epoch);pending=coordinator.pending();return result;
}
void clear_tracking_hit()noexcept{using namespace tracking_detail;std::lock_guard lock(mutex);coordinator.clear_hit();}
}
