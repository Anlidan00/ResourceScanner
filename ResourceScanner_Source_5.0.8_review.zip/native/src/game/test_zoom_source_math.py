"""Offline emulator of exact cached GAME zoom clamp, never shipped code."""
from pathlib import Path
import sys,struct,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT.parent/'binary/vendor'))
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64
from unicorn.x86_const import *
GAME=ROOT.parent/'terrain/private/enshrouded.exe'
def main():
    pe=pefile.PE(str(GAME));checks=0;cases=[]
    def single(base,extra,delta,previous):
        uc=Uc(UC_ARCH_X86,UC_MODE_64)
        for rva in [0xD80000,0x150A000]:
            uc.mem_map(base+rva,0x10000);uc.mem_write(base+rva,pe.get_data(rva,0x10000))
        state=0x40000000;uc.mem_map(state,0x10000)
        levels=[16.,8.,4.,2.]+([.25]if extra else[])
        uc.mem_write(state+0x40,struct.pack('<5f',*(levels+[0.]*(5-len(levels)))))
        uc.mem_write(state+0x54,bytes([len(levels)]));uc.mem_write(state+0x58,struct.pack('<f',.2))
        uc.mem_write(state+0x258,struct.pack('<f',1.));uc.mem_write(state+0x10,struct.pack('<f',previous))
        uc.mem_write(state+0x400,struct.pack('<q',delta));uc.reg_write(UC_X86_REG_RSI,state);uc.reg_write(UC_X86_REG_RAX,state+0x400)
        uc.reg_write(UC_X86_REG_XMM11,int.from_bytes(struct.pack('<f',1.)+bytes(12),'little'))
        value=pe.get_data(0x13B5670,8);uc.reg_write(UC_X86_REG_XMM13,int.from_bytes(value+bytes(8),'little'))
        uc.emu_start(base+0xD802BE,base+0xD80324,count=64)
        return struct.unpack('<f',uc.mem_read(state+0x10,4))[0]
    for base in [0x140000000,0x7FF600000000]:
        for delta in [-1000000000,-50000000,-10000000,-1000000,0,1000000,10000000,50000000,1000000000]:
            for previous in [.05,.4,.8,3.2]:
                native=single(base,False,delta,previous);extended=single(base,True,delta,previous)
                assert .4-1e-7<=native<=3.2+1e-6
                assert .05-1e-7<=extended<=3.2+1e-6
                if native>.400001:assert abs(native-extended)<1e-6
                if delta<=-50000000:assert abs(native-.4)<1e-7 and abs(extended-.05)<1e-7
                checks+=4;cases.append(dict(base=hex(base),delta=delta,previous=previous,native=native,extended=extended))
    out=dict(result='PASS_ACTUAL_GAME_ZOOM_CLAMP_TWO_ASLR_BASES',checks=checks,cases=cases,
        source_sha256=hashlib.sha256(GAME.read_bytes()).hexdigest(),source_range='D802BE..D80324',
        no_original_mod_inputs=True,no_game_access=True,
        scope_order='Primary game C1EDA9->C201B0 and C1EDB1->D7FFD0 occur before C1E810 returns; own compiled SEH finally guards that entire call.',
        limitations=['Pure game clamp instructions executed offline; this is not a real-game wheel test.'])
    target=ROOT/'diagnostics/ZOOM_MATH_REVIEW.json';target.write_text(json.dumps(out,indent=2),encoding='utf8');print(out['result'],checks)
if __name__=='__main__':main()
