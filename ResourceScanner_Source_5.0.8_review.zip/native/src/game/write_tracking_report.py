"""Bind our new tracking source/fixtures; never reads a running game."""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'diagnostics/tracking15_unit_v3'
FILES=['CMakeLists.txt','include/rs/game/frame.hpp','include/rs/game/tracking.hpp',
       'src/game/adapter.cpp','src/game/tracking.cpp','src/game/tracking_logic.hpp',
       'src/game/tracking_internal.hpp','src/game/tracking_profile.hpp','src/game/TRACKING_PROFILE.json',
       'src/game/make_tracking_profile.py','src/game/tracking_smoke.cpp',
       'src/game/test_tracking_game_route.py','src/game/write_tracking_report.py']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)
def sources():return {name:sha(ROOT/name)for name in FILES}
def main():
    OUT.mkdir(exist_ok=True)
    if '--snapshot-only'in sys.argv:
        (OUT/'PREBUILD.json').write_text(json.dumps(sources(),indent=2),encoding='utf8');return
    before=json.loads((OUT/'PREBUILD.json').read_text('utf8'));assert before==sources(),'Source changed across fixture build'
    ancestor=json.loads((ROOT/'build_final14/BUILD_RECEIPT.json').read_text('utf8'))['source_files']
    adapter=(ROOT/'src/game/adapter.cpp').read_text('utf8')
    reverse=adapter.replace('#include "tracking_internal.hpp"\n','')
    reverse=reverse.replace('{std::lock_guard lock(request_mutex);requested=next;}\n        tracking_detail::observe_request(next.state,next.ui_context_frame,next.backend);','std::lock_guard lock(request_mutex);requested=next;')
    reverse=reverse.replace('    tracking_detail::observe_frame(frame);\n','')
    reverse=reverse.replace('\n        if(!tracking_detail::start(game_base))platform::log("tracking","Optional source profile unavailable; native map RMB retained");','')
    reverse=reverse.replace('\n    if(!tracking_detail::start(game_base))platform::log("tracking","Optional source profile unavailable; native map RMB retained");','')
    reverse=reverse.replace('stop_adapter()noexcept{tracking_detail::stop();','stop_adapter()noexcept{')
    assert hashlib.sha256(reverse.encode()).hexdigest()==ancestor['src/game/adapter.cpp'],'Unexpected base-adapter delta'
    frame=(ROOT/'include/rs/game/frame.hpp').read_text('utf8')
    frame=frame.replace('    // Native-only lifetime token copied into a rendered tracking hit. An old\n    // render may never acquire a new map lifetime merely by reusing addresses.\n    std::uint64_t tracking_generation{};\n','')
    assert hashlib.sha256(frame.encode()).hexdigest()==ancestor['include/rs/game/frame.hpp'],'Unexpected Frame prefix delta'
    unchanged={}
    for name,wanted in ancestor.items():
        if name in ['CMakeLists.txt','include/rs/game/frame.hpp','src/game/adapter.cpp','src/ui.cpp']:continue
        assert sha(ROOT/name)==wanted,name
        unchanged[name]=wanted
    unit=subprocess.run([str(OUT/'tracking_smoke.exe')],capture_output=True,text=True,check=True)
    assert 'PASS tracking production-host 169 assertions'in unit.stdout,unit.stdout
    route=ROOT/'diagnostics/waypoint15/GAME_COMMAND_DRAIN_ROUTE_REVIEW.json'
    primary=json.loads(route.read_text('utf8'));assert primary['checks']==152
    report=dict(result='PASS_OWN_TRACKING_SOURCE_AND_PRODUCTION_HOST_TARGETED_TESTS',
        assertions=169,primary_game_instruction_assertions=152,no_game_access=True,no_original_mod_inputs=True,
        core_build_pending=True,source_files=before,source_unchanged_during_build=True,
        unit=dict(executable=ref(OUT/'tracking_smoke.exe'),stdout=unit.stdout.strip(),build_log=ref(OUT/'build.log')),
        adapter_compilation=dict(object=ref(OUT/'adapter.obj'),log=ref(OUT/'adapter_build.log')),
        primary_route=ref(route),typed_profile=ref(ROOT/'src/game/TRACKING_PROFILE.json'),
        base_adapter_reverse_exact=True,frame_prefix_reverse_exact=True,
        superseded_source_review=ref(ROOT/'diagnostics/tracking15_unit_v2/SOURCE_FREEZE.json'),
        unchanged_ancestor_native_sources=unchanged,
        covered=['finite fullXYZ and explicit flag1; real0 allowed, unavailable0 rejected',
        'native SSE Q32 equivalence, signed primary Q16 source heights, no origin or Z inversion',
        'fresh process/birth/map/context/native-only generation; late old render cannot acquire new lifetime',
        'same-address world or loaded/selected hero changes renew native lifetime; missing context does not mint a valid token',
        'input context must still equal the source Context that minted the hit lifetime, even before the next commit',
        'paint-derived two-area hit union, own HWND/foreground/current cursor, HUD exclusion',
        'RMB down/hold/release ownership, left/nonmarker passthrough, queue full',
        'result suppression must succeed before request/gesture commit; failed release preserves prior ownership',
        'native command-thread dispatch only; VOID refusal/structured fault has no fallback or claimed success'],
        boundaries=['No game was launched, attached or changed by this fixture.',
                    'Input state and native controller consumer are inert providers in the production-host test.',
                    'The separate source fixture executes actual cached GAME query/controller instructions at two bases.',
                    'Final reviewed height data, integrated Core build and Root actual-game gate are separate.'])
    (OUT/'TRACKING_OWNER_REVIEW.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    freeze=dict(result='FROZEN_OWN_TRACKING_SOURCE_FOR_INDEPENDENT_REVIEW',source_files=before,
        owner_report=ref(OUT/'TRACKING_OWNER_REVIEW.json'),public_header=ref(ROOT/'include/rs/game/tracking.hpp'))
    (OUT/'SOURCE_FREEZE.json').write_text(json.dumps(freeze,indent=2),encoding='utf8')
    print(report['result'],sha(OUT/'TRACKING_OWNER_REVIEW.json'))
if __name__=='__main__':main()
