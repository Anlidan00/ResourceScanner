#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <cmath>

namespace rs::game::world_zoom {
// Temporary edits to this call's own native MapState only. The 8-byte compare
// exchange publishes the fifth level and count together; failed/later edits
// cannot be overwritten by restoration. No executable bytes are changed here.
struct Memory {
    void* user{};
    bool (*read)(void*,std::uintptr_t,void*,std::size_t) noexcept{};
    bool (*exchange)(void*,std::uintptr_t,std::uint64_t,std::uint64_t) noexcept{};
};
struct Scope {
    Memory memory{};
    std::uintptr_t state{};
    std::array<std::uint8_t,16> original_levels{};
    std::uint64_t before{},during{};
    bool changed{};
};
inline constexpr std::uint64_t state_key=0x236F8649B9BF0F5BULL;

inline bool identity(const Memory& m,std::uintptr_t state) noexcept {
    if(!m.read||!m.exchange||state<0x10060||state>0x00007FFFFFFEFFFFULL||(state&7))return false;
    std::uint64_t key{};std::uint32_t size{};
    return m.read(m.user,state-0x28,&key,sizeof(key))&&key==state_key&&
        m.read(m.user,state-0x18,&size,sizeof(size))&&size==0x260;
}
inline bool extend(Scope& scope,std::uintptr_t state) noexcept {
    if(scope.changed||!identity(scope.memory,state))return false;
    std::array<std::uint8_t,32> raw{};
    if(!scope.memory.read(scope.memory.user,state+0x38,raw.data(),raw.size()))return false;
    float width{},height{};std::array<float,4> levels{};std::uint64_t tail{};
    std::memcpy(&width,raw.data(),4);std::memcpy(&height,raw.data()+4,4);
    std::memcpy(levels.data(),raw.data()+8,16);std::memcpy(&tail,raw.data()+24,8);
    if(!std::isfinite(width)||!std::isfinite(height)||width<=0||height<=0||width>1e6f||height>1e6f||raw[28]!=4)return false;
    for(std::size_t i=0;i<levels.size();++i)
        if(!std::isfinite(levels[i])||levels[i]<=0||levels[i]>1024||(i&&levels[i]>=levels[i-1]))return false;
    const float extra_level=levels.back()*.5f;
    if(!std::isnormal(extra_level)||extra_level>=levels.back()||extra_level*2!=levels.back())return false;
    auto extended=tail;std::uint32_t bits{};std::memcpy(&bits,&extra_level,4);
    extended=(extended&0xFFFFFF0000000000ULL)|std::uint64_t(bits)|(std::uint64_t{5}<<32);
    std::array<std::uint8_t,32> again{};
    if(!identity(scope.memory,state)||!scope.memory.read(scope.memory.user,state+0x38,again.data(),again.size())||again!=raw||
        !scope.memory.exchange(scope.memory.user,state+0x50,tail,extended))return false;
    scope.state=state;scope.before=tail;scope.during=extended;scope.changed=true;
    std::memcpy(scope.original_levels.data(),levels.data(),16);return true;
}
inline bool restore(Scope& scope) noexcept {
    if(!scope.changed)return true;
    scope.changed=false;
    if(!identity(scope.memory,scope.state))return false;
    std::array<std::uint8_t,16> levels{};
    if(!scope.memory.read(scope.memory.user,scope.state+0x40,levels.data(),levels.size())||levels!=scope.original_levels)return false;
    return scope.memory.exchange(scope.memory.user,scope.state+0x50,scope.during,scope.before);
}
void note_state(std::uintptr_t state) noexcept;
void note_requested_state(std::uintptr_t state) noexcept;
using RenderCall=std::uint8_t(*)(std::uintptr_t);
std::uint8_t call(const Memory&,RenderCall,std::uintptr_t element);
bool start(std::uintptr_t executable_base) noexcept;
// Explicit startup policy boundary; false never installs/enables zoom hooks.
bool start(std::uintptr_t executable_base,bool extra_zoom_enabled) noexcept;
bool settings_enabled(const wchar_t* absolute_ini_path) noexcept;
void stop() noexcept;
} // namespace rs::game::world_zoom
