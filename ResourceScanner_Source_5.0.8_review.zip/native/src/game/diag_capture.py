"""Bounded read-only diagnostic for the explicitly authorized Root test PID."""
import argparse,ctypes as C,ctypes.wintypes as W,hashlib,json,struct,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--birth',type=int,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--seed',type=Path);p.add_argument('--all-viewports',action='store_true');a=p.parse_args()
k=C.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[W.DWORD,W.BOOL,W.DWORD];k.OpenProcess.restype=W.HANDLE
k.ReadProcessMemory.argtypes=[W.HANDLE,C.c_void_p,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t)];k.ReadProcessMemory.restype=W.BOOL
k.GetProcessTimes.argtypes=[W.HANDLE,C.POINTER(W.FILETIME),C.POINTER(W.FILETIME),C.POINTER(W.FILETIME),C.POINTER(W.FILETIME)]
k.CreateToolhelp32Snapshot.argtypes=[W.DWORD,W.DWORD];k.CreateToolhelp32Snapshot.restype=W.HANDLE
k.CloseHandle.argtypes=[W.HANDLE]
class Module(C.Structure):
    _fields_=[('dwSize',W.DWORD),('th32ModuleID',W.DWORD),('th32ProcessID',W.DWORD),('GlblcntUsage',W.DWORD),('ProccntUsage',W.DWORD),('modBaseAddr',C.c_void_p),('modBaseSize',W.DWORD),('hModule',W.HMODULE),('szModule',W.WCHAR*256),('szExePath',W.WCHAR*260)]
k.Module32FirstW.argtypes=[W.HANDLE,C.POINTER(Module)];k.Module32NextW.argtypes=[W.HANDLE,C.POINTER(Module)]
h=k.OpenProcess(0x1010,False,a.pid)
if not h:raise OSError(C.get_last_error(),'Read-only OpenProcess')
snap=None
try:
    ft=[W.FILETIME()for _ in range(4)]
    assert k.GetProcessTimes(h,*[C.byref(x)for x in ft]);birth=ft[0].dwLowDateTime|(ft[0].dwHighDateTime<<32);assert birth==a.birth,'PID reused'
    snap=k.CreateToolhelp32Snapshot(0x18,a.pid);assert snap not in [None,C.c_void_p(-1).value]
    m=Module();m.dwSize=C.sizeof(m);modules=[];ok=k.Module32FirstW(snap,C.byref(m))
    while ok:
        modules.append(dict(name=m.szModule,path=m.szExePath,base=m.modBaseAddr,size=m.modBaseSize));ok=k.Module32NextW(snap,C.byref(m))
    core=next(x for x in modules if x['name'].lower()=='resourcescannercore.dll');exe=next(x for x in modules if x['name'].lower()=='enshrouded.exe')
    core_sha=hashlib.sha256(Path(core['path']).read_bytes()).hexdigest()
    request_rva={'f000f3789b69db9c7be60bfd4052dc710ab338685836d90ef28228156ad3a033':0x116160,
        'f4a4d127236aa9ea0d32cd529831417b759665ba2ce552ae2100be91b29bb7d4':0x13c998}.get(core_sha)
    assert request_rva,'Only frozen explicitly authorized native diagnostic layouts are accepted'
    assert hashlib.sha256(Path(exe['path']).read_bytes()).hexdigest()=='d64966e23b1a458ee6f147bcbceac0b577fa7e39a212f371287d8cc119817882'
    records={};used=0;prefetched=[]
    def read(address,size):
        global used
        assert 0x10000<=address<0x7ffffffe0000 and 0<size<=0x10000 and used+size<=2*1024*1024
        for start,raw in prefetched:
            if start<=address and address+size<=start+len(raw):return raw[address-start:address-start+size]
        value=C.create_string_buffer(size);done=C.c_size_t();used+=size
        if not k.ReadProcessMemory(h,address,value,size,C.byref(done))or done.value!=size:raise OSError(C.get_last_error(),hex(address))
        raw=value.raw;records[f'{address:x}:{size:x}']=raw.hex();return raw
    def u64(p):return struct.unpack('<Q',read(p,8))[0]
    def u32(p):return struct.unpack('<I',read(p,4))[0]
    # Own frozen Core07 RIP stores: observe_state3D63B/642/649 ->116160..170.
    requested=struct.unpack('<3Q',read(core['base']+request_rva,24));state,ui_frame,builder=requested
    report=dict(pid=a.pid,birth=birth,core=core,exe=exe,requested=dict(state=state,ui_context_frame=ui_frame,backend=builder))
    if min(requested)<0x10000:
        report['failure']='requested map context is empty'
    else:
        ui=ui_frame-16;commit=u64(ui+0xe90);canvas=u64(builder+16);element=u64(state+24)
        arena=u64(builder);app=u64(ui)-0x468;u64(ui+0x68);u64(app+0x5b0);loca=u64(app+0x35290);u32(loca+0xd8);u32(ui+0xf5c)
        view=u64(ui_frame+0x48);state_owner=u64(view);game_ui=u64(state_owner+0x38);read(state_owner+0xc,1);read(game_ui+0x1cd8,1);read(view+0x31e70,1)
        read(canvas,0x20);viewport_records=[];at=u64(canvas+8)
        while at:
            assert len(viewport_records)<64;viewport_records.append(dict(address=at,raw_hex=read(at,0x90).hex()));at=u64(at+8)
        scalar=dict(ui=ui,commit_root=commit,canvas=canvas,map_element=element,
            state_time=u64(state),ui_time=u64(ui_frame+8),state_stamp=u64(state-0x38),canvas_stamp=u64(canvas),first_viewport=u64(canvas+8))
        read(state-0x60,0x2c0);read(ui_frame,0x70);read(builder,0x80)
        if a.seed:
            seed=json.loads(a.seed.read_text());assert seed['pid']==a.pid and seed['birth']==birth and seed['requested']==report['requested']
            low=min(n['address']for n in seed['nodes'])&~0xfff;high=(max(n['address']for n in seed['nodes'])+0x1127)&~0xfff
            assert high-low<=1024*1024
            # Copy each bounded arena page span once instead of 243 individual
            # RPM calls crossing a 60Hz commit boundary. No cached bytes reused.
            spans=[]
            for at in range(low,high,0x10000):spans.append((at,read(at,min(0x10000,high-at))))
            prefetched.extend(spans)
        def node(address):
            raw=read(address,0x128);q=lambda n:struct.unpack_from('<Q',raw,n)[0]
            return dict(address=address,parent=q(0),previous=q(8),next=q(16),first=q(24),last=q(32),count=q(40),literal=q(56),frame=q(72),viewport=q(80),generation=struct.unpack_from('<I',raw,104)[0],rect=struct.unpack_from('<4f',raw,0x114))
        map_node=node(element);vp=map_node['viewport'];vr=read(vp,0x90);root=u64(vp+80)
        scalar.update(viewport=vp,viewport_frame=struct.unpack_from('<Q',vr,16)[0],viewport_backend=struct.unpack_from('<Q',vr,24)[0],viewport_generation=struct.unpack_from('<I',vr,128)[0],scale_origin=struct.unpack_from('<3f',vr,32),viewport_root=root)
        report.update(scalar=scalar,map_node=map_node,arena_owner=arena,application=app,viewport_records=viewport_records)
        roots=[root]
        if a.all_viewports:roots=[struct.unpack_from('<Q',bytes.fromhex(v['raw_hex']),0x50)[0]for v in viewport_records];roots=[v for v in roots if v>=0x10000]
        nodes=[];todo=list(roots);seen=set()
        while todo:
            at=todo.pop();assert at not in seen and len(seen)<2048;seen.add(at);n=node(at);nodes.append(n)
            child=n['first'];count=0
            while child:
                assert count<2048;todo.append(child);child=u64(child+16);count+=1
            assert count==n['count']
        report['nodes']=nodes
        report['after']=dict(requested=struct.unpack('<3Q',read(core['base']+request_rva,24)),state_time=u64(state),ui_time=u64(ui_frame+8),state_stamp=u64(state-0x38),canvas_stamp=u64(canvas))
    report.update(bytes_read=used,memory=records)
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in report.items()if k not in ['nodes','memory']},indent=2))
finally:
    if snap:k.CloseHandle(snap)
    k.CloseHandle(h)
