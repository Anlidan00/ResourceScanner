"""Bind the separate 5.0.2 source build; never alter previous receipts."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final12'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)
def main():
    parent_path=ROOT/'build_final11/NATIVE_QA_SUMMARY.json';parent=json.loads(parent_path.read_text())
    old=json.loads((ROOT/'build_final11/BUILD_RECEIPT.json').read_text());receipt=json.loads((BUILD/'BUILD_RECEIPT.json').read_text())
    assert receipt['version']=='5.0.2' and len(receipt['tests'])==14
    for name in ['src/platform/vulkan_render.cpp','src/platform/vulkan_dispatch.hpp','src/platform/vulkan_proxy.cpp','src/platform/shared_frame.cpp','src/game/state.cpp','include/rs/game/frame.hpp','src/game/hud_blockers.hpp','src/platform/font.cpp']:
        assert receipt['source_files'][name]==old['source_files'][name],name
    for name in ['src/platform/lifecycle.cpp','src/platform/paths.cpp']:
        assert hashlib.sha256((ROOT/name).read_bytes().replace(b'5.0.2',b'5.0.1')).hexdigest()==old['source_files'][name]
    unit=json.loads((ROOT/'diagnostics/WORLD_ZOOM_UNIT_REVIEW.json').read_text())
    for name in ['src/game/zoom_out.cpp','src/game/zoom_out.hpp','src/game/zoom_profile.hpp','src/game/zoom_out_smoke.cpp','src/game/adapter.cpp']:
        assert receipt['source_files'][name]==unit['source_files'][name],name
    assert receipt['source_files']['src/ui.cpp']=='2437829b59828f5b39c52b91fa0d8fd1aefdfdba41f0e2d98aa64e482047809b'
    assert receipt['source_files']['include/rs/method_icons.hpp']=='353c9799b0ed6b5c5bff40029d11712b14f99742f34b888c123a1eb56a0fb233'
    for item in parent['input_bindings'].values():
        if Path(item['path'])!=ROOT/'src/ui.cpp':assert ref(Path(item['path']))['sha256']==item['sha256']
    run=subprocess.run([str(BUILD/'rs_game_adapter_smoke.exe'),str(ROOT/'diagnostics/map09_44496_all_bulk.json')],capture_output=True,text=True,timeout=15);assert run.returncode==0
    zoom=subprocess.run([str(BUILD/'rs_world_zoom_smoke.exe')],capture_output=True,text=True,timeout=15);assert zoom.returncode==0
    proof=dict(result='PASS_5_0_2_NATIVE_SOURCE_BUILD_UI_AND_SCOPED_WORLD_ZOOM',receipt=ref(BUILD/'BUILD_RECEIPT.json'),parent=ref(parent_path),
        source_files=receipt['source_files'],normal_fixture_count=14,source_before_after_exact=True,
        actual_tree=dict(exit_code=run.returncode,stdout=run.stdout,source=ref(ROOT/'diagnostics/map09_44496_all_bulk.json')),
        zoom_unit=dict(exit_code=zoom.returncode,stdout=zoom.stdout,source_receipt=ref(ROOT/'diagnostics/WORLD_ZOOM_UNIT_REVIEW.json')),
        zoom_source=ref(ROOT/'src/game/ZOOM_SOURCE.json'),zoom_native_math=ref(ROOT/'diagnostics/ZOOM_MATH_REVIEW.json'),
        zoom_projection=ref(BUILD/'ZOOM_PROJECTION_REVIEW.json'),
        approved_method_assets=ref(ROOT/'assets/methods/APPROVED_ASSET_SOURCES.json'),
        method_generator=ref(ROOT/'assets/methods/regenerate_approved.cjs'),
        method_header=ref(ROOT/'include/rs/method_icons.hpp'),
        source_carry=['Exact Vulkan09 lifetime/PFN dispatch and proxy07 source.','Exact Map08/11 projection/lifecycle/blocker/IPC source apart from optional zoom observer registration.',
                      'Exact6OFLfont bytes/fontloader. NewUI uses existing profiles at its own scoped sizes.'],
        native_owner_no_game_access=True,exact_core_game_gate_pending_root=True,installer_payload_permitted=False)
    proof_path=BUILD/'NATIVE_SOURCE_CARRY.json';proof_path.write_text(json.dumps(proof,indent=2),encoding='utf8')
    bindings=dict(parent['input_bindings']);bindings['ui_source']=ref(ROOT/'src/ui.cpp');bindings['method_icons']=ref(ROOT/'include/rs/method_icons.hpp');bindings['method_assets']=ref(ROOT/'assets/methods/APPROVED_ASSET_SOURCES.json');bindings['world_zoom_source']=ref(ROOT/'src/game/ZOOM_SOURCE.json')
    summary=dict(parent);summary.update(result='PASS_5_0_2_NATIVE_OFFLINE_PENDING_ROOT_GAME',version='5.0.2',source_files=receipt['source_files'],
        input_bindings=bindings,game_tests_prohibited_by_user=False,no_game_tests=True,root_owned_game_test_pending=True,
        reports=[ref(BUILD/'BUILD_RECEIPT.json'),ref(proof_path),ref(ROOT/'qa/hud_blockers11/REPORT.json'),ref(parent_path)],
        modules=[dict(role='core',installed_path='ResourceScanner/ResourceScannerCore.dll',**ref(BUILD/'ResourceScannerCore.dll')),
                 dict(role='loader',installed_path='vulkan-1.dll',**ref(ROOT/'build_final07/vulkan-1.dll'))],
        validation_limits=['No native-owner game process access/control/install operations for this revision. This exact Core12 still requires Root game observation.',
            'Source and own hidden-Vulkan-host fixtures validate startup/render/font/texture/resize/input routes; they do not replace a game test.',
            'Optional world zoom uses compatibility-guarded native instance data for the duration of WORLD renderer only, with C++/SEH restoration; future incompatible layouts retain native zoom.',
            'No full GPU pixel-equivalence, arbitrary Thai IME shaping or multiplayer guarantee is claimed.'],
        boundaries=['Restored method alpha artwork/roundedUI and tooltip-order fixes are Root-owned UI changes, exact UI2437829b source bound.',
            'One extra world-map level0.25, all original4levels preserved; no minimap/globalcamera/persistentgameconfig writes; Insert-independent.',
            'Proxy07c49 retained unchanged; the build12 proxy is not the package module.',
            'Prior capture UI-clock overlap limitation remains disclosed; actual zoom/math and derived geometry fixtures have explicit scopes.',
            'Separate independent UI/zoom review and Root game/package admission remain required.'],
        installer_payload_permitted=False,release_ready=False)
    path=BUILD/'NATIVE_QA_SUMMARY.json';path.write_text(json.dumps(summary,indent=2),encoding='utf8');print(summary['result'],sha(path),sha(BUILD/'ResourceScannerCore.dll'))
if __name__=='__main__':main()
