"""Feature-only geometry mutations of the immutable Root-owned capture."""
from pathlib import Path
import argparse,copy,hashlib,json,struct,subprocess
ROOT=Path(__file__).resolve().parents[2]
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--build',default='build_zoom_unit12');args=parser.parse_args()
    source=ROOT/'diagnostics/map09_44496_all_bulk.json';original=json.loads(source.read_text())
    executable=ROOT/args.build/'rs_game_adapter_smoke.exe';cases=[]
    for active in [False,True]:
        for center in [(960.,540.),(-4000.,6000.)]:
            j=copy.deepcopy(original);state=j['requested']['state']
            image=next(n for n in j['nodes']if n['literal']==0x3F267F93B50D2258)
            width=height=512.;image['rect']=[center[0]-width/2,center[1]-height/2,width,height]
            patches=[(image['address']+0x114,struct.pack('<4f',*image['rect']))]
            if active:patches.append((state+0x50,struct.pack('<fB',.25,5)))
            touched=0
            for key,value in list(j['memory'].items()):
                start=int(key.split(':')[0],16);raw=bytearray.fromhex(value)
                for address,data in patches:
                    left=max(start,address);right=min(start+len(raw),address+len(data))
                    if right>left:raw[left-start:right-start]=data[left-address:right-address];touched+=1
                j['memory'][key]=raw.hex()
            assert touched>=len(patches)
            label=f'zoom_projection_{int(active)}_{int(center[0])}.json';target=ROOT/'diagnostics'/label
            target.write_text(json.dumps(j,separators=(',',':')),encoding='utf8')
            run=subprocess.run([str(executable),str(target)],capture_output=True,text=True,timeout=10)
            assert run.returncode==0,(active,center,run.stdout)
            cases.append(dict(active_fifth_count=active,center=center,exit_code=run.returncode,stdout=run.stdout,
                derived_capture_sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
    out=dict(result='PASS_EXTRA_ZOOM_GEOMETRY_CURRENT_ADAPTER_FLAGS15',parent_capture_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        current_adapter_sha256=hashlib.sha256((ROOT/'src/game/adapter.cpp').read_bytes()).hexdigest(),
        fixture_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),cases=cases,
        scope='Explicit derived geometry/count mutations only. Original279-node capture remains unchanged. Actual game wheel/fit remains Root gate.')
    target=ROOT/args.build/'ZOOM_PROJECTION_REVIEW.json';target.write_text(json.dumps(out,indent=2),encoding='utf8');print(out['result'],len(cases))
if __name__=='__main__':main()
