"""5.0.3 exact cached-GAME clamp with dynamic half-native final level."""
from pathlib import Path
import argparse,sys,struct,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT.parent/'binary/vendor'))
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64
from unicorn.x86_const import *
GAME=ROOT.parent/'terrain/private/enshrouded.exe'
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--build',default='build_final14');args=parser.parse_args()
    pe=pefile.PE(str(GAME));checks=0;cases=[]
    def single(base,levels,extra,delta,previous):
        uc=Uc(UC_ARCH_X86,UC_MODE_64)
        for rva in [0xD80000,0x150A000]:
            uc.mem_map(base+rva,0x10000);uc.mem_write(base+rva,pe.get_data(rva,0x10000))
        state=0x40000000;uc.mem_map(state,0x10000);all_levels=levels+([levels[-1]*.5]if extra else[])
        uc.mem_write(state+0x40,struct.pack('<5f',*(all_levels+[0.]*(5-len(all_levels)))))
        uc.mem_write(state+0x54,bytes([len(all_levels)]));uc.mem_write(state+0x58,struct.pack('<f',.2))
        uc.mem_write(state+0x258,struct.pack('<f',1.));uc.mem_write(state+0x10,struct.pack('<f',previous))
        uc.mem_write(state+0x400,struct.pack('<q',delta));uc.reg_write(UC_X86_REG_RSI,state);uc.reg_write(UC_X86_REG_RAX,state+0x400)
        uc.reg_write(UC_X86_REG_XMM11,int.from_bytes(struct.pack('<f',1.)+bytes(12),'little'))
        uc.reg_write(UC_X86_REG_XMM13,int.from_bytes(pe.get_data(0x13B5670,8)+bytes(8),'little'))
        uc.emu_start(base+0xD802BE,base+0xD80324,count=64)
        return struct.unpack('<f',uc.mem_read(state+0x10,4))[0]
    for base in [0x140000000,0x7FF600000000]:
        for levels in [[16.,8.,4.,2.],[8.,4.,2.,1.],[2.,1.,.5,.25],[32.,16.,8.,4.]]:
            low=levels[-1]*.2;high=levels[0]*.2
            for delta in [-1000000000,-50000000,-1000000,0,1000000,1000000000]:
                for previous in [low*.5,low,low*2,high]:
                    native=single(base,levels,False,delta,previous);extended=single(base,levels,True,delta,previous)
                    epsilon=max(high*1e-6,1e-8)
                    assert low-epsilon<=native<=high+epsilon
                    assert low*.5-epsilon<=extended<=high+epsilon
                    if native>low+epsilon:assert abs(native-extended)<epsilon
                    if delta<=-50000000:assert abs(native/extended-2)<1e-6
                    checks+=4;cases.append(dict(base=hex(base),levels=levels,delta=delta,previous=previous,native=native,extended=extended))
    out=dict(result='PASS_ACTUAL_GAME_DYNAMIC_EXACT_2X_ZOOM_CLAMP_TWO_ASLR_BASES',checks=checks,cases=cases,
        source_sha256=hashlib.sha256(GAME.read_bytes()).hexdigest(),source_range='D802BE..D80324',
        no_original_mod_inputs=True,no_game_access=True,
        limitations=['Actual cached-game clamp instructions executed offline; no new real-game wheel test.'])
    target=ROOT/args.build/'ZOOM_2X_MATH_REVIEW.json';target.write_text(json.dumps(out,indent=2),encoding='utf8');print(out['result'],checks)
if __name__=='__main__':main()
