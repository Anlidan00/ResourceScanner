"""UI-only 5.0.2 build, with explicitly inherited native fixture evidence."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final13'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size)
def main():
    parent_path=ROOT/'build_final12/NATIVE_QA_SUMMARY.json';parent=json.loads(parent_path.read_text())
    prior_path=ROOT/'build_final12/BUILD_RECEIPT.json';prior=json.loads(prior_path.read_text())
    before_path=BUILD/'SOURCE_INPUTS_BEFORE_BUILD.json';before=json.loads(before_path.read_text())
    changed=[name for name,value in before['source_files'].items()if prior['source_files'].get(name)!=value]
    assert changed==['src/ui.cpp'],changed
    assert set(before['source_files'])==set(prior['source_files'])
    assert before['source_files']['src/ui.cpp']=='d9ca113d66d5c8beb89720966cfed83531d21ad723321ab57dc346a8d31388b6'
    assert before['source_files']['src/ui.cpp']==sha(ROOT/'src/ui.cpp')
    receipt=dict(result='PASS_FRESH_UI_ONLY_5_0_2_BUILD_NATIVE_EVIDENCE_EXACT_SOURCE_CARRY',product='ResourceScanner',version='5.0.2',
        source_files=before['source_files'],compiled_input_files=before['compiled_input_files'],
        prebuild_inputs=ref(before_path),compile_commands=ref(BUILD/'compile_commands.json'),
        source_binding='Exact source hashes before and after fresh compilation; one changed source file, UI only.',
        upstream_provenance=ref(ROOT/'third_party/PROVENANCE.json'),
        tests=[],tests_not_repeated='Per coordinator: unchanged native14 fixtures are inherited by exact source equality, not claimed reexecuted.',
        inherited_native_tests=dict(receipt=ref(prior_path),tests=len(prior['tests']),all_native_compiled_sources_exact=True),
        artifacts=[ref(BUILD/'ResourceScannerCore.dll')],no_game_tests=True,no_installed_file_access=True,
        installer_payload_permitted=False,release_ready=False)
    receipt_path=BUILD/'BUILD_RECEIPT.json';receipt_path.write_text(json.dumps(receipt,indent=2),encoding='utf8')
    carry=dict(result='PASS_SINGLE_UI_SOURCE_DELTA_AND_UNCHANGED_NATIVE_ZOOM_PROXY_FONTS_ASSETS',
        parent=ref(parent_path),receipt=ref(receipt_path),only_changed_source=changed,
        ui_source=ref(ROOT/'src/ui.cpp'),
        behavior='At very far overview only: identical nonportrait inventory resource/method/tier cells admit one representative; normal view and creature portraits retain prior behavior.',
        source_hash_equality='Every other own source/header/method asset/generator/license equals frozen12 prebuild inputs.',
        no_native_fixtures_repeated=True,retained_proxy=ref(ROOT/'build_final07/vulkan-1.dll'),
        scoped_zoom_peer=ref(ROOT/'qa/world_zoom12/REPORT.json'),prior_ui_peer=ref(ROOT/'qa/ui_visual502/REPORT.json'),
        independent_declutter_ui_gate_pending=True,exact_core_game_gate_pending_root=True)
    carry_path=BUILD/'UI_ONLY_SOURCE_CARRY.json';carry_path.write_text(json.dumps(carry,indent=2),encoding='utf8')
    bindings=dict(parent['input_bindings']);bindings['ui_source']=ref(ROOT/'src/ui.cpp')
    summary=dict(parent);summary.update(result='PASS_5_0_2_FAR_OVERVIEW_UI_ONLY_BUILD_PENDING_UI_PEER_AND_ROOT_GAME',
        source_files=before['source_files'],input_bindings=bindings,
        modules=[dict(role='core',installed_path='ResourceScanner/ResourceScannerCore.dll',**ref(BUILD/'ResourceScannerCore.dll')),
                 dict(role='loader',installed_path='vulkan-1.dll',**ref(ROOT/'build_final07/vulkan-1.dll'))],
        reports=[ref(receipt_path),ref(carry_path),ref(parent_path),ref(ROOT/'qa/world_zoom12/REPORT.json'),ref(ROOT/'qa/ui_visual502/REPORT.json')],
        validation_limits=['This exact Core13 has fresh source build and source-equality evidence; far-overview UI independent assertions and Root game observation remain separate gates.',
            'All native/zoom/font/assets/protocol source is exact Core12; its14 native fixtures are explicitly inherited, not repeated.',
            'No native-owner process access, game install, control or save operation was performed.'],
        boundaries=['Same5.0.2 version and retained proxy07c49.',
            'Exactly one compiled source changes from12: Root-owned far-overview UI cell admission; native renderer/adapter/zoom unchanged.',
            'Private candidate flags remain false pending coordinator admission.'],
        no_game_tests=True,root_owned_game_test_pending=True,installer_payload_permitted=False,release_ready=False)
    path=BUILD/'NATIVE_QA_SUMMARY.json';path.write_text(json.dumps(summary,indent=2),encoding='utf8')
    print(summary['result'],sha(path),sha(BUILD/'ResourceScannerCore.dll'))
if __name__=='__main__':main()
