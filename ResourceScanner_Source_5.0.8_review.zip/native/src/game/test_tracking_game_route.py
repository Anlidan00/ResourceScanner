"""Read-only cached GAME producer/consumer ABI fixture; not product code."""
from pathlib import Path
import sys,struct,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT.parent/'binary/vendor'))
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE
from unicorn.x86_const import *
GAME=ROOT.parent/'terrain/private/enshrouded.exe'
def main():
    pe=pefile.PE(str(GAME));checks=0;cases=[]
    query_cases=[]
    def query_scenario(base,status):
        nonlocal checks
        uc=Uc(UC_ARCH_X86,UC_MODE_64)
        for rva in [0xA3A000,0x119B000,0x281E000]:
            uc.mem_map(base+rva,0x1000);uc.mem_write(base+rva,pe.get_data(rva,0x1000))
        heap=0x50000000;uc.mem_map(heap,0x10000)
        view=heap;node=heap+0x1000;root=heap+0x2000;frame=heap+0x3000;out=heap+0x4000;stop=heap+0x5000;sp=heap+0x9000-8
        put=lambda p,fmt,*a:uc.mem_write(p,struct.pack('<'+fmt,*a))
        get=lambda p,n:bytes(uc.mem_read(p,n))
        put(base+0x281E3F8,'Q',root);put(root+0x10,'Q',frame);put(frame+0x44,'I',1234);put(view+8,'Q',node)
        put(out,'I',0xDEADBEEF);put(sp,'Q',stop);put(sp+0x28,'Q',0xA5)
        nv=[UC_X86_REG_RBX,UC_X86_REG_RBP,UC_X86_REG_RSI,UC_X86_REG_RDI,UC_X86_REG_R12,UC_X86_REG_R13,UC_X86_REG_R14,UC_X86_REG_R15]
        expected={r:0x1122334455660000+i for i,r in enumerate(nv)}
        def hook(u,address,size,_):
            if address==stop:u.emu_stop();return
            if address==base+0x119BA50:
                s=u.reg_read(UC_X86_REG_RSP)
                assert (u.reg_read(UC_X86_REG_RCX),u.reg_read(UC_X86_REG_RDX),u.reg_read(UC_X86_REG_R8),u.reg_read(UC_X86_REG_R9))==(node,1234,2,7)
                assert get(s+0x28,1)==b'\xA5'
                u.reg_write(UC_X86_REG_RAX,status);ret=struct.unpack('<Q',get(s,8))[0]
                u.reg_write(UC_X86_REG_RSP,s+8);u.reg_write(UC_X86_REG_RIP,ret)
        uc.hook_add(UC_HOOK_CODE,hook)
        for r,v in expected.items():uc.reg_write(r,v)
        uc.reg_write(UC_X86_REG_RSP,sp);uc.reg_write(UC_X86_REG_RCX,view);uc.reg_write(UC_X86_REG_RDX,out)
        uc.reg_write(UC_X86_REG_R8,2);uc.reg_write(UC_X86_REG_R9,7)
        uc.emu_start(base+0xA3A670,stop,count=100)
        assert uc.reg_read(UC_X86_REG_RAX)==out and struct.unpack('<I',get(out,4))[0]==status
        assert uc.reg_read(UC_X86_REG_RSP)==sp+8 and all(uc.reg_read(r)==v for r,v in expected.items())
        checks+=6;return dict(base=hex(base),status=status,returns_exact_out_pointer=True,stack_nonvolatile_and_fifth_arg=True)
    def scenario(base,xyz,allocate=True):
        nonlocal checks
        uc=Uc(UC_ARCH_X86,UC_MODE_64)
        for rva,size in [(0xD5F000,0x1000),(0xB05000,0x1000),(0x852000,0x3000),
                         (0x150E000,0x1000),(0x1D48000,0x1000),(0x3A4000,0x2000),(0x3AF000,0x1000),(0x956000,0x1000)]:
            uc.mem_map(base+rva,size);uc.mem_write(base+rva,pe.get_data(rva,size))
        heap=0x40000000;uc.mem_map(heap,0x600000)
        root=heap;ctx=heap+0x1000;queue=heap+0x40000;array=heap+0x41000;buffer=heap+0x42000;point=heap+0x43000
        client=heap+0x50000;out=heap+0x530000;stack=heap+0x540000;stop=heap+0x550000;controller=heap+0x560000
        put=lambda p,fmt,*a:uc.mem_write(p,struct.pack('<'+fmt,*a))
        get=lambda p,n:bytes(uc.mem_read(p,n))
        put(root+0xD0,'Q',ctx);put(ctx+0x33CC0,'Q',queue)
        put(queue+8,'QQ',array,0);put(queue+0x18,'Q',16);put(queue+0x30,'Q',buffer);put(queue+0x40,'I',0)
        put(point,'3q',*xyz)
        nv=[UC_X86_REG_RBX,UC_X86_REG_RBP,UC_X86_REG_RSI,UC_X86_REG_RDI,UC_X86_REG_R12,UC_X86_REG_R13,UC_X86_REG_R14,UC_X86_REG_R15]
        expected={r:0x1122334455660000+i for i,r in enumerate(nv)}
        expected.update({r:0x99887766554433221100AABBCCDD0000+i for i,r in enumerate(range(UC_X86_REG_XMM6,UC_X86_REG_XMM15+1))})
        allocations=[]
        def hook(u,address,size,_):
            if address==stop:u.emu_stop();return
            if address in [base+0x3A4680,base+0x9566F0,base+0x3AFB80]:
                if address==base+0x9566F0:
                    allocations.append((u.reg_read(UC_X86_REG_RDX)&0xFFFFFFFF,u.reg_read(UC_X86_REG_R8)&0xFFFFFFFF))
                    u.reg_write(UC_X86_REG_RAX,out if allocate else 0)
                elif address==base+0x3A4680:u.reg_write(UC_X86_REG_RAX,heap+0x580000)
                else:u.reg_write(UC_X86_REG_RAX,3)
                sp=u.reg_read(UC_X86_REG_RSP);ret=struct.unpack('<Q',get(sp,8))[0]
                u.reg_write(UC_X86_REG_RSP,sp+8);u.reg_write(UC_X86_REG_RIP,ret)
        uc.hook_add(UC_HOOK_CODE,hook)
        def call(target,rcx,rdx):
            sp=stack+0x8000-8;put(sp,'Q',stop)
            for r,v in expected.items():uc.reg_write(r,v)
            uc.reg_write(UC_X86_REG_RSP,sp);uc.reg_write(UC_X86_REG_RCX,rcx);uc.reg_write(UC_X86_REG_RDX,rdx)
            uc.emu_start(base+target,stop,count=2000)
            assert uc.reg_read(UC_X86_REG_RSP)==sp+8
            assert all(uc.reg_read(r)==v for r,v in expected.items())
        call(0xD5F6F0,root,point)
        assert uc.reg_read(UC_X86_REG_RAX)&255==1
        assert struct.unpack('<Q',get(queue+0x10,8))[0]==1
        packet=struct.unpack('<Q',get(array,8))[0];raw=get(packet,40)
        assert packet==buffer and raw[0]==0x42 and raw[8:32]==struct.pack('<3q',*xyz) and raw[32]==1
        assert struct.unpack('<I',get(queue+0x40,4))[0]==40;checks+=5
        put(client+0x47D4E0,'Q',heap+0x570000);put(controller+0x1B8,'Q',client)
        call(0x8546D0,controller,packet)
        assert allocations==[(0xB66AE67E,48)],allocations
        if allocate:
            assert get(out+0x10,24)==struct.pack('<3q',*xyz) and get(out+0x28,1)==b'\x01'
            assert struct.unpack('<I',get(out+8,4))[0]==3
        else:assert get(out,48)==b'\0'*48
        checks+=5
        return dict(base=hex(base),xyz_fixed32_32=xyz,event_kind=0x42,all_xyz_bytes_preserved=True,
                    ecs_type_hash='B66AE67E',ecs_size=48,allocation_available=allocate,native_stack_and_nonvolatile_preserved=True)
    for base in [0x140000000,0x7FF600000000]:
        for status in range(6):query_cases.append(query_scenario(base,status))
        for xyz in [(1<<32,783<<32,-3<<32),(1234567891234,-9876543210,3333333333333),(-10<<32,0,2<<32)]:cases.append(scenario(base,xyz))
        cases.append(scenario(base,(1<<32,-123<<32,2<<32),False))
    out=dict(result='PASS_PRIMARY_GAME_TRACKING_QUERY_AND_CONTROLLER_VOID_CONSUMER',checks=checks,cases=cases,query_cases=query_cases,
        game_source_sha256=hashlib.sha256(GAME.read_bytes()).hexdigest(),
        producer='Actual D5F6F0 plus actual B058B0 queue allocator; no producer stub.',
        consumer='Actual full8546D0 kind3 controller->852760 switch,0x42->853012; only downstream ECS allocation/context/index providers are inert.',
        input_query='Actual full A3A670, only native119BA50 input-state provider substituted; view/node/frame/button/mode/fifth-mask and exact out-pointer return verified.',
        no_game_access=True,no_original_mod_inputs=True,
        boundaries=['Full3D event payload is copied unchanged; no terrain-height resolution is present in these source paths.',
                    'A literal zero-Y producer case only proves byte preservation, NOT admission of unavailable source height.',
                    'Native full consumer is VOID; allocation refusal returns normally without a status. Submitted is only an attempt.',
                    'UI click suppression and own queue are separately tested production code, not exercised by this source fixture.'])
    target=ROOT/'diagnostics/waypoint15';target.mkdir(exist_ok=True)
    (target/'GAME_COMMAND_DRAIN_ROUTE_REVIEW.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(out['result'],checks)
if __name__=='__main__':main()
