#include "zoom_out.hpp"
#include "zoom_profile.hpp"
#include <rs/platform/paths.hpp>
#include <windows.h>
#include <MinHook.h>
#include <intrin.h>
#include <atomic>
#include <type_traits>

namespace rs::game::world_zoom {
namespace {
using RenderMap=std::uint8_t(__fastcall*)(std::uintptr_t);
using InitializeMap=void(__fastcall*)(std::uintptr_t,std::uintptr_t,std::uintptr_t);
RenderMap render_map{};InitializeMap initialize_map{};
std::array<void*,2> targets{};
std::uintptr_t base{};
std::atomic_bool enabled{};
bool created{};
thread_local Scope* current{};
static_assert(std::is_trivially_destructible_v<Scope>);
bool read(void*,std::uintptr_t address,void* out,std::size_t size) noexcept {
    SIZE_T done{};return ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(address),out,size,&done)&&done==size;
}
bool exchange(void*,std::uintptr_t address,std::uint64_t before,std::uint64_t after) noexcept {
    // A corrupt/freed resource never turns a feature failure into a process
    // failure. Only the aligned 8-byte MapState table tail is ever written.
    if(address&7)return false;
    __try {return static_cast<std::uint64_t>(InterlockedCompareExchange64(reinterpret_cast<volatile LONG64*>(address),
        static_cast<LONG64>(after),static_cast<LONG64>(before)))==before;}
    __except(EXCEPTION_EXECUTE_HANDLER){return false;}
}
std::uint8_t __fastcall render(std::uintptr_t element) {
    if(!enabled.load(std::memory_order_acquire))return render_map(element);
    return call({nullptr,read,exchange},render_map,element);
}
void __fastcall initialize(std::uintptr_t state,std::uintptr_t options,std::uintptr_t index) {
    const auto caller=reinterpret_cast<std::uintptr_t>(_ReturnAddress());
    initialize_map(state,options,index);
    if(caller==base+0xC1EB5D)note_state(state);
}
}
std::uint8_t call(const Memory& memory,RenderCall original,std::uintptr_t element) {
    Scope scope{};scope.memory=memory;auto* previous=current;current=&scope;
    std::uint8_t result{};
    // SEH finally covers native structured exceptions as well as C++ unwind.
    // There are no C++ objects requiring destructor unwinding in this wrapper.
    __try {result=original(element);}
    __finally {restore(scope);current=previous;}
    return result;
}
void note_state(std::uintptr_t state) noexcept {if(current)extend(*current,state);}
void note_requested_state(std::uintptr_t state) noexcept {
    // GAME119F650 returns this flag. Newly allocated resources still await
    // their native constructor/initializer; don't edit their reused bytes.
    std::uint8_t initializing{};
    if(current&&state>=0x10010&&current->memory.read(current->memory.user,state-0x10,&initializing,1)&&!initializing)extend(*current,state);
}
bool settings_enabled(const wchar_t* ini) noexcept {
    return !ini||!*ini||GetPrivateProfileIntW(L"Scanner",L"ExtraZoomOut",1,ini)!=0;
}
bool start(std::uintptr_t executable_base) noexcept {
    bool option=true;
    try {auto root=platform::data_directory();if(!root.empty()&&root.is_absolute()){
        auto ini=root/L"settings.ini";option=settings_enabled(ini.c_str());}}
    catch(...){} // A failed optional settings read retains the documented default.
    return start(executable_base,option);
}
bool start(std::uintptr_t executable_base,bool option) noexcept {
    if(!option){stop();platform::log("game-zoom","ExtraZoomOut=0; native world-map zoom retained; zoom hooks disabled");return true;}
    if(enabled.load())return true;
    base=executable_base;if(!base)return false;
    for(const auto& span:zoom_profile::spans){std::array<std::uint8_t,192> actual{};
        if(span.size>actual.size()||!read(nullptr,base+span.rva,actual.data(),span.size)||
            std::memcmp(actual.data(),span.bytes,span.size))return false;}
    if(!created){
        targets={reinterpret_cast<void*>(base+0xC1E810),reinterpret_cast<void*>(base+0xD40D80)};
        if(MH_CreateHook(targets[0],reinterpret_cast<void*>(render),reinterpret_cast<void**>(&render_map))!=MH_OK)return false;
        if(MH_CreateHook(targets[1],reinterpret_cast<void*>(initialize),reinterpret_cast<void**>(&initialize_map))!=MH_OK){MH_RemoveHook(targets[0]);return false;}
        created=true;
    }
    if(MH_EnableHook(targets[0])!=MH_OK||MH_EnableHook(targets[1])!=MH_OK){for(auto p:targets)MH_DisableHook(p);return false;}
    enabled.store(true,std::memory_order_release);platform::log("game-zoom","ExtraZoomOut=1; world-map zoom-out limit is 2x native");return true;
}
void stop() noexcept {
    enabled.store(false,std::memory_order_release);
    if(created)for(auto p:targets)MH_DisableHook(p);
    // Published trampolines remain alive. In-flight render finally restores
    // its own table before returning, including a concurrent stop request.
}
} // namespace rs::game::world_zoom
