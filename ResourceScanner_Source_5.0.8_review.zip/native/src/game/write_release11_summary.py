"""5.0.1: exact native version delta plus one reviewed fullscreen guard."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final11'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def ref(path):return dict(path=str(path.resolve()),sha256=digest(path.read_bytes()),bytes=path.stat().st_size)
parent_path=ROOT/'build_final10/NATIVE_QA_SUMMARY.json';parent=json.loads(parent_path.read_text());old=json.loads((ROOT/'build_final10/BUILD_RECEIPT.json').read_text());new=json.loads((BUILD/'BUILD_RECEIPT.json').read_text())
version_files=['CMakeLists.txt','src/platform/lifecycle.cpp','src/platform/paths.cpp']
for name in version_files:assert digest((ROOT/name).read_bytes().replace(b'5.0.1',b'5.0.0'))==old['source_files'][name],name
assert new['version']=='5.0.1'
changed=sorted(name for name,value in old['source_files'].items()if new['source_files'].get(name)!=value)
assert changed==sorted(version_files+['src/game/hud_blockers.hpp','src/game/adapter_smoke.cpp']),changed
header=(ROOT/'src/game/hud_blockers.hpp').read_text()
corrected='''                        const auto raw_body=transform(body,v.scale,v.x,v.y),full=transform(root,v.scale,v.x,v.y);
                        if(raw_body.left<=full.left&&raw_body.top<=full.top&&raw_body.right>=full.right&&raw_body.bottom>=full.bottom)return;
                        Rect rect{};if(pixel_rect(body,v,rect)){'''
old_guard='''                        Rect rect{};if(pixel_rect(body,v,rect)){auto full=transform(root,v.scale,v.x,v.y);
                            if(rect.left<=full.left&&rect.top<=full.top&&rect.right>=full.right&&rect.bottom>=full.bottom)return;'''
assert corrected in header and digest(header.replace(corrected,old_guard).encode())==old['source_files']['src/game/hud_blockers.hpp']
for name in ['src/platform/vulkan_render.cpp','src/platform/vulkan_dispatch.hpp','src/platform/vulkan_proxy.cpp','src/game/adapter.cpp','src/ui.cpp','src/platform/shared_frame.cpp','src/game/state.cpp']:
    assert new['source_files'][name]==old['source_files'][name],name
for item in parent['input_bindings'].values():assert ref(Path(item['path']))['sha256']==item['sha256']
capture=ROOT/'diagnostics/map09_44496_all_bulk.json';run=subprocess.run([str(BUILD/'rs_game_adapter_smoke.exe'),str(capture)],cwd=BUILD,capture_output=True,text=True,timeout=30);assert run.returncode==0,run.stdout
proof=dict(result='PASS_5_0_1_VERSION_AND_SINGLE_REVIEWED_FULLSCREEN_GUARD_OFFLINE',parent=ref(parent_path),receipt=ref(BUILD/'BUILD_RECEIPT.json'),
    version='5.0.1',version_only_compiled_sources=version_files,normalized_prior_hash_equality=True,
    one_functional_guard=dict(source=ref(ROOT/'src/game/hud_blockers.hpp'),finding=ref(ROOT/'qa/hud_blockers10/FINDING_FULLSCREEN_V10.json'),
        change='Compare RAW popup body to RAW native viewport BEFORE clipping to map_content; no fullscreen ancestor may become a whole-map blocker.',normalized_all_other_header_bytes_exact=True),
    additional_test_source=ref(ROOT/'src/game/adapter_smoke.cpp'),
    capture=ref(capture),capture_provenance='Optimistic external read: node/viewport geometry all current same generation; overlapping UI clock snapshots differ. Independent QA replays both stable recorded clock choices; no atomic entire capture claim.',
    actual_capture_test=dict(exit_code=run.returncode,stdout=run.stdout,checks=27,normal_blockers=4,normal_flags=15,fullscreen_mutation='optional blocker set rejects; map projection/world remain ready'),
    normal_fixtures=len(new['tests']),ui_source_exact='39ee1248f1458b15b1b0c3a1c3741dd16d9c3f929a5ebb102dce1fa2d4050471',
    vulkan09_map08_protocols_exact=True,retained_proxy=ref(ROOT/'build_final07/vulkan-1.dll'),
    actual_game_gate_pending_root=True)
(BUILD/'VERSION_GUARD_CARRY.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
summary=dict(parent);summary.update(version='5.0.1',result='PASS_5_0_1_NATIVE_OFFLINE_PENDING_ROOT_GAME',source_files=new['source_files'],
    modules=[dict(role='core',installed_path='ResourceScanner/ResourceScannerCore.dll',**ref(BUILD/'ResourceScannerCore.dll')),
        dict(role='loader',installed_path='vulkan-1.dll',**ref(ROOT/'build_final07/vulkan-1.dll'))],
    reports=[ref(BUILD/'BUILD_RECEIPT.json'),ref(BUILD/'VERSION_GUARD_CARRY.json'),ref(ROOT/'qa/ui_blockers10/REPORT.json'),ref(parent_path)],
    boundaries=['Native product version5.0.1; exact Vulkan09 and Map08 semantics retained.',
        'Single reviewed fullscreen-popup guard correction relative to Core10; normal four rectangles unchanged.',
        'Geometry capture is coherent; full snapshot is not claimed atomic because its duplicate UI clock readings differ.',
        'This exact Core11 requires Root-owned actual game gate and separate packaging admission.'])
(BUILD/'NATIVE_QA_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(dict(summary=ref(BUILD/'NATIVE_QA_SUMMARY.json'),proof=ref(BUILD/'VERSION_GUARD_CARRY.json'),modules=summary['modules']),indent=2))
