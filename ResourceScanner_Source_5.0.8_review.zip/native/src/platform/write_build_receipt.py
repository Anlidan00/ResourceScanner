"""Record a source-only build and run only our own offline fixture executables."""
from pathlib import Path
import argparse,hashlib,json,subprocess,time,os,re
ROOT=Path(__file__).resolve().parents[2]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def source_inputs(build):
    own=[ROOT/'CMakeLists.txt',ROOT/'build.ps1',ROOT/'src/platform/write_build_receipt.py']+sorted((ROOT/'include').rglob('*.hpp'))+sorted((ROOT/'src').rglob('*.cpp'))+sorted((ROOT/'src').rglob('*.hpp'))
    # The generated method alpha table is a compiler input; its approved
    # source assets, licenses and generator are also bound, without rerendering.
    own+=sorted(p for p in (ROOT/'assets/methods').rglob('*')if p.is_file())
    commands=json.loads((build/'compile_commands.json').read_text(encoding='utf8'))
    compiled={Path(x['file']).resolve()for x in commands}
    for part in ['imgui','json/include','vulkan_headers/include','minhook/include','minhook/src','zstd/lib']:
        compiled.update((ROOT/'third_party'/part).rglob('*.h'))
    compiled.update((build/'proxy_generated').glob('*'));compiled.update((build/'vulkan_proxy_generated').glob('*'))
    compiled={x for x in compiled if x.is_file()}
    return own,compiled,commands
def snapshot(build):
    own,compiled,_=source_inputs(build)
    return dict(source_files={x.relative_to(ROOT).as_posix():sha(x)for x in own},
        compiled_input_files={x.relative_to(ROOT).as_posix():sha(x)for x in sorted(compiled)},
        compile_commands_sha256=sha(build/'compile_commands.json'))
def verify(build):
    previous=json.loads((build/'SOURCE_INPUTS_BEFORE_BUILD.json').read_text(encoding='utf8'))
    assert previous==snapshot(build),'Sources/compiler inputs changed since build began; rebuild before admission'
    own,_,commands=source_inputs(build)
    header_time=max(x.stat().st_mtime_ns for x in own if x.suffix=='.hpp')
    for row in commands:
        source=Path(row['file']);obj=Path(row['directory'])/row['output'];assert obj.is_file(),obj
        assert obj.stat().st_mtime_ns>=source.stat().st_mtime_ns,(source,obj)
        if source.is_relative_to(ROOT/'src'):
            assert obj.stat().st_mtime_ns>=header_time,(source,'object predates project header')
    return previous
def main():
    p=argparse.ArgumentParser();p.add_argument('--build',default='build_final02');p.add_argument('--snapshot-only',action='store_true');p.add_argument('--verify-only',action='store_true');a=p.parse_args();build=(ROOT/a.build).resolve()
    assert build.is_relative_to(ROOT.resolve())
    if a.snapshot_only:
        (build/'SOURCE_INPUTS_BEFORE_BUILD.json').write_text(json.dumps(snapshot(build),indent=2),encoding='utf8');print('SOURCE_INPUTS_SNAPSHOTTED_BEFORE_COMPILATION');return
    prebuild=verify(build)
    if a.verify_only:print('PASS_BEFORE_AFTER_COMPILED_INPUTS_EXACT');return
    before=prebuild['source_files']
    cases=[]
    commands=[['rs_platform_smoke.exe'],['rs_game_adapter_smoke.exe',str(ROOT.parent/'mob_portraits/game_qa/session_20261026_123657_794994/hud_tree_v4.json')],['rs_world_zoom_smoke.exe'],
        ['rs_state_mapping_smoke.exe'],['rs_font_smoke.exe',str(ROOT/'fonts')],['rs_proxy_smoke.exe',str(build/'dbghelp.dll')],['rs_vulkan_smoke.exe',str(build/'ResourceScannerCore.dll')],
        ['rs_vulkan_failure_smoke.exe'],['rs_lifecycle_failure_smoke.exe']]
    for command in commands:
        started=time.monotonic();r=subprocess.run([str(build/command[0]),*command[1:]],cwd=build,capture_output=True,text=True,timeout=45)
        cases.append(dict(command=command,exit_code=r.returncode,seconds=round(time.monotonic()-started,3),stdout=r.stdout,stderr=r.stderr))
        if r.returncode:raise RuntimeError(cases[-1])
    command=[str(build/'rs_vulkan_smoke.exe'),str(build/'ResourceScannerCore.dll')];environment=os.environ.copy();environment['RS_GPU_TEST_NO_DELAY']='1'
    r=subprocess.run(command,cwd=build,env=environment,capture_output=True,text=True,timeout=45)
    cases.append(dict(command=command,scenario='Immediate Vulkan initialization without fixture backoff',exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
    if r.returncode:raise RuntimeError(cases[-1])
    environment['RS_GPU_TEST_VULKAN_PROXY']='1'
    for late in [False,True]:
        if late:environment['RS_GPU_TEST_LATE_QUEUE']='1'
        else:environment.pop('RS_GPU_TEST_LATE_QUEUE',None)
        proxy_command=[str(build/'rs_vulkan_smoke.exe'),str(build/'ResourceScanner/ResourceScannerCore.dll')]
        r=subprocess.run(proxy_command,cwd=build,env=environment,capture_output=True,text=True,timeout=45)
        cases.append(dict(command=proxy_command,scenario='FIRST-API proxy before caller Core startup; cached PFNs; late_queue='+str(late),exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
        if r.returncode:raise RuntimeError(cases[-1])
    r=subprocess.run([str(build/'rs_vulkan_proxy_smoke.exe'),str(build/'vulkan-1.dll')],cwd=build,capture_output=True,text=True,timeout=45)
    cases.append(dict(scenario='Optional Core absent; transparent real Vulkan continues',exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
    if r.returncode:raise RuntimeError(cases[-1])
    environment.pop('RS_GPU_TEST_VULKAN_PROXY',None)
    environment['RS_GPU_TEST_LATE_QUEUE']='1'
    r=subprocess.run(command,cwd=build,env=environment,capture_output=True,text=True,timeout=45)
    cases.append(dict(command=command,scenario='GIPA/GDPA dispatch, immediate engine creation, graphics queue obtained after swapchain',exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
    if r.returncode:raise RuntimeError(cases[-1])
    assert prebuild==verify(build),'Source changed during fixture run'
    version=re.search(r'project\(ResourceScanner VERSION ([0-9.]+)',(ROOT/'CMakeLists.txt').read_text()).group(1)
    receipt=dict(result='PASS_FRESH_SOURCE_OFFLINE_VERTICAL_SLICE',product='ResourceScanner',version=version,
        source_files=before,upstream_provenance=dict(path='third_party/PROVENANCE.json',sha256=sha(ROOT/'third_party/PROVENANCE.json')),
        prebuild_inputs=dict(path=str(build/'SOURCE_INPUTS_BEFORE_BUILD.json'),sha256=sha(build/'SOURCE_INPUTS_BEFORE_BUILD.json')),
        source_binding='Exact hashes before compilation and after all fixtures; source/object timestamp checks are ancillary.',
        compile_commands=dict(path=str(build/'compile_commands.json'),sha256=sha(build/'compile_commands.json')),
        game_source_profile=dict(path='src/game/SOURCE_PROFILE.json',sha256=sha(ROOT/'src/game/SOURCE_PROFILE.json')),
        tests=cases,artifacts=[dict(path=str(build/n),bytes=(build/n).stat().st_size,sha256=sha(build/n))for n in ['ResourceScannerCore.dll','dbghelp.dll','vulkan-1.dll']],
        no_game_tests=True,no_installed_file_access=True,installer_payload_permitted=False,release_ready=False,
        boundaries=['Game UI observer scheduling/projection has source and inert-memory evidence; no actual game gate by user request.',
            'Vulkan fixture uses our hidden window and own process; it is not a game screenshot or game hook validation.',
            'Only official separately fetched source dependencies and our own source enter the native build.'])
    (build/'BUILD_RECEIPT.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
    print(receipt['result'],len(cases),sha(build/'BUILD_RECEIPT.json'))
if __name__=='__main__':main()
