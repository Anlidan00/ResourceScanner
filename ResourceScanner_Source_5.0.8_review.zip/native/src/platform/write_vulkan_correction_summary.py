"""Bind the private startup correction; no installed paths are accessed."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2]
BUILD=ROOT/'build_final05'
def ref(path):
    return dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
old=json.loads((ROOT/'build_final04/NATIVE_QA_SUMMARY.json').read_text())
prior=json.loads((ROOT/'build_final04/BUILD_RECEIPT.json').read_text())
receipt=json.loads((BUILD/'BUILD_RECEIPT.json').read_text())
changed=[name for name,value in prior['source_files'].items() if receipt['source_files'].get(name)!=value]
assert sorted(changed)==['src/platform/lifecycle.cpp','src/platform/vulkan_render.cpp','src/platform/vulkan_smoke.cpp'],changed
for item in old['input_bindings'].values():assert ref(Path(item['path']))['sha256']==item['sha256']
proof=dict(result='PASS_TARGETED_VULKAN_STARTUP_CORRECTION_OFFLINE',
    parent=ref(ROOT/'build_final04/NATIVE_QA_SUMMARY.json'),receipt=ref(BUILD/'BUILD_RECEIPT.json'),
    changed_compiled_sources=changed,all_other_compiled_own_sources_exact=True,
    old_core_negative=dict(core=ref(ROOT/'build_final04/ResourceScannerCore.dll'),
        fixture=ref(BUILD/'rs_vulkan_smoke.exe'),scenario='Immediate initialization; GIPA/GDPA dispatch; late graphics queue',
        exit_code=1,stdout='FAIL GIPA did not return our GDPA dispatch wrapper'),
    changes=['Install Vulkan hooks before source observers and helper startup, including synchronous attempt when Vulkan is already loaded.',
        'Enable our Vulkan hooks in one MinHook queued transaction rather than sequential process-thread suspensions.',
        'Return our GetInstanceProcAddr/GetDeviceProcAddr wrappers when they are requested through GIPA/GDPA.',
        'Retain only owned scalar swapchain creation fields and defer initialization until its graphics queue is captured; retry on its first Present.',
        'Log first intercepted Vulkan stages and missing-precondition masks without per-frame spam.'],
    diagnostic_mask=dict(instance=1,physical_device=2,device=4,surface=8,window=16,graphics_queue=32,graphics_family=64),
    current_loader_compatible=dict(loader=ref(ROOT/'build_final04/dbghelp.dll'),
        reason='Proxy source, public core exports, installed paths, catalog/runtime/IPC/UI interfaces are unchanged.'),
    actual_game_gate='Pending Root-owned replacement of Core only; no game/process/install operations by native owner.')
(BUILD/'VULKAN_STARTUP_CORRECTION.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
summary={key:value for key,value in old.items() if key not in ['modules','reports','boundaries']}
summary.update(result='PASS_TARGETED_VULKAN_STARTUP_OFFLINE_CHECKS_PENDING_GAME',complete=True,
    no_game_tests=True,game_tests_prohibited_by_user=False,root_owned_game_test_pending=True,
    installer_payload_permitted=False,release_ready=False,
    modules=[dict(role=role,installed_path=installed,**ref(BUILD/name)) for role,installed,name in [
        ('core','ResourceScanner/ResourceScannerCore.dll','ResourceScannerCore.dll'),('loader','dbghelp.dll','dbghelp.dll')]],
    root_core_only_test_loader=ref(ROOT/'build_final04/dbghelp.dll'),
    reports=[ref(BUILD/'BUILD_RECEIPT.json'),ref(BUILD/'VULKAN_STARTUP_CORRECTION.json'),ref(ROOT/'build_final04/NATIVE_QA_SUMMARY.json')],
    boundaries=['Private corrective candidate; original released native revision failed to enter renderer in the Root-owned game test.',
        'All eight source-bound offline fixtures passed, including real hidden Vulkan GIPA/GDPA dispatch and queue-after-swapchain Present.',
        'Actual game success is not claimed before Root tests this exact Core.'])
(BUILD/'NATIVE_QA_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(dict(summary=ref(BUILD/'NATIVE_QA_SUMMARY.json'),proof=ref(BUILD/'VULKAN_STARTUP_CORRECTION.json'),modules=summary['modules']),indent=2))
