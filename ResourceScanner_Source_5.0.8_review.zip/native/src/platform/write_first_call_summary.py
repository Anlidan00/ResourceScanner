"""Private source-bound Vulkan first-call route; no installed/game access."""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final07'
def ref(path):return dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
parent=json.loads((ROOT/'build_final06/NATIVE_QA_SUMMARY.json').read_text())
before=json.loads((ROOT/'build_final06/BUILD_RECEIPT.json').read_text())
current=json.loads((BUILD/'BUILD_RECEIPT.json').read_text())
changes=sorted(name for name,value in before['source_files'].items() if current['source_files'].get(name)!=value)
assert changes==['CMakeLists.txt','src/platform/dllmain.cpp','src/platform/vulkan_render.cpp','src/platform/vulkan_smoke.cpp'],changes
for item in parent['input_bindings'].values():assert ref(Path(item['path']))['sha256']==item['sha256']
game=ROOT.parent/'terrain/private/enshrouded.exe';raw=game.read_bytes();nt=struct.unpack_from('<I',raw,60)[0];opt=nt+24;optlen=struct.unpack_from('<H',raw,nt+20)[0];nsec=struct.unpack_from('<H',raw,nt+6)[0]
def data(rva,size):
    for i in range(nsec):
        at=opt+optlen+i*40;vs,va,rs,off=struct.unpack_from('<IIII',raw,at+8)
        if va<=rva and rva+size<=va+rs:return raw[off+rva-va:off+rva-va+size]
    raise ValueError(rva)
windows=[dict(rva=rva,bytes_hex=data(rva,count).hex(),meaning=meaning)for rva,count,meaning in [
    (0xFCC2BB,0x20,'Literal unqualified vulkan-1.dll span passed into game library loader F38470.'),
    (0xF384F3,0xA,'Game loader passes converted literal to imported LoadLibraryW at IAT13B27E0; no System32/absolute-path flag.'),
    (0xFCC310,0x28,'GetProcAddress(vkGetInstanceProcAddr), stores resulting PFN.'),
    (0xFCC36B,0x11,'Immediate vkCreateInstance PFN lookup via cached GIPA before engine creation.'),
    (0xF341AD,0xC,'Game proc lookup calls imported GetProcAddress at IAT13B2908.')]]
assert data(0x1D9EA18,13)==b'vulkan-1.dll\0'
assert data(0x1D9EA28,22)==b'vkGetInstanceProcAddr\0'
proof=dict(result='PASS_SOURCE_GAME_LOAD_ROUTE_AND_OWN_FIRST_API_PROXY_OFFLINE',
    game_source=ref(game),game_source_windows=windows,whole_game_version_gate=False,
    parent=ref(ROOT/'build_final06/NATIVE_QA_SUMMARY.json'),build_receipt=ref(BUILD/'BUILD_RECEIPT.json'),
    changed_prior_compiled_own_sources=changes,all_other_prior_compiled_own_sources_exact=True,
    own_proxy_source=ref(ROOT/'src/platform/vulkan_proxy.cpp'),generator=ref(ROOT/'src/platform/generate_proxy.py'),
    official_return_type_registry=ref(ROOT/'third_party/vulkan_headers/registry/vk.xml'),
    system_export_interface=ref(BUILD/'vulkan_proxy_generated/EXPORT_INTERFACE.json'),
    first_call_contract=['Local vulkan-1.dll exports forward to absolute System32 real Vulkan; only names/ordinals are generated from its PE interface.',
        'Its first API resolver loads optional Core and synchronously prepares real-module hooks BEFORE returning the API/PFN to the engine.',
        'Core hooks only the explicit System32 module path; a same-basename local proxy is never selected as the real loader.',
        'Core absent/startup failure does not gate real Vulkan forwarding; unsupported proc-address queries retain NULL.',
        'Missing VkResult exports return VK_ERROR_INITIALIZATION_FAILED(-3), never false VK_SUCCESS; other unsupported exports return zero/no-op.'],
    observed_offline=dict(normal_and_fault_fixtures=13,first_api_proxy_gpu_scenarios=2,callbacks_per_proxy_scenario=24,
        baseline06_precreated_objects=dict(core=ref(BUILD/'precreated06/ResourceScannerCore.dll'),result=ref(BUILD/'precreated06_result.txt'),overlay_callbacks=0),
        proxy_missing_core='Real Vulkan instance creation/destruction PASS; unsupported lookup NULL.'),
    root_test_layout=dict(add='vulkan-1.dll',replace='ResourceScanner/ResourceScannerCore.dll',remove_owned_previous_proxy='dbghelp.dll',
        retain='All catalog/runtime/fonts/Stack files; root owns journal and restore.'),
    no_installed_file_access=True,no_game_tests=True,actual_game_gate_pending=True)
(BUILD/'FIRST_CALL_BOOTSTRAP_REVIEW.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
summary=dict(parent)
summary.update(result='PASS_FIRST_CALL_VULKAN_PROXY_OFFLINE_PENDING_GAME',loader_route='vulkan-first-api-barrier',
    modules=[dict(role=role,installed_path=installed,**ref(BUILD/name))for role,installed,name in [
        ('core','ResourceScanner/ResourceScannerCore.dll','ResourceScannerCore.dll'),('loader','vulkan-1.dll','vulkan-1.dll')]],
    reports=[ref(BUILD/'BUILD_RECEIPT.json'),ref(BUILD/'FIRST_CALL_BOOTSTRAP_REVIEW.json'),ref(ROOT/'build_final06/NATIVE_QA_SUMMARY.json')],
    boundaries=['Actual first two game launches proved the asynchronous dbghelp bootstrap insufficient; that route is retired for this candidate.',
        'The independent first-API Vulkan proxy passes actual own-host GPU/cache/missing-Core tests; this exact candidate awaits Root game validation.'])
summary.pop('root_core_only_test_loader',None)
(BUILD/'NATIVE_QA_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(dict(summary=ref(BUILD/'NATIVE_QA_SUMMARY.json'),proof=ref(BUILD/'FIRST_CALL_BOOTSTRAP_REVIEW.json'),modules=summary['modules']),indent=2))
