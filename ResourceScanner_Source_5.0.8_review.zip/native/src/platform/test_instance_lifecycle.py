"""Only our hidden-window host: old stale-instance abort and fixed lifecycle."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final09'
def ref(p):return dict(path=str(p.resolve()),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
results=[]
for name,core,expected in [('baseline08_lifecycle',ROOT/'build_final08/ResourceScannerCore.dll',0xc0000409),('retained07_lifecycle',BUILD/'ResourceScannerCore.dll',0)]:
    stage=BUILD/name;assert stage.resolve().is_relative_to(BUILD.resolve());destination=stage/'ResourceScanner';destination.mkdir(parents=True,exist_ok=True)
    shutil.copy2(core,destination/'ResourceScannerCore.dll');shutil.copy2(ROOT/'build_final07/vulkan-1.dll',stage/'vulkan-1.dll')
    shutil.copytree(ROOT/'fonts',destination/'fonts',dirs_exist_ok=True)
    env=os.environ.copy();env.update(RS_GPU_TEST_NO_DELAY='1',RS_GPU_TEST_VULKAN_PROXY='1',RS_GPU_TEST_DUMMY_INSTANCE='1',RS_GPU_TEST_TWO_INSTANCES='1',RS_GPU_TEST_LATE_QUEUE='1',RS_GPU_TEST_DEVICE_BEFORE_SURFACE='1')
    run=subprocess.run([str(BUILD/'rs_vulkan_smoke.exe'),str(destination/'ResourceScannerCore.dll')],cwd=BUILD,env=env,capture_output=True,text=True,timeout=30)
    result=dict(scenario=name,core=ref(core),proxy=ref(stage/'vulkan-1.dll'),host=ref(BUILD/'rs_vulkan_smoke.exe'),exit_code=run.returncode,exit_u32=run.returncode&0xffffffff,stdout=run.stdout,stderr=run.stderr)
    results.append(result);assert result['exit_u32']==expected,result
    if expected==0:assert '24 callbacks' in run.stdout and 'first_call_proxy=1' in run.stdout
    print(name,hex(result['exit_u32']),run.stdout.strip())
report=dict(result='PASS_DETERMINISTIC_OLD_INSTANCE_ABORT_AND_FIXED_REAL_GPU_LIFECYCLE',
    sequence='Create dummy first; keep it alive while creating auxiliary and main instances; destroy dummy BEFORE main physical/device initialization; create Device BEFORE Surface as in the actual game; retain auxiliary until resize.',
    device_before_surface=True,
    old_expected='Same C0000409 process-fatal abort as game08 after using a destroyed first-instance global.',
    fixed_expected='24 actual GPU callbacks,3 uploads,2 swapchain generations,23 fonts,2 Insert presses; main and auxiliary ownership independent.',
    process_scope='Only rs_vulkan_smoke.exe created by this script; no game process/control/install access.',results=results)
(BUILD/'INSTANCE_LIFECYCLE_REVIEW.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(ref(BUILD/'INSTANCE_LIFECYCLE_REVIEW.json'))
