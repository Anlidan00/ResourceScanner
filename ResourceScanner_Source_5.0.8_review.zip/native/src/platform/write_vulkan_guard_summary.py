"""Bind only the three reviewed bootstrap failure-path corrections."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final06'
def ref(path):return dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
parent=json.loads((ROOT/'build_final05/NATIVE_QA_SUMMARY.json').read_text())
old=json.loads((ROOT/'build_final05/BUILD_RECEIPT.json').read_text())
new=json.loads((BUILD/'BUILD_RECEIPT.json').read_text())
changes=sorted(name for name,value in old['source_files'].items() if new['source_files'].get(name)!=value)
added=sorted(set(new['source_files'])-set(old['source_files']))
assert changes==['CMakeLists.txt','src/platform/lifecycle.cpp','src/platform/vulkan_render.cpp'],changes
assert added==['src/platform/lifecycle_failure_smoke.cpp','src/platform/vulkan_failure_smoke.cpp'],added
for item in parent['input_bindings'].values():assert ref(Path(item['path']))['sha256']==item['sha256']
proof=dict(result='PASS_THREE_TARGETED_BOOTSTRAP_FAILURE_GUARDS',parent=ref(ROOT/'build_final05/NATIVE_QA_SUMMARY.json'),
    build_receipt=ref(BUILD/'BUILD_RECEIPT.json'),changed_prior_source_files=changes,new_fixture_files=added,
    all_other_prior_source_files_exact=True,
    fixes=['Optional vkGetDeviceQueue2 proc-address lookup preserves its original pointer if our exported trampoline is unavailable.',
        'A failed MinHook activation disables but retains published trampolines, and subsequent activation reuses the same complete set.',
        'Failure to create the core worker after synchronous hook installation sets stopped and invokes safe hook teardown.'],
    fault_test_boundaries=['Actual own Vulkan bootstrap/replacement code with only MinHook return boundaries replaced by fault providers.',
        'Actual own lifecycle start code with CreateThread failure and hook install/teardown observation providers.'],
    tests=10,actual_hidden_vulkan_scenarios=3,normal_fixtures_reexecuted=True,
    existing_loader_compatible=ref(ROOT/'build_final04/dbghelp.dll'),actual_game_test_pending=True)
(BUILD/'BOOTSTRAP_GUARD_REVIEW.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
summary=dict(parent)
summary['modules']=[dict(role=role,installed_path=installed,**ref(BUILD/name))for role,installed,name in [
    ('core','ResourceScanner/ResourceScannerCore.dll','ResourceScannerCore.dll'),('loader','dbghelp.dll','dbghelp.dll')]]
summary['reports']=[ref(BUILD/'BUILD_RECEIPT.json'),ref(BUILD/'BOOTSTRAP_GUARD_REVIEW.json'),ref(ROOT/'build_final05/NATIVE_QA_SUMMARY.json')]
summary['result']='PASS_TARGETED_VULKAN_BOOTSTRAP_AND_FAILURE_GUARDS_PENDING_GAME'
(BUILD/'NATIVE_QA_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(dict(summary=ref(BUILD/'NATIVE_QA_SUMMARY.json'),receipt=ref(BUILD/'BUILD_RECEIPT.json'),proof=ref(BUILD/'BOOTSTRAP_GUARD_REVIEW.json'),modules=summary['modules']),indent=2))
