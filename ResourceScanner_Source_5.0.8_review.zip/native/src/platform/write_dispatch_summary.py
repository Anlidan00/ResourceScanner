"""Bind the targeted live-instance/real-PFN repair; original reports untouched."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[2];BUILD=ROOT/'build_final09'
def ref(path):return dict(path=str(path.resolve()),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
parent_path=ROOT/'build_final08/NATIVE_QA_SUMMARY.json';parent=json.loads(parent_path.read_text());prior=json.loads((ROOT/'build_final08/BUILD_RECEIPT.json').read_text());receipt=json.loads((BUILD/'BUILD_RECEIPT.json').read_text())
changes=sorted(name for name,value in prior['source_files'].items()if receipt['source_files'].get(name)!=value)
assert changes==['src/platform/vulkan_failure_smoke.cpp','src/platform/vulkan_render.cpp','src/platform/vulkan_smoke.cpp'],changes
assert all(receipt['source_files'][n]==prior['source_files'][n]for n in ['src/game/adapter.cpp','src/game/adapter_smoke.cpp','src/platform/vulkan_proxy.cpp','src/ui.cpp','src/catalog.cpp'])
for item in parent['input_bindings'].values():assert ref(Path(item['path']))['sha256']==item['sha256']
# Separate correction for stale inherited metadata; never overwrite summary1827.
addendum=dict(result='SOURCE_MAP_METADATA_CORRECTION_ONLY',parent=ref(parent_path),authoritative_receipt=ref(ROOT/'build_final08/BUILD_RECEIPT.json'),source_files=prior['source_files'],
    explanation='The inherited summary source_files described07. The08 prebuild snapshot, BUILD_RECEIPT and Core were correctly bound; this addendum names the authoritative map without changing any frozen artifact.')
addendum_path=ROOT/'build_final08/SOURCE_FILES_ADDENDUM.json'
if addendum_path.exists():assert json.loads(addendum_path.read_text())==addendum
else:addendum_path.write_text(json.dumps(addendum,indent=2),encoding='utf8')
life_path=BUILD/'INSTANCE_LIFECYCLE_REVIEW.json';life=json.loads(life_path.read_text());life['device_before_surface']=True
life['sequence']='Create dummy first; auxiliary and main while dummy is alive; destroy dummy; main Device BEFORE Surface; auxiliary retained until resize.'
for row in life['results']:
    stage=BUILD/row['scenario'];log_path=stage/'ResourceScanner/native.log';events=[json.loads(line)for line in log_path.read_text().splitlines()];pid=events[-1]['pid'];events=[e for e in events if e['pid']==pid]
    row['native_log']=ref(log_path);row['last_process_events']=[dict(phase=e['phase'],message=e['message'])for e in events]
    if row['exit_u32']:assert events[-1]['message']=='vkCreateDevice succeeded'
life_path.write_text(json.dumps(life,indent=2),encoding='utf8')
actual_capture=ROOT/'diagnostics/map07_51620_bulk.json';run=subprocess.run([str(BUILD/'rs_game_adapter_smoke.exe'),str(actual_capture)],cwd=BUILD,capture_output=True,text=True,timeout=30);assert run.returncode==0
proof=dict(result='PASS_LIVE_INSTANCE_LIFECYCLE_AND_EXACT_LAYER_PFN_DISPATCH_OFFLINE',
    parent=ref(parent_path),prior_source_map_addendum=ref(addendum_path),receipt=ref(BUILD/'BUILD_RECEIPT.json'),
    crash_root_cause_peer=ref(ROOT/'qa/crash08/REPORT.json'),deterministic_old_new_real_gpu=ref(life_path),
    source_changes=changes,new_dispatch=ref(ROOT/'src/platform/vulkan_dispatch.hpp'),new_layer_fixture=ref(ROOT/'src/platform/vulkan_layer_smoke.hpp'),
    ownership=['Bounded live instance records retired on DestroyInstance.',
        'Physical-device ownership captured from successful enumeration; device tied to its actual physical/instance origin.',
        'Surface, queue, device and swapchain must share a live recorded origin before overlay initialization.',
        'Each cached thunk has an immutable EXACT original PFN plus original GIPA/GDPA origin; no global resolver replacement of a layer function.',
        'Nested real-layer calls forward unchanged without admitting their private inner handles as engine-visible owners.',
        'Raw renderer lookups use the selected live device origin; redundant eager CreateDevice memory query removed.',
        'Fixed registry saturation preserves the real API and skips observation; no opaque handle guessing or dereferences.'],
    normal_fixture_count=len(receipt['tests']),map08_exact_source_carry=True,proxy07_exact_source_carry=True,
    actual_map_capture=ref(actual_capture),actual_map_replay=dict(exit_code=run.returncode,stdout=run.stdout,positive_flags=15),
    own_hidden_gpu_scope_only=True,game_test_this_candidate_pending=True)
(BUILD/'INSTANCE_DISPATCH_REVIEW.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
summary=dict(parent);summary.update(result='PASS_INSTANCE_LIFECYCLE_LAYER_DISPATCH_OFFLINE_PENDING_GAME',source_files=receipt['source_files'],
    modules=[dict(role='core',installed_path='ResourceScanner/ResourceScannerCore.dll',**ref(BUILD/'ResourceScannerCore.dll')),
        dict(role='loader',installed_path='vulkan-1.dll',**ref(ROOT/'build_final07/vulkan-1.dll'))],
    reports=[ref(BUILD/'BUILD_RECEIPT.json'),ref(BUILD/'INSTANCE_DISPATCH_REVIEW.json'),ref(life_path),ref(addendum_path),ref(parent_path)],
    boundaries=['Actual game08 failed at invalid-instance GIPA in the old eager physical-memory query; no game retry of that revision.',
        'Own realGPU fixture reproduces old08 C0000409 with the actual Device-before-Surface order; new09 passes under the same sequence and retained proxy07.',
        'Two independent fake layer resolvers and opaque owners validate immutable PFN chains and private inner-handle suppression.',
        'Map08 adapter and proxy07 are retained; actual09 game flags15/helper-ready3 verification is still pending Root.'])
(BUILD/'NATIVE_QA_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
print(json.dumps(dict(summary=ref(BUILD/'NATIVE_QA_SUMMARY.json'),proof=ref(BUILD/'INSTANCE_DISPATCH_REVIEW.json'),lifecycle=ref(life_path),modules=summary['modules']),indent=2))
