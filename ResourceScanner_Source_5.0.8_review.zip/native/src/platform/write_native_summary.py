"""Bind the fresh offline native build, data, helper, and independent evidence."""
from pathlib import Path
import argparse,hashlib,json
ROOT=Path(__file__).resolve().parents[2]
def reference(path):
    path=path.resolve();raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def main():
    p=argparse.ArgumentParser();p.add_argument('--build',default='build_final01');a=p.parse_args();build=(ROOT/a.build).resolve();assert build.is_relative_to(ROOT.resolve())
    receipt=json.loads((build/'BUILD_RECEIPT.json').read_text())
    assert receipt['result']=='PASS_FRESH_SOURCE_OFFLINE_VERTICAL_SLICE'and len(receipt['tests'])==7
    for path,digest in receipt['source_files'].items():assert reference(ROOT/path)['sha256']==digest,path
    modules=[]
    for role,name,installed in [('core','ResourceScannerCore.dll','ResourceScanner/ResourceScannerCore.dll'),('loader','dbghelp.dll','dbghelp.dll')]:
        item=reference(build/name);assert any(v['sha256']==item['sha256']for v in receipt['artifacts']);modules.append(dict(role=role,installed_path=installed,**item))
    reports=[build/'BUILD_RECEIPT.json',ROOT/'src/game/SOURCE_PROFILE.json',ROOT/'src/game/COMMIT_CAPTURE_SOURCE.json',
        ROOT/'src/platform/PLATFORM_CONTRACT.json',ROOT/'qa/adapter_commit/ADAPTER_REVIEW_82f8af6d8c3e.json',
        ROOT/'qa/catalog_loader/FILE_LOADER_REVIEW_4a37bedd7bd7_1e5ba36e.json',ROOT/'qa/catalog_loader/CODEC_NEGATIVE_REVIEW.json',
        ROOT/'qa/state_reader/STATE_READER_REVIEW_f83f1688bc3f.json',ROOT/'qa/ui_behavior/UI_REVIEW_74c1fc2840ab.json',
        ROOT/'qa/ui_behavior/ORDER_CARRY_REVIEW.json',ROOT/'qa/ui_behavior/AGE_PATH_CARRY_REVIEW.json',
        ROOT/'qa/ui_behavior/CATALOG_ADMISSION_REVIEW.json',ROOT/'qa/state_reader/FRAME_AGE_ADDENDUM.json']
    inputs={key:reference(ROOT/path)for key,path in dict(catalog_raw='data/build/resource_scanner.rscn',catalog_zstd='data/build/resource_scanner.rscn.zst',
        catalog_raw_receipt='data/build/resource_scanner.rscn.receipt.json',catalog_zstd_receipt='data/build/resource_scanner.rscn.zst.receipt.json',
        runtime='runtime/PACKAGE_MANIFEST.json',runtime_source_freeze='runtime/SOURCE_FREEZE.json',fonts='fonts/manifest.json',
        third_party='third_party/PROVENANCE.json',ui_source='src/ui.cpp',ui_shell='include/rs/ui_shell.hpp',catalog_source='src/catalog.cpp',catalog_header='include/rs/catalog.hpp').items()}
    summary=dict(result='PASS_INDEPENDENT_SOURCE_NATIVE_OFFLINE_CHECKS',product='ResourceScanner',version='5.0.0',complete=True,
        independent_rewrite=True,old_mod_binary_inputs=False,original_mod_routines_copied=False,
        offline_checks_complete=True,no_game_tests=True,game_tests_prohibited_by_user=True,modules=modules,input_bindings=inputs,
        reports=[reference(x)for x in reports],source_files=receipt['source_files'],
        validation_limits=['No actual game launch, injection, process read/attach, installed-file operation or save operation was performed for this rewrite by the native owner.',
            'The loader search/startup order, game observer scheduling and map projection have source/inert evidence, not a 5.0.0 in-game oracle, by user request.',
            'Vulkan presentation, texture upload/deferred destruction, six font profiles, resize and Win32 forwarding were exercised in our own hidden-window executable.',
            'No full GPU pixel-equivalence, arbitrary Thai IME shaping, multiplayer or future game-layout compatibility guarantee is claimed.'],
        installer_payload_permitted=False,release_ready=False,
        admission_note='Packaging/admission belongs to the coordinator after the final independent source/build review; preserve these source/PE bytes.')
    output=build/'NATIVE_QA_SUMMARY.json';output.write_text(json.dumps(summary,indent=2),encoding='utf8');print(reference(output))
if __name__=='__main__':main()
