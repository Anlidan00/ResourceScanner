using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace ResourceScanner.Setup {
    public static class Text {
        static Dictionary<string,Dictionary<string,string>> catalogs;
        static string current="en";
        // These three startup captions remain available if the embedded table
        // itself cannot be read. They are generated from the same translations.
        static readonly Dictionary<string,string[]> startup=new Dictionary<string,string[]> {
            {"en",new[]{"ResourceScanner","Close","The installer language data could not be loaded. Download the installer again."}},
            {"de",new[]{"Ressourcenscanner","Schlie\u00dfen","Die Sprachdaten des Installationsprogramms konnten nicht geladen werden. Lade das Installationsprogramm erneut herunter."}},
            {"fr",new[]{"Scanner de ressources","Fermer","Les donn\u00e9es linguistiques du programme d\u2019installation n\u2019ont pas pu \u00eatre charg\u00e9es. T\u00e9l\u00e9chargez-le \u00e0 nouveau."}},
            {"it",new[]{"Scanner risorse","Chiudi","Impossibile caricare i dati linguistici del programma di installazione. Scaricalo di nuovo."}},
            {"es",new[]{"Esc\u00e1ner de recursos","Cerrar","No se pudieron cargar los datos de idioma del instalador. Desc\u00e1rgalo de nuevo."}},
            {"ru",new[]{"\u0421\u043a\u0430\u043d\u0435\u0440 \u0440\u0435\u0441\u0443\u0440\u0441\u043e\u0432","\u0417\u0430\u043a\u0440\u044b\u0442\u044c","\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044c \u043f\u0435\u0440\u0435\u0432\u043e\u0434\u044b \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0449\u0438\u043a\u0430. \u0421\u043a\u0430\u0447\u0430\u0439 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0449\u0438\u043a \u0437\u0430\u043d\u043e\u0432\u043e."}},
            {"pl",new[]{"Skaner zasob\u00f3w","Zamknij","Nie uda\u0142o si\u0119 wczyta\u0107 t\u0142umacze\u0144 instalatora. Pobierz instalator ponownie."}},
            {"ja",new[]{"\u30ea\u30bd\u30fc\u30b9\u30b9\u30ad\u30e3\u30ca\u30fc","\u9589\u3058\u308b","\u30a4\u30f3\u30b9\u30c8\u30fc\u30e9\u30fc\u306e\u8a00\u8a9e\u30c7\u30fc\u30bf\u3092\u8aad\u307f\u8fbc\u3081\u307e\u305b\u3093\u3067\u3057\u305f\u3002\u30a4\u30f3\u30b9\u30c8\u30fc\u30e9\u30fc\u3092\u518d\u30c0\u30a6\u30f3\u30ed\u30fc\u30c9\u3057\u3066\u304f\u3060\u3055\u3044\u3002"}},
            {"ko",new[]{"\ub9ac\uc18c\uc2a4 \uc2a4\uce90\ub108","\ub2eb\uae30","\uc124\uce58 \ud504\ub85c\uadf8\ub7a8\uc758 \uc5b8\uc5b4 \ub370\uc774\ud130\ub97c \ubd88\ub7ec\uc624\uc9c0 \ubabb\ud588\uc2b5\ub2c8\ub2e4. \uc124\uce58 \ud504\ub85c\uadf8\ub7a8\uc744 \ub2e4\uc2dc \ub2e4\uc6b4\ub85c\ub4dc\ud574 \uc8fc\uc138\uc694."}},
            {"pt-BR",new[]{"Scanner de recursos","Fechar","N\u00e3o foi poss\u00edvel carregar os dados de idioma do instalador. Baixe o instalador novamente."}},
            {"th",new[]{"\u0e40\u0e04\u0e23\u0e37\u0e48\u0e2d\u0e07\u0e2a\u0e41\u0e01\u0e19\u0e17\u0e23\u0e31\u0e1e\u0e22\u0e32\u0e01\u0e23","\u0e1b\u0e34\u0e14","\u0e44\u0e21\u0e48\u0e2a\u0e32\u0e21\u0e32\u0e23\u0e16\u0e42\u0e2b\u0e25\u0e14\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e20\u0e32\u0e29\u0e32\u0e02\u0e2d\u0e07\u0e15\u0e31\u0e27\u0e15\u0e34\u0e14\u0e15\u0e31\u0e49\u0e07\u0e44\u0e14\u0e49 \u0e42\u0e1b\u0e23\u0e14\u0e14\u0e32\u0e27\u0e19\u0e4c\u0e42\u0e2b\u0e25\u0e14\u0e15\u0e31\u0e27\u0e15\u0e34\u0e14\u0e15\u0e31\u0e49\u0e07\u0e2d\u0e35\u0e01\u0e04\u0e23\u0e31\u0e49\u0e07"}},
            {"tr",new[]{"Kaynak Taray\u0131c\u0131","Kapat","Y\u00fckleyicinin dil verileri y\u00fcklenemedi. Y\u00fckleyiciyi yeniden indirin."}},
            {"zh-CN",new[]{"\u8d44\u6e90\u626b\u63cf\u5668","\u5173\u95ed","\u65e0\u6cd5\u52a0\u8f7d\u5b89\u88c5\u7a0b\u5e8f\u7684\u8bed\u8a00\u6570\u636e\u3002\u8bf7\u91cd\u65b0\u4e0b\u8f7d\u5b89\u88c5\u7a0b\u5e8f\u3002"}},
            {"zh-TW",new[]{"\u8cc7\u6e90\u6383\u63cf\u5668","\u95dc\u9589","\u7121\u6cd5\u8f09\u5165\u5b89\u88dd\u7a0b\u5f0f\u7684\u8a9e\u8a00\u8cc7\u6599\u3002\u8acb\u91cd\u65b0\u4e0b\u8f09\u5b89\u88dd\u7a0b\u5f0f\u3002"}},
            {"uk",new[]{"\u0421\u043a\u0430\u043d\u0435\u0440 \u0440\u0435\u0441\u0443\u0440\u0441\u0456\u0432","\u0417\u0430\u043a\u0440\u0438\u0442\u0438","\u041d\u0435 \u0432\u0434\u0430\u043b\u043e\u0441\u044f \u0437\u0430\u0432\u0430\u043d\u0442\u0430\u0436\u0438\u0442\u0438 \u043f\u0435\u0440\u0435\u043a\u043b\u0430\u0434\u0438 \u0456\u043d\u0441\u0442\u0430\u043b\u044f\u0442\u043e\u0440\u0430. \u0417\u0430\u0432\u0430\u043d\u0442\u0430\u0436 \u0456\u043d\u0441\u0442\u0430\u043b\u044f\u0442\u043e\u0440 \u0437\u043d\u043e\u0432\u0443."}},
        };
        static string Language(string culture) {
            string tag=(culture??"en").Replace('_','-');string key=tag.Split('-')[0].ToLowerInvariant();
            if(key=="zh")key=(tag.IndexOf("TW",StringComparison.OrdinalIgnoreCase)>=0||tag.IndexOf("HK",StringComparison.OrdinalIgnoreCase)>=0||tag.IndexOf("Hant",StringComparison.OrdinalIgnoreCase)>=0)?"zh-TW":"zh-CN";
            if(key=="pt")key="pt-BR";return startup.ContainsKey(key)?key:"en";
        }
        public static void Load(Stream stream,string culture) {
            current=Language(culture);catalogs=null;
            try {
                using(var reader=new StreamReader(stream,new UTF8Encoding(false,true)))catalogs=new JavaScriptSerializer{MaxJsonLength=1048576}.Deserialize<Dictionary<string,Dictionary<string,string>>>(reader.ReadToEnd());
                if(catalogs==null||!catalogs.ContainsKey("en")||catalogs["en"]==null||catalogs.Count!=15||catalogs.Values.Any(c=>c==null||c.Count!=catalogs["en"].Count||c.Any(k=>!catalogs["en"].ContainsKey(k.Key)||String.IsNullOrWhiteSpace(k.Value))))throw new InvalidDataException();
            }catch(Exception){catalogs=null;throw new SetupException(startup[current][2]);}
        }
        public static string Get(string key) {
            string value;Dictionary<string,string> selected;
            if(catalogs!=null&&catalogs.TryGetValue(current,out selected)&&selected.TryGetValue(key,out value))return value;
            if(catalogs!=null&&catalogs["en"].TryGetValue(key,out value))return value;
            if(key=="ui.title")return startup[current][0];if(key=="ui.close")return startup[current][1];
            if(catalogs!=null&&catalogs.TryGetValue(current,out selected)&&selected.TryGetValue("error.operation_failed",out value))return value;
            return startup[current][2];
        }
        public static string ErrorMessage(Exception error) {
            if(error is SetupException)return error.Message;
            if(error is UnauthorizedAccessException||error is System.Security.SecurityException)return Get("error.access_denied");
            if(error is InvalidDataException||error is DecoderFallbackException||error is FormatException)return Get("error.invalid_data");
            if(error is ArgumentException||error is NotSupportedException||error is PathTooLongException)return Get("error.invalid_path");
            return Get("error.operation_failed");
        }
    }
    public static class PackageReader {
        public static Package Read(Stream input) {
            using(var archive=new ZipArchive(input,ZipArchiveMode.Read)) {
                var metadata=archive.GetEntry("package.json");if(metadata==null||metadata.Length>1048576)throw new SetupException(Text.Get("payload.invalid_file_list"));
                PackageInfo info;
                using(var reader=new StreamReader(metadata.Open(),new UTF8Encoding(false,true)))info=new JavaScriptSerializer{MaxJsonLength=1048576}.Deserialize<PackageInfo>(reader.ReadToEnd());
                if(info==null||info.files==null||info.files.Length>128)throw new SetupException(Text.Get("payload.invalid_file_list"));
                var content=new Dictionary<string,byte[]>(StringComparer.OrdinalIgnoreCase);long total=0;
                foreach(var row in info.files) {
                    if(row==null||row.bytes<0||row.bytes>268435456)throw new SetupException(Text.Get("payload.invalid_file_list"));
                    var item=archive.GetEntry(row.path);if(item==null||item.Length!=row.bytes)throw new SetupException(Text.Get("payload.file_verification_failed"));
                    total+=row.bytes;if(total>536870912)throw new SetupException(Text.Get("install.backup_too_large"));
                    var bytes=new byte[(int)row.bytes];
                    using(var stream=item.Open()){int done=0;while(done<bytes.Length){int n=stream.Read(bytes,done,bytes.Length-done);if(n==0)throw new SetupException(Text.Get("payload.file_verification_failed"));done+=n;}if(stream.ReadByte()!=-1)throw new SetupException(Text.Get("payload.file_verification_failed"));}
                    content.Add(row.path,bytes);
                }
                if(archive.Entries.Count!=content.Count+1)throw new SetupException(Text.Get("payload.extra_files"));
                var package=new Package{Info=info,Content=content};Installer.Validate(package);return package;
            }
        }
    }
    public static class SteamGames {
        static string SmallText(string path) {
            try {
                using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)) {
                    if(stream.Length>1048576)return "";int length=(int)stream.Length;var bytes=new byte[length];int done=0;
                    while(done<length){int n=stream.Read(bytes,done,length-done);if(n==0)return "";done+=n;}
                    if(stream.Length!=length||stream.ReadByte()!=-1)return "";return new UTF8Encoding(false,true).GetString(bytes).TrimStart('\ufeff');
                }
            }catch(IOException){return "";}catch(UnauthorizedAccessException){return "";}catch(ArgumentException){return "";}
        }
        static void Add(HashSet<string> roots,string path) {
            if(String.IsNullOrWhiteSpace(path)||path.Length>32767||!Path.IsPathRooted(path)||path.Any(Char.IsControl))return;
            try{roots.Add(Path.GetFullPath(path));}catch(ArgumentException){}catch(NotSupportedException){}catch(PathTooLongException){}
        }
        public static string[] Find() {
            var libraries=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(string registry in new[]{@"HKEY_CURRENT_USER\Software\Valve\Steam",@"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam"}) {
                try{foreach(string key in new[]{"SteamPath","InstallPath"})Add(libraries,Registry.GetValue(registry,key,null)as string);}catch(System.Security.SecurityException){}catch(UnauthorizedAccessException){}
            }
            Add(libraries,Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Steam"));
            foreach(string library in libraries.ToArray())foreach(Match found in Regex.Matches(SmallText(Path.Combine(library,"steamapps","libraryfolders.vdf")),"\"path\"\\s+\"([^\"]+)\""))Add(libraries,found.Groups[1].Value.Replace("\\\\","\\"));
            var games=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(string library in libraries) {
                string directory="Enshrouded";var text=SmallText(Path.Combine(library,"steamapps","appmanifest_1203620.acf"));var match=Regex.Match(text,"\"installdir\"\\s+\"([^\"]+)\"");
                if(match.Success&&match.Groups[1].Value==Path.GetFileName(match.Groups[1].Value))directory=match.Groups[1].Value;
                var game=Path.Combine(library,"steamapps","common",directory);if(File.Exists(Path.Combine(game,"enshrouded.exe")))games.Add(game);
            }
            return games.OrderBy(s=>s,StringComparer.OrdinalIgnoreCase).ToArray();
        }
    }
    public static class Theme {
        public static readonly Color Background=Color.FromArgb(32,33,37),Frame=Color.FromArgb(50,51,56),Text=Color.FromArgb(233,226,207),Muted=Color.FromArgb(165,159,146),Gold=Color.FromArgb(211,188,128),Border=Color.FromArgb(141,128,92),Button=Color.FromArgb(63,58,45),Hover=Color.FromArgb(102,88,59),Pressed=Color.FromArgb(141,119,73);
        [DllImport("dwmapi.dll")]static extern int DwmSetWindowAttribute(IntPtr window,int attribute,ref int value,int bytes);
        public static void DarkTitle(IntPtr window){try{int enabled=1;if(DwmSetWindowAttribute(window,20,ref enabled,4)!=0)DwmSetWindowAttribute(window,19,ref enabled,4);}catch(DllNotFoundException){}catch(EntryPointNotFoundException){}catch(ExternalException){}}
        public static Form CreateErrorForm(string message){string title=ResourceScanner.Setup.Text.Get("ui.title");var font=new Font("Segoe UI",10);var form=new Form{Text=title+" "+Installer.Version,ClientSize=new Size(620,250),BackColor=Background,ForeColor=Text,Font=font,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,StartPosition=FormStartPosition.CenterScreen,AutoScaleDimensions=new SizeF(96,96),AutoScaleMode=AutoScaleMode.Dpi};string caption=ResourceScanner.Setup.Text.Get("ui.close");var label=new Label{Text=message,ForeColor=Text,BackColor=Frame,Location=new Point(12,12),Size=new Size(556,132)};var panel=new DarkPanel{Location=new Point(20,20),Size=new Size(580,156)};panel.Controls.Add(label);var close=new DarkButton{Text=caption,Location=new Point(420,194),Size=new Size(180,38),DialogResult=DialogResult.OK};form.Controls.AddRange(new Control[]{panel,close});form.AcceptButton=close;form.CancelButton=close;form.HandleCreated+=delegate{DarkTitle(form.Handle);};form.Disposed+=delegate{font.Dispose();};return form;}
        public static void ShowError(string message){using(var form=CreateErrorForm(message))form.ShowDialog();}
        public static GraphicsPath Round(RectangleF box,float radius) {
            var p=new GraphicsPath();float d=Math.Min(radius*2,Math.Min(box.Width,box.Height));
            if(d<=0){p.AddRectangle(box);return p;}
            p.AddArc(box.X,box.Y,d,d,180,90);p.AddArc(box.Right-d,box.Y,d,d,270,90);p.AddArc(box.Right-d,box.Bottom-d,d,d,0,90);p.AddArc(box.X,box.Bottom-d,d,d,90,90);p.CloseFigure();return p;
        }
        public static void Plate(Graphics g,Rectangle bounds,Color fill,Color border,float radius) {
            if(bounds.Width<2||bounds.Height<2)return;g.SmoothingMode=SmoothingMode.AntiAlias;
            using(var p=Round(new RectangleF(.5f,.5f,bounds.Width-1,bounds.Height-1),radius))using(var b=new SolidBrush(fill))using(var pen=new Pen(border)){g.FillPath(b,p);g.DrawPath(pen,p);}
        }
    }
    public sealed class DarkPanel:Panel {
        public DarkPanel(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);BackColor=Theme.Background;}
        protected override void OnPaint(PaintEventArgs e){Theme.Plate(e.Graphics,ClientRectangle,Theme.Frame,Theme.Border,8*e.Graphics.DpiX/96);}
    }
    public sealed class DarkButton:Button {
        bool hover,down;
        public DarkButton(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);FlatStyle=FlatStyle.Flat;FlatAppearance.BorderSize=0;UseVisualStyleBackColor=false;BackColor=Theme.Background;ForeColor=Theme.Text;}
        protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
        protected override void OnMouseLeave(EventArgs e){hover=down=false;Invalidate();base.OnMouseLeave(e);}
        protected override void OnMouseDown(MouseEventArgs e){if(e.Button==MouseButtons.Left)down=true;Invalidate();base.OnMouseDown(e);}
        protected override void OnMouseUp(MouseEventArgs e){down=false;Invalidate();base.OnMouseUp(e);}
        protected override void OnKeyDown(KeyEventArgs e){if(e.KeyCode==Keys.Space||e.KeyCode==Keys.Enter)down=true;Invalidate();base.OnKeyDown(e);}
        protected override void OnKeyUp(KeyEventArgs e){down=false;Invalidate();base.OnKeyUp(e);}
        protected override void OnGotFocus(EventArgs e){Invalidate();base.OnGotFocus(e);}
        protected override void OnLostFocus(EventArgs e){down=false;Invalidate();base.OnLostFocus(e);}
        protected override void OnEnabledChanged(EventArgs e){Invalidate();base.OnEnabledChanged(e);}
        protected override void OnPaint(PaintEventArgs e){e.Graphics.Clear(BackColor);float s=e.Graphics.DpiX/96;Theme.Plate(e.Graphics,ClientRectangle,!Enabled?Theme.Frame:down?Theme.Pressed:hover?Theme.Hover:Theme.Button,Theme.Border,8*s);TextRenderer.DrawText(e.Graphics,Text,Font,ClientRectangle,Enabled?Theme.Text:Theme.Muted,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine);if(Focused&&ShowFocusCues){var r=ClientRectangle;r.Inflate(-5,-5);ControlPaint.DrawFocusRectangle(e.Graphics,r,Theme.Gold,Theme.Button);}}
    }
    public sealed class DarkCheckBox:CheckBox {
        bool hover;
        public DarkCheckBox(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);BackColor=Theme.Background;ForeColor=Theme.Text;AutoSize=false;}
        protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
        protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
        protected override void OnCheckedChanged(EventArgs e){Invalidate();base.OnCheckedChanged(e);}
        protected override void OnGotFocus(EventArgs e){Invalidate();base.OnGotFocus(e);}
        protected override void OnLostFocus(EventArgs e){Invalidate();base.OnLostFocus(e);}
        protected override void OnEnabledChanged(EventArgs e){Invalidate();base.OnEnabledChanged(e);}
        protected override void OnPaint(PaintEventArgs e){e.Graphics.Clear(BackColor);float s=e.Graphics.DpiX/96;Theme.Plate(e.Graphics,ClientRectangle,hover&&Enabled?Theme.Frame:Theme.Background,Color.FromArgb(90,Theme.Border),8*s);float edge=18*s,x=10*s,y=(Height-edge)/2;using(var p=Theme.Round(new RectangleF(x,y,edge,edge),4*s))using(var b=new SolidBrush(Checked?Theme.Gold:Theme.Frame))using(var pen=new Pen(Theme.Border,Math.Max(1,s))){e.Graphics.FillPath(b,p);e.Graphics.DrawPath(pen,p);}if(Checked){using(var pen=new Pen(Theme.Background,2*s)){pen.StartCap=pen.EndCap=LineCap.Round;pen.LineJoin=LineJoin.Round;e.Graphics.DrawLines(pen,new[]{new PointF(x+edge*.22f,y+edge*.52f),new PointF(x+edge*.43f,y+edge*.73f),new PointF(x+edge*.79f,y+edge*.28f)});}}var text=new Rectangle((int)(38*s),0,Math.Max(0,Width-(int)(48*s)),Height);TextRenderer.DrawText(e.Graphics,Text,Font,text,Enabled?Theme.Text:Theme.Muted,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine);if(Focused&&ShowFocusCues){text.Inflate(0,-5);ControlPaint.DrawFocusRectangle(e.Graphics,text,Theme.Gold,Theme.Background);}}
    }
    public sealed class DarkField:Panel {
        public readonly TextBox Input=new TextBox{BorderStyle=BorderStyle.None,BackColor=Theme.Frame,ForeColor=Theme.Text};
        public DarkField(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.ResizeRedraw,true);BackColor=Theme.Background;TabStop=false;Controls.Add(Input);}
        protected override void OnResize(EventArgs e){base.OnResize(e);LayoutInput();}
        protected override void OnFontChanged(EventArgs e){base.OnFontChanged(e);if(Input!=null){Input.Font=Font;LayoutInput();}}
        void LayoutInput(){if(Input==null)return;int padding=Math.Max(8,Height/4);Input.SetBounds(padding,Math.Max(1,(Height-Input.PreferredHeight)/2),Math.Max(1,Width-padding*2),Input.PreferredHeight);}
        protected override void OnPaint(PaintEventArgs e){Theme.Plate(e.Graphics,ClientRectangle,Theme.Frame,Theme.Border,8*e.Graphics.DpiX/96);}
    }
    public sealed class SetupForm:Form {
        readonly DarkField folder;readonly DarkCheckBox known,extraZoom,explored;readonly DarkButton browse,install,remove;readonly Label status;readonly Font bodyFont,titleFont;readonly Package package;
        public SetupForm(Package value,string initialFolder){
            package=value;AutoScaleDimensions=new SizeF(96,96);AutoScaleMode=AutoScaleMode.Dpi;ClientSize=new Size(760,520);Text=ResourceScanner.Setup.Text.Get("ui.title")+" "+Installer.Version;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=true;StartPosition=FormStartPosition.CenterScreen;BackColor=Theme.Background;ForeColor=Theme.Text;bodyFont=new Font("Segoe UI",10);titleFont=new Font("Segoe UI",14,FontStyle.Bold);Font=bodyFont;
            var title=new Label{Name="ProductTitle",Text=ResourceScanner.Setup.Text.Get("ui.title")+" "+Installer.Version,Location=new Point(24,20),Size=new Size(712,34),Font=titleFont,ForeColor=Theme.Gold};
            var topLine=new Panel{Location=new Point(24,64),Size=new Size(712,1),BackColor=Theme.Border};
            var label=new Label{Text=ResourceScanner.Setup.Text.Get("ui.game_folder"),Location=new Point(24,80),Size=new Size(712,22),ForeColor=Theme.Text};
            folder=new DarkField{Name="GameFolder",Location=new Point(24,108),Size=new Size(624,40),TabIndex=0};folder.Input.Text=initialFolder??"";folder.Input.AccessibleName=ResourceScanner.Setup.Text.Get("ui.game_folder");folder.Input.TabIndex=0;
            browse=new DarkButton{Name="Browse",Text="…",Location=new Point(660,108),Size=new Size(76,40),TabIndex=1,AccessibleName=ResourceScanner.Setup.Text.Get("ui.game_folder")};
            browse.Click+=delegate{using(var picker=new FolderBrowserDialog()){picker.Description=ResourceScanner.Setup.Text.Get("game.choose_folder");picker.SelectedPath=folder.Input.Text;if(picker.ShowDialog(this)==DialogResult.OK)folder.Input.Text=picker.SelectedPath;}};
            known=new DarkCheckBox{Name="KnownItemsOnly",Text=ResourceScanner.Setup.Text.Get("ui.known_items"),Checked=true,Location=new Point(24,170),Size=new Size(712,38),TabIndex=2};
            extraZoom=new DarkCheckBox{Name="ExtraZoomOut",Text=ResourceScanner.Setup.Text.Get("ui.extra_zoom"),Checked=true,Location=new Point(24,214),Size=new Size(712,38),TabIndex=3};
            explored=new DarkCheckBox{Name="ExploredOnly",Text=ResourceScanner.Setup.Text.Get("ui.explored_only"),Checked=true,Location=new Point(24,258),Size=new Size(712,38),TabIndex=4};
            var lowerLine=new Panel{Location=new Point(24,314),Size=new Size(712,1),BackColor=Theme.Border};
            install=new DarkButton{Name="Install",Text=ResourceScanner.Setup.Text.Get("ui.install"),Location=new Point(24,334),Size=new Size(348,44),TabIndex=5};
            remove=new DarkButton{Name="Uninstall",Text=ResourceScanner.Setup.Text.Get("ui.uninstall"),Location=new Point(388,334),Size=new Size(348,44),TabIndex=6};
            var statusPanel=new DarkPanel{Name="StatusPanel",Location=new Point(24,398),Size=new Size(712,98)};
            status=new Label{Name="Status",Location=new Point(12,12),Size=new Size(688,74),Text=ResourceScanner.Setup.Text.Get("game.choose_folder"),BackColor=Theme.Frame,ForeColor=Theme.Text};statusPanel.Controls.Add(status);
            install.Click+=Action;remove.Click+=Action;Controls.AddRange(new Control[]{title,topLine,label,folder,browse,known,extraZoom,explored,lowerLine,install,remove,statusPanel});
        }
        void Action(object sender,EventArgs args){install.Enabled=remove.Enabled=browse.Enabled=known.Enabled=extraZoom.Enabled=explored.Enabled=false;folder.Input.ReadOnly=true;UseWaitCursor=true;try{if(sender==install){Installer.Install(folder.Input.Text,package,known.Checked,extraZoom.Checked,explored.Checked);status.Text=ResourceScanner.Setup.Text.Get("ui.installed");}else{Installer.Uninstall(folder.Input.Text,package);status.Text=ResourceScanner.Setup.Text.Get("ui.uninstalled");}}catch(Exception error){status.Text=ResourceScanner.Setup.Text.ErrorMessage(error);}finally{install.Enabled=remove.Enabled=browse.Enabled=known.Enabled=extraZoom.Enabled=explored.Enabled=true;folder.Input.ReadOnly=false;UseWaitCursor=false;}}
        protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);Theme.DarkTitle(Handle);}
        protected override void Dispose(bool disposing){base.Dispose(disposing);if(disposing){if(titleFont!=null)titleFont.Dispose();if(bodyFont!=null)bodyFont.Dispose();}}
    }
    public static class Program {
        [STAThread]public static void Main() {
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
            try {
                var assembly=Assembly.GetExecutingAssembly();using(var languages=assembly.GetManifestResourceStream("ResourceScanner.Translations.json"))Text.Load(languages,CultureInfo.CurrentUICulture.Name);
                Package package;using(var payload=assembly.GetManifestResourceStream("ResourceScanner.Package.zip"))package=PackageReader.Read(payload);
                using(var form=new SetupForm(package,SteamGames.Find().FirstOrDefault()??""))Application.Run(form);
            }catch(Exception error){Theme.ShowError(Text.ErrorMessage(error));}
        }
    }
}
