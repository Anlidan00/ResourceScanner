"""Build ResourceScanner5 only after exact source/payload origin admission."""
import argparse,hashlib,json,subprocess,zipfile
from pathlib import Path,PurePosixPath

ROOT=Path(__file__).resolve().parents[2]
VERSION="5.0.8"
ENTRYPOINT="vulkan-1.dll"
def sha(data):return hashlib.sha256(data).hexdigest()
def bounded_json(path):
    with path.open('rb')as stream:data=stream.read(16*1024*1024+1)
    if len(data)>16*1024*1024:raise ValueError('Build input JSON exceeds bounds')
    return data,json.loads(data)
def load(path):return bounded_json(path)[1]
def root_admission(spec,review_raw):
    if spec.get('status')!='SOURCE_HASHES_ADMITTED_FOR_PACKAGE_BUILD':raise ValueError('Draft package is not admitted')
    evidence=spec.get('admission',{});relative=evidence.get('path')
    if not isinstance(relative,str):raise ValueError('Root release admission is required')
    path=(ROOT/relative).resolve()
    if not path.is_relative_to(ROOT):raise ValueError('External release admission refused')
    raw,record=bounded_json(path)
    entries=sha(json.dumps(spec['files'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8'))
    if sha(raw)!=evidence.get('sha256')or record.get('result')!='PASS_INDEPENDENT_RESOURCE_SCANNER_PACKAGE_ADMISSION'or record.get('product')!='ResourceScanner'or record.get('version')!=VERSION or record.get('package_entries_sha256')!=entries or record.get('origin_review_sha256')!=sha(review_raw):raise ValueError('Root release admission does not bind this exact closure')
    return sha(raw)
def safe_name(name):
    if not isinstance(name,str)or'\\'in name or':'in name:return False
    p=PurePosixPath(name)
    if not name or p.is_absolute()or str(p)!=name or len(name)>240:return False
    for x in p.parts:
        if x in ('','.','..')or x.endswith((' ','.'))or'~'in x or any(ord(c)<32 or c in '<>"|?*'for c in x):return False
        device=x.split('.')[0].upper()
        if device in ('CON','PRN','AUX','NUL','CLOCK$','CONIN$','CONOUT$')or len(device)==4 and device[:3]in('COM','LPT')and device[3]in'123456789¹²³':return False
    if name!=ENTRYPOINT and not name.startswith('ResourceScanner/'):return False
    return name.casefold()not in ('resourcescanner/install.json','resourcescanner/settings.ini')
def build(spec_path,origin_path,output):
    spec=load(spec_path);review_raw,review=bounded_json(origin_path)
    if review.get('result')!='PASS_PROVENANCE_GUARDS' or review.get('issues'):raise ValueError('Exact provenance admission is required')
    admission_sha256=root_admission(spec,review_raw)
    admitted={(r['path'],r['sha256'])for r in review['checked']}
    def source(relative):
        path=(ROOT/relative).resolve()
        if not path.is_relative_to(ROOT)or not path.is_file():raise ValueError('External or missing source')
        with path.open('rb')as stream:data=stream.read(268435457)
        if len(data)>268435456 or (relative,sha(data))not in admitted:raise ValueError('Source origin not admitted or changed: '+relative)
        return data
    if spec.get('version')!=VERSION or spec.get('entrypoint')!=ENTRYPOINT:raise ValueError('Unsupported product/version')
    files=[];content={};total=0
    for row in spec['files']:
        name=row['path']
        if not safe_name(name)or name.casefold()in{v.casefold()for v in content}:raise ValueError('Invalid payload path')
        data=source(row['source']);digest=sha(data)
        if digest!=row['sha256']:raise ValueError('Payload source changed')
        total+=len(data)
        if total>536870912 or len(files)>=128:raise ValueError('Payload exceeds bounds')
        files.append(dict(path=name,bytes=len(data),sha256=digest));content[name]=data
    if ENTRYPOINT not in content or 'ResourceScanner/ResourceScannerCore.dll'not in content or 'ResourceScanner/resource_scanner.rscn.zst'not in content:raise ValueError('Required independent components absent')
    installer_sources=['installer/v5_0_8/InstallCore.cs','installer/v5_0_8/SetupUi.cs'];strings=source('installer/v5_0_8/strings.json')
    for name in installer_sources:source(name)
    stage=output.parent/('build-'+sha(json.dumps(files,sort_keys=True).encode())[:16]);stage.mkdir(parents=True,exist_ok=False)
    package=stage/'package.zip';metadata=dict(schema='resource-scanner-package-v1',version=VERSION,entrypoint=ENTRYPOINT,files=files)
    with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
        archive.writestr('package.json',json.dumps(metadata,separators=(',',':')).encode())
        for name,data in content.items():archive.writestr(name,data,compress_type=zipfile.ZIP_STORED if name.endswith('.zst')else zipfile.ZIP_DEFLATED)
    (stage/'strings.json').write_bytes(strings)
    for name in installer_sources:(stage/Path(name).name).write_bytes(source(name))
    target=stage/'ResourceScannerSetup.exe'
    compiler=Path('C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe')
    cmd=[str(compiler),'/nologo','/optimize+','/target:winexe','/platform:x64','/main:ResourceScanner.Setup.Program','/out:'+str(target),'/resource:'+str(package)+',ResourceScanner.Package.zip','/resource:'+str(stage/'strings.json')+',ResourceScanner.Translations.json']+['/reference:'+name for name in ['System.Web.Extensions.dll','System.Windows.Forms.dll','System.Drawing.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll']]+[str(stage/Path(name).name)for name in installer_sources]
    subprocess.run(cmd,check=True);output.parent.mkdir(parents=True,exist_ok=True)
    if output.exists():raise ValueError('Refusing to overwrite previous deliverable')
    output.write_bytes(target.read_bytes())
    receipt=dict(result='BUILT_INDEPENDENT_RESOURCE_SCANNER_INSTALLER_REQUIRES_ACTUAL_PACKAGE_PEER',version=VERSION,output_sha256=sha(output.read_bytes()),output_bytes=output.stat().st_size,package_sha256=sha(package.read_bytes()),package_files=files,source_spec_sha256=sha(spec_path.read_bytes()),origin_review_sha256=sha(review_raw),root_admission_sha256=admission_sha256,compiler=str(compiler),only_independent_product_payload=True)
    output.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');return receipt

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('spec',type=Path);parser.add_argument('origin_review',type=Path);parser.add_argument('output',type=Path);args=parser.parse_args();print(json.dumps(build(args.spec,args.origin_review,args.output)))
