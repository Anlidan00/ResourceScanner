param([string]$BuildDirectory = 'build', [switch]$SkipFetch)
$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path $PSScriptRoot -Parent
$pythonCommand = (Get-Command python -ErrorAction Stop).Source
& $pythonCommand -B (Join-Path $PSScriptRoot 'verify_sources.py')
if ($LASTEXITCODE) { throw 'Source verification failed' }
if (-not $SkipFetch) {
    & $pythonCommand -B (Join-Path $PSScriptRoot 'fetch_dependencies.py')
    if ($LASTEXITCODE) { throw 'Dependency fetch failed' }
}
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$vsRoot = if (Test-Path -LiteralPath $vswhere) { & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath }
if (-not $vsRoot -and (Test-Path -LiteralPath 'C:\BuildTools\VC\Auxiliary\Build\vcvars64.bat')) { $vsRoot = 'C:\BuildTools' }
if (-not $vsRoot) { throw 'MSVC x64 Build Tools are required' }
$vcvars = Join-Path $vsRoot 'VC\Auxiliary\Build\vcvars64.bat'
$env:VSLANG = '1033'
$environmentLines = & $env:ComSpec /d /s /c "`"$vcvars`" >nul && set"
foreach ($line in $environmentLines) {
    if ($line -match '^([^=]+)=(.*)$') { [Environment]::SetEnvironmentVariable($matches[1], $matches[2], 'Process') }
}
$cmake = Join-Path $vsRoot 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
$ninja = Join-Path $vsRoot 'Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe'
if (-not (Test-Path -LiteralPath $cmake)) { $cmake = (Get-Command cmake -ErrorAction Stop).Source }
if (-not (Test-Path -LiteralPath $ninja)) { $ninja = (Get-Command ninja -ErrorAction Stop).Source }
$buildRoot = Join-Path $repoRoot $BuildDirectory
& $cmake -S (Join-Path $repoRoot 'native') -B (Join-Path $buildRoot 'native') -G Ninja "-DCMAKE_MAKE_PROGRAM=$ninja" '-DCMAKE_BUILD_TYPE=Release' '-DCMAKE_TRY_COMPILE_CONFIGURATION=Release' '-DCMAKE_C_FLAGS_DEBUG=/Od /Z7' '-DCMAKE_CXX_FLAGS_DEBUG=/Od /Z7' '-DBUILD_TESTING=OFF' "-DPython3_EXECUTABLE=$pythonCommand"
if ($LASTEXITCODE) { throw 'Core configure failed' }
& $cmake --build (Join-Path $buildRoot 'native') --target ResourceScannerCore --parallel 4
if ($LASTEXITCODE) { throw 'Core build failed' }
& $cmake -S (Join-Path $repoRoot 'loader') -B (Join-Path $buildRoot 'loader') -G Ninja "-DCMAKE_MAKE_PROGRAM=$ninja" '-DCMAKE_BUILD_TYPE=Release' '-DCMAKE_TRY_COMPILE_CONFIGURATION=Release' '-DCMAKE_CXX_FLAGS_DEBUG=/Od /Z7'
if ($LASTEXITCODE) { throw 'Published loader configure failed' }
& $cmake --build (Join-Path $buildRoot 'loader') --parallel 4
if ($LASTEXITCODE) { throw 'Published loader build failed' }
