"""Fetch the exact upstream source archives used by Resource Scanner 5.0.8."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, urllib.request, zipfile

ROOT = Path(__file__).resolve().parents[1]

def wanted(name, rel):
    p=PurePosixPath(rel)
    if name=='imgui':
        return len(p.parts)==1 or rel in ('backends/imgui_impl_win32.cpp','backends/imgui_impl_win32.h','backends/imgui_impl_vulkan.cpp','backends/imgui_impl_vulkan.h')
    if name in ('minhook','json'):
        return len(p.parts)==1 or p.parts[0] in ('include','src','cmake')
    if name=='zstd':return len(p.parts)==1 or p.parts[0]=='lib'
    if name=='vulkan_headers':return len(p.parts)==1 or p.parts[0] in ('include','LICENSES') or rel=='registry/vk.xml'
    return False

def main():
    for dep in json.loads((ROOT/'dependencies.lock.json').read_text()):
        request=urllib.request.Request(dep['archive_url'],headers={'User-Agent':'ResourceScanner-source-review'})
        with urllib.request.urlopen(request,timeout=120) as response:raw=response.read(512*1024*1024+1)
        if len(raw)>512*1024*1024 or hashlib.sha256(raw).hexdigest()!=dep['archive_sha256']:
            raise ValueError('Upstream archive hash mismatch: '+dep['name'])
        destination=ROOT/'native/third_party'/dep['name']
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            for info in archive.infolist():
                p=PurePosixPath(info.filename)
                if info.is_dir() or len(p.parts)<2:continue
                if p.is_absolute() or '..' in p.parts or '\\' in info.filename:raise ValueError('Unsafe archive path')
                rel=PurePosixPath(*p.parts[1:]).as_posix()
                if not wanted(dep['name'],rel):continue
                if info.file_size>64*1024*1024:raise ValueError('Oversized upstream member')
                target=destination/rel;target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(archive.read(info))
        print(dep['name'],dep['commit'],'verified')

if __name__=='__main__':main()
