"""Verify the source bytes bound to the published 5.0.8 release."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'release/source_hashes.json').read_text())
for name,expected in manifest['files'].items():
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if actual!=expected:raise SystemExit('Source changed: '+name)
print('PASS:',len(manifest['files']),'release-bound files')
