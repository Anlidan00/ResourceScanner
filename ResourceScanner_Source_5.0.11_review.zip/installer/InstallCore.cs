using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading;
using System.Globalization;
using System.Web.Script.Serialization;

namespace ResourceScanner.Setup {
    public sealed class SetupException:IOException {public SetupException(string message):base(message){}}
    public sealed class PackageFile {public string path;public long bytes;public string sha256;}
    public sealed class PackageInfo {public string schema;public string version;public string entrypoint;public PackageFile[] files;}
    public sealed class InstallState {public string schema;public string version;public string entrypoint;public PackageFile[] files;}
    public sealed class Package {
        public PackageInfo Info;
        public Dictionary<string,byte[]> Content;
    }
    public static class Installer {
        public const string Version="5.0.11";
        public const int DefaultToggleKey=45;
        public static bool ValidToggleKey(int key) {
            return key==8||key==9||key==13||key==19||key==20||key>=32&&key<=40||key==45||key==46||key>=48&&key<=57||key>=65&&key<=90||key>=96&&key<=135||key==144||key==145||key>=186&&key<=192||key>=219&&key<=222||key==226;
        }
        static bool ParseToggleKey(string value,out int key) {return Int32.TryParse(value,NumberStyles.None,CultureInfo.InvariantCulture,out key)&&ValidToggleKey(key);}
        public const string ExpectedEntrypoint="vulkan-1.dll";
        const string StateName="ResourceScanner/install.json";
        const string SettingsName="ResourceScanner/settings.ini";
        const long FileLimit=268435456;
        const long UndoLimit=536870912;
        static readonly StringComparer Names=StringComparer.OrdinalIgnoreCase;
        static readonly JavaScriptSerializer Json=new JavaScriptSerializer{MaxJsonLength=1048576,RecursionLimit=24};
        public static Action EnsureGameClosed=delegate{if(System.Diagnostics.Process.GetProcessesByName("enshrouded").Length!=0||System.Diagnostics.Process.GetProcessesByName("enshrouded_server").Length!=0)throw Error("game.close_first");};
#if TESTING
        public static Action<string> BeforeMutation=delegate{};
#endif
        [System.Diagnostics.Conditional("TESTING")]
        static void MutationBoundary(string path) {
#if TESTING
            BeforeMutation(path);
#endif
        }

        static Exception Error(string key,string detail="") {return new SetupException(Text.Get(key)+(detail.Length==0?"":"\n"+detail));}
        public static string Digest(byte[] value) {using(var h=SHA256.Create())return String.Concat(h.ComputeHash(value).Select(b=>b.ToString("x2")));}
        static bool HashText(string value) {return value!=null&&value.Length==64&&value.All(c=>c>='0'&&c<='9'||c>='a'&&c<='f');}
        static void NoRedirect(string value) {
            var path=Path.GetFullPath(value);
            for(var part=path;!String.IsNullOrEmpty(part);part=Path.GetDirectoryName(part)) {
                if((File.Exists(part)||Directory.Exists(part))&&(File.GetAttributes(part)&FileAttributes.ReparsePoint)!=0)throw Error("path.reparse");
                var next=Path.GetDirectoryName(part);if(next==part)break;
            }
        }
        static string GameRoot(string value) {
            if(String.IsNullOrWhiteSpace(value)||!Path.IsPathRooted(value)||value.Length>32767)throw Error("game.choose_folder");
            var root=Path.GetFullPath(value).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);
            NoRedirect(root);if(!Directory.Exists(root)||!File.Exists(Path.Combine(root,"enshrouded.exe")))throw Error("game.choose_folder");
            return root;
        }
        static bool Component(string value) {
            if(value.Length==0||value=="."||value==".."||value!=value.TrimEnd(' ','.')||value.Contains('~')||value.IndexOfAny(Path.GetInvalidFileNameChars())>=0)return false;
            string device=value.Split('.')[0].ToUpperInvariant();
            if(new[]{"CON","PRN","AUX","NUL","CLOCK$","CONIN$","CONOUT$"}.Contains(device))return false;
            if(device.Length==4&&(device.StartsWith("COM")||device.StartsWith("LPT"))&&"123456789¹²³".Contains(device[3]))return false;
            return true;
        }
        static bool Relative(string value) {
            return !String.IsNullOrEmpty(value)&&value.Length<=240&&!value.Contains('\\')&&!value.Contains(':')&&!value.StartsWith("/")&&value.Split('/').All(Component);
        }
        static bool Entrypoint(string value) {return Relative(value)&&Names.Equals(value,ExpectedEntrypoint);}
        static bool Owned(string relative,string entrypoint) {
            return Relative(relative)&&(Names.Equals(relative,entrypoint)||relative.StartsWith("ResourceScanner/",StringComparison.OrdinalIgnoreCase));
        }
        static string Resolve(string root,string relative,string entrypoint) {
            if(!Owned(relative,entrypoint))throw Error("path.invalid");
            var result=Path.GetFullPath(Path.Combine(root,relative.Replace('/',Path.DirectorySeparatorChar)));
            if(!result.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw Error("path.outside_game");
            NoRedirect(result);if(Directory.Exists(result))throw Error("file.folder_instead_file");return result;
        }
        static byte[] ReadBounded(string path,long limit) {
            NoRedirect(path);
            using(var input=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)) {
                long length=input.Length;if(length<0||length>limit)throw Error("install.backup_too_large");
                var bytes=new byte[(int)length];int done=0;
                while(done<bytes.Length){int n=input.Read(bytes,done,bytes.Length-done);if(n==0)throw Error("file.changed_during_operation_prefix",Path.GetFileName(path));done+=n;}
                if(input.Length!=length||input.ReadByte()!=-1)throw Error("file.changed_during_operation_prefix",Path.GetFileName(path));return bytes;
            }
        }
        static string ExistingHash(string path) {return File.Exists(path)?Digest(ReadBounded(path,FileLimit)):null;}
        static void ValidateRows(PackageFile[] rows,string entrypoint,bool productPackage) {
            if(rows==null||rows.Length==0||rows.Length>128||!Entrypoint(entrypoint))throw Error("payload.invalid_file_list");
            var names=new HashSet<string>(Names);
            foreach(var row in rows) {
                if(row==null||!Owned(row.path,entrypoint)||!names.Add(row.path)||row.bytes<0||row.bytes>FileLimit||!HashText(row.sha256))throw Error("payload.invalid_file_list");
                if(Names.Equals(row.path,StateName)||Names.Equals(row.path,SettingsName))throw Error("payload.invalid_file_list");
            }
            if(productPackage&&!names.Contains(entrypoint))throw Error("payload.missing_files");
        }
        public static void Validate(Package package) {
            if(package==null||package.Info==null||package.Info.schema!="resource-scanner-package-v1"||package.Info.version!=Version||package.Content==null)throw Error("payload.invalid_file_list");
            ValidateRows(package.Info.files,package.Info.entrypoint,true);
            if(package.Content.Count!=package.Info.files.Length)throw Error("payload.extra_files");
            foreach(var row in package.Info.files){byte[] bytes;if(!package.Content.TryGetValue(row.path,out bytes)||bytes.LongLength!=row.bytes||Digest(bytes)!=row.sha256)throw Error("payload.file_verification_failed");}
        }
        static bool ParseVersion(string value,out int[] parts) {
            parts=null;if(value==null||value.Length>17)return false;
            var fields=value.Split('.');if(fields.Length!=3)return false;var parsed=new int[3];
            for(int i=0;i<3;i++)if(fields[i].Length==0||fields[i].Length>5||fields[i].Length>1&&fields[i][0]=='0'||!Int32.TryParse(fields[i],NumberStyles.None,CultureInfo.InvariantCulture,out parsed[i])||parsed[i]>65535)return false;
            parts=parsed;return true;
        }
        static bool UpgradeableVersion(string value) {
            int[] parts;if(!ParseVersion(value,out parts))return false;
            return parts[0]>5||parts[0]==5&&(parts[1]>0||parts[1]==0&&parts[2]>=8);
        }
        static InstallState ReadState(string root,Package package,bool upgrade=false) {
            var path=Resolve(root,StateName,"placeholder.dll");if(!File.Exists(path))return null;
            try {
                var state=Json.Deserialize<InstallState>(new UTF8Encoding(false,true).GetString(ReadBounded(path,1048576)));
                if(state==null||state.schema!="resource-scanner-install-v1")throw Error("payload.invalid_file_list",StateName);
                int[] parts;if(!ParseVersion(state.version,out parts))throw Error("payload.invalid_file_list",StateName);
                if(upgrade&&!UpgradeableVersion(state.version)||!upgrade&&state.version!=Version) {
                    throw Error("install.detected_version_prefix",state.version);
                }
                ValidateRows(state.files,state.entrypoint,true);
                if(!upgrade) {
                    var expected=package.Info.files.ToDictionary(row=>row.path,Names);
                    var different=state.files.FirstOrDefault(row=>!expected.ContainsKey(row.path)||row.bytes!=expected[row.path].bytes||row.sha256!=expected[row.path].sha256);
                    var missing=package.Info.files.FirstOrDefault(row=>!state.files.Any(saved=>Names.Equals(saved.path,row.path)));
                    if(different!=null||missing!=null)throw Error("install.payload_mismatch_prefix",different!=null?different.path:missing.path);
                }
                return state;
            }catch(ArgumentException){throw Error("payload.invalid_file_list",StateName);}
        }
        static byte[] Settings(byte[] current,bool knownOnly,bool extraZoomOut,bool exploredOnly,int toggleKey) {
            if(current!=null&&current.Length>262144)throw Error("settings.too_large_unchanged");
            string content="";
            if(current!=null) {
                if(current.Length>=2&&current[0]==255&&current[1]==254)content=new UnicodeEncoding(false,true,true).GetString(current,2,current.Length-2);
                else content=new UTF8Encoding(false,true).GetString(current).TrimStart('\ufeff');
                if(content.Any(c=>Char.IsControl(c)&&c!='\r'&&c!='\n'&&c!='\t'))throw Error("settings.unknown_unchanged");
            }
            var lines=content.Replace("\r\n","\n").Split('\n').ToList();bool inSection=false,found=false,foundZoom=false,foundExplored=false,foundToggle=false,section=false;int sectionCount=0;
            for(int i=0;i<lines.Count;i++) {
                var value=lines[i].Trim();
                if(value.Length==0||value.StartsWith(";")||value.StartsWith("#"))continue;
                if(value.StartsWith("[")&&!value.EndsWith("]"))throw Error("settings.unknown_unchanged");
                if(value.StartsWith("[")&&value.EndsWith("]")) {inSection=Names.Equals(value,"[Scanner]");section|=inSection;if(inSection&&++sectionCount>1)throw Error("settings.unknown_unchanged");continue;}
                if(value.IndexOf('=')<=0)throw Error("settings.unknown_unchanged");
                int equals=value.IndexOf('=');if(inSection&&equals>0&&Names.Equals(value.Substring(0,equals).Trim(),"KnownItemsOnly")){
                    if(found)throw Error("settings.unknown_unchanged");lines[i]="KnownItemsOnly="+(knownOnly?"1":"0");found=true;
                }
                if(inSection&&equals>0&&Names.Equals(value.Substring(0,equals).Trim(),"ExtraZoomOut")){
                    if(foundZoom)throw Error("settings.unknown_unchanged");lines[i]="ExtraZoomOut="+(extraZoomOut?"1":"0");foundZoom=true;
                }
                if(inSection&&equals>0&&Names.Equals(value.Substring(0,equals).Trim(),"ExploredOnly")){
                    if(foundExplored)throw Error("settings.unknown_unchanged");lines[i]="ExploredOnly="+(exploredOnly?"1":"0");foundExplored=true;
                }
                if(inSection&&equals>0&&Names.Equals(value.Substring(0,equals).Trim(),"ToggleKey")){
                    if(foundToggle)throw Error("settings.unknown_unchanged");lines[i]="ToggleKey="+toggleKey.ToString(CultureInfo.InvariantCulture);foundToggle=true;
                }
            }
            if(!found) {
                if(section){int index=lines.FindIndex(x=>Names.Equals(x.Trim(),"[Scanner]"));lines.Insert(index+1,"KnownItemsOnly="+(knownOnly?"1":"0"));}
                else {lines.Add("[Scanner]");lines.Add("KnownItemsOnly="+(knownOnly?"1":"0"));}
            }
            if(!foundZoom) {
                int index=lines.FindIndex(x=>Names.Equals(x.Trim(),"[Scanner]"));
                lines.Insert(index+1+(!found?1:0),"ExtraZoomOut="+(extraZoomOut?"1":"0"));
            }
            if(!foundExplored) {
                int index=lines.FindIndex(x=>Names.Equals(x.Trim(),"[Scanner]"));
                lines.Insert(index+1+(!found?1:0)+(!foundZoom?1:0),"ExploredOnly="+(exploredOnly?"1":"0"));
            }
            if(!foundToggle) {
                int index=lines.FindIndex(x=>Names.Equals(x.Trim(),"[Scanner]"));
                lines.Insert(index+1+(!found?1:0)+(!foundZoom?1:0)+(!foundExplored?1:0),"ToggleKey="+toggleKey.ToString(CultureInfo.InvariantCulture));
            }
            var encoding=new UnicodeEncoding(false,true,true);return encoding.GetPreamble().Concat(encoding.GetBytes(String.Join("\r\n",lines))).ToArray();
        }
        enum OptionCheck {Invalid,Same,Different}
        public static bool TryReadOptions(string folder,out bool knownOnly,out bool extraZoomOut,out bool exploredOnly,out int toggleKey) {
            knownOnly=extraZoomOut=exploredOnly=true;toggleKey=DefaultToggleKey;
            try {
                string path=Resolve(GameRoot(folder),SettingsName,ExpectedEntrypoint);if(!File.Exists(path))return false;
                byte[] bytes=ReadBounded(path,262144);
                string content=bytes.Length>=2&&bytes[0]==255&&bytes[1]==254?new UnicodeEncoding(false,true,true).GetString(bytes,2,bytes.Length-2):new UTF8Encoding(false,true).GetString(bytes).TrimStart('\ufeff');
                if(content.Any(c=>Char.IsControl(c)&&c!='\r'&&c!='\n'&&c!='\t'))return false;
                bool inside=false;int sections=0;var options=new Dictionary<string,string>(Names);
                foreach(string raw in content.Replace("\r\n","\n").Split('\n')) {
                    string line=raw.Trim();if(line.Length==0||line.StartsWith(";")||line.StartsWith("#"))continue;
                    if(line.StartsWith("[")) {
                        if(!line.EndsWith("]"))return false;
                        inside=Names.Equals(line,"[Scanner]");if(inside&&++sections>1)return false;continue;
                    }
                    int equals=line.IndexOf('=');if(equals<=0)return false;if(!inside)continue;
                    string key=line.Substring(0,equals).Trim();if(!Names.Equals(key,"KnownItemsOnly")&&!Names.Equals(key,"ExtraZoomOut")&&!Names.Equals(key,"ExploredOnly")&&!Names.Equals(key,"ToggleKey"))continue;
                    if(options.ContainsKey(key))return false;options.Add(key,line.Substring(equals+1).Trim());
                }
                if(sections!=1||new[]{"KnownItemsOnly","ExtraZoomOut","ExploredOnly"}.Any(key=>!options.ContainsKey(key)||options[key]!="0"&&options[key]!="1"))return false;
                int parsed=DefaultToggleKey;if(options.ContainsKey("ToggleKey")&&!ParseToggleKey(options["ToggleKey"],out parsed))return false;
                knownOnly=options["KnownItemsOnly"]=="1";extraZoomOut=options["ExtraZoomOut"]=="1";exploredOnly=options["ExploredOnly"]=="1";toggleKey=parsed;return true;
            }catch(IOException){return false;}catch(ArgumentException){return false;}catch(UnauthorizedAccessException){return false;}catch(NotSupportedException){return false;}catch(System.Security.SecurityException){return false;}
        }
        static OptionCheck StoredOptionsMatch(byte[] current,bool knownOnly,bool extraZoomOut,bool exploredOnly,int toggleKey) {
            if(current==null||current.Length>262144)return OptionCheck.Invalid;
            string content;
            try {
                content=current.Length>=2&&current[0]==255&&current[1]==254
                    ?new UnicodeEncoding(false,true,true).GetString(current,2,current.Length-2)
                    :new UTF8Encoding(false,true).GetString(current).TrimStart('\ufeff');
            }catch(DecoderFallbackException){return OptionCheck.Invalid;}
            if(content.IndexOf('\0')>=0)return OptionCheck.Invalid;
            bool inside=false;int sections=0,storedToggle=0;bool foundToggle=false;var found=new Dictionary<string,bool>(Names);
            foreach(var raw in content.Replace("\r\n","\n").Split('\n')) {
                string line=raw.Trim();if(line.Length==0||line.StartsWith(";")||line.StartsWith("#"))continue;
                if(line.StartsWith("[")||line.EndsWith("]")) {
                    if(!(line.StartsWith("[")&&line.EndsWith("]")))return OptionCheck.Invalid;
                    inside=Names.Equals(line,"[Scanner]");if(inside&&++sections>1)return OptionCheck.Invalid;continue;
                }
                if(!inside)continue;int equals=line.IndexOf('=');if(equals<=0)return OptionCheck.Invalid;
                string key=line.Substring(0,equals).Trim();
                if(Names.Equals(key,"ToggleKey")) {
                    if(foundToggle||!ParseToggleKey(line.Substring(equals+1).Trim(),out storedToggle))return OptionCheck.Invalid;
                    foundToggle=true;continue;
                }
                if(!Names.Equals(key,"KnownItemsOnly")&&!Names.Equals(key,"ExtraZoomOut")&&!Names.Equals(key,"ExploredOnly"))continue;
                string value=line.Substring(equals+1).Trim();if(found.ContainsKey(key)||(value!="0"&&value!="1"))return OptionCheck.Invalid;
                found.Add(key,value=="1");
            }
            if(sections!=1||found.Count!=3||!foundToggle)return OptionCheck.Invalid;
            return found["KnownItemsOnly"]==knownOnly&&found["ExtraZoomOut"]==extraZoomOut&&found["ExploredOnly"]==exploredOnly&&storedToggle==toggleKey?OptionCheck.Same:OptionCheck.Different;
        }
        static bool ScannerSettings(byte[] bytes) {
            try {
                string text=bytes.Length>=2&&bytes[0]==255&&bytes[1]==254
                    ?new UnicodeEncoding(false,true,true).GetString(bytes,2,bytes.Length-2)
                    :new UTF8Encoding(false,true).GetString(bytes).TrimStart('\ufeff');
                if(text.IndexOf('\0')>=0)return false;
                bool section=false;var keys=new HashSet<string>(Names);
                foreach(var raw in text.Replace("\r\n","\n").Split('\n')) {
                    string line=raw.Trim();if(line.Length==0||line.StartsWith(";")||line.StartsWith("#"))continue;
                    if(line.StartsWith("[")||line.EndsWith("]")) {
                        if(section||!Names.Equals(line,"[Scanner]"))return false;section=true;continue;
                    }
                    int equals=line.IndexOf('=');if(!section||equals<=0)return false;
                    string key=line.Substring(0,equals).Trim(),value=line.Substring(equals+1).Trim();
                    if(!keys.Add(key))return false;
                    if(Names.Equals(key,"Layers")) {
                        if(value.Length>32767)return false;
                        if(value.Length!=0) {
                            var ids=new HashSet<string>(StringComparer.Ordinal);
                            foreach(var id in value.Split('|'))if(id.Length==0||id.Length>240||!ids.Add(id)||!(id[0]>='a'&&id[0]<='z'||id[0]>='A'&&id[0]<='Z'||id[0]>='0'&&id[0]<='9')||!id.All(c=>c>='a'&&c<='z'||c>='A'&&c<='Z'||c>='0'&&c<='9'||c=='-'||c=='_'||c=='.'))return false;
                        }
                    } else if(Names.Equals(key,"KnownItemsOnly")||Names.Equals(key,"ExtraZoomOut")||Names.Equals(key,"ExploredOnly")||Names.Equals(key,"Enabled")) {
                        if(value!="0"&&value!="1")return false;
                    } else if(Names.Equals(key,"ToggleKey")) {
                        int toggleKey;if(!ParseToggleKey(value,out toggleKey))return false;
                    } else return false;
                }
                return section&&keys.Contains("KnownItemsOnly")&&keys.Contains("ExtraZoomOut")&&keys.Contains("ExploredOnly");
            }catch(ArgumentException){return false;}
        }
        static bool ScannerLog(byte[] bytes,bool single) {
            try {
                string text=new UTF8Encoding(false,true).GetString(bytes).TrimStart('\ufeff');
                var lines=single?new[]{text}:text.Replace("\r\n","\n").Split('\n');int count=0;
                foreach(var line in lines) {
                    if(String.IsNullOrWhiteSpace(line))continue;
                    var item=Json.DeserializeObject(line) as Dictionary<string,object>;object app;
                    if(item==null||!item.TryGetValue("app",out app)||!String.Equals(app as string,"resource-scanner",StringComparison.Ordinal))return false;
                    count++;
                }
                return count>0;
            }catch(ArgumentException){return false;}catch(InvalidOperationException){return false;}
        }
        static byte[] ScannerRuntime(string path,string name) {
            try {
                var bytes=ReadBounded(path,Names.Equals(name,"settings.ini")?262144:1048576);
                return (Names.Equals(name,"settings.ini")?ScannerSettings(bytes):ScannerLog(bytes,Names.Equals(name,"map.log")))?bytes:null;
            }catch(IOException){return null;}catch(UnauthorizedAccessException){return null;}
        }
        sealed class Image {public byte[] Bytes;public string Before;public string After;public FileAttributes Attributes;public DateTime Modified;}
        static void Atomic(string target,byte[] bytes) {
            NoRedirect(target);var directory=Path.GetDirectoryName(target);Directory.CreateDirectory(directory);NoRedirect(directory);
            var temporary=Path.Combine(directory,".ResourceScanner-"+Guid.NewGuid().ToString("N")+".tmp");
            try {
                using(var output=new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None)){output.Write(bytes,0,bytes.Length);output.Flush(true);}
                NoRedirect(target);if(File.Exists(target))File.Replace(temporary,target,null);else File.Move(temporary,target);
            }finally{if(File.Exists(temporary))File.Delete(temporary);}
        }
        static void Change(string root,Dictionary<string,byte[]> changes,Dictionary<string,string> expectedBefore=null) {
            var images=new Dictionary<string,Image>(Names);long total=0;
            foreach(var pair in changes) {
                NoRedirect(pair.Key);var exists=File.Exists(pair.Key);var bytes=exists?ReadBounded(pair.Key,FileLimit):null;
                if(expectedBefore!=null&&expectedBefore.ContainsKey(pair.Key)&&(bytes==null?null:Digest(bytes))!=expectedBefore[pair.Key])throw Error("file.changed_during_check_prefix",Path.GetFileName(pair.Key));
                total+=bytes==null?0:bytes.LongLength;if(total>UndoLimit)throw Error("install.backup_too_large");
                images.Add(pair.Key,new Image{Bytes=bytes,Before=bytes==null?null:Digest(bytes),After=pair.Value==null?null:Digest(pair.Value),Attributes=exists?File.GetAttributes(pair.Key):FileAttributes.Normal,Modified=exists?File.GetLastWriteTimeUtc(pair.Key):DateTime.MinValue});
            }
            foreach(var pair in images)if(ExistingHash(pair.Key)!=pair.Value.Before)throw Error("file.changed_during_check_prefix",Path.GetFileName(pair.Key));
            try {
                foreach(var pair in changes){MutationBoundary(pair.Key);if(ExistingHash(pair.Key)!=images[pair.Key].Before)throw Error("file.changed_during_operation_prefix",Path.GetFileName(pair.Key));if(pair.Value==null)File.Delete(pair.Key);else Atomic(pair.Key,pair.Value);}
            }catch(Exception cause) {
                bool complete=true;
                foreach(var pair in images.Reverse()) {
                    try {
                        string now=ExistingHash(pair.Key);if(now==pair.Value.Before)continue;
                        if(now!=pair.Value.After){complete=false;continue;}
                        if(pair.Value.Bytes==null)File.Delete(pair.Key);
                        else {Atomic(pair.Key,pair.Value.Bytes);File.SetLastWriteTimeUtc(pair.Key,pair.Value.Modified);File.SetAttributes(pair.Key,pair.Value.Attributes);}
                    }catch{complete=false;}
                }
                throw Error(complete?"install.restored_after_error":"install.rollback_incomplete",Text.ErrorMessage(cause));
            }
        }
        static void Locked(string root,Action operation) {
            string identity=Digest(Encoding.UTF8.GetBytes(root.ToUpperInvariant()));
            using(var mutex=new Mutex(false,"Local\\ResourceScanner.Setup."+identity)) {
                bool owns=false;
                try{try{owns=mutex.WaitOne(0);}catch(AbandonedMutexException){owns=true;}if(!owns)throw Error("install.other_setup_running");operation();}
                finally{if(owns)mutex.ReleaseMutex();}
            }
        }
        public static void Install(string folder,Package package,bool knownOnly,bool extraZoomOut,bool exploredOnly) {
            Install(folder,package,knownOnly,extraZoomOut,exploredOnly,DefaultToggleKey);
        }
        public static void Install(string folder,Package package,bool knownOnly,bool extraZoomOut,bool exploredOnly,int toggleKey) {
            if(!ValidToggleKey(toggleKey))throw Error("settings.invalid_toggle_key");
            Validate(package);string root=GameRoot(folder);
            Locked(root,delegate {
                EnsureGameClosed();string otherCatalog=Path.Combine(root,"resource_scanner.dat");NoRedirect(otherCatalog);
                if(File.Exists(otherCatalog)||Directory.Exists(otherCatalog))throw Error("install.orphan_file_prefix","resource_scanner.dat");
                var statePath=Resolve(root,StateName,package.Info.entrypoint);var stateBefore=ExistingHash(statePath);
                var installed=ReadState(root,package,true);
                if(ExistingHash(statePath)!=stateBefore)throw Error("file.changed_during_check_prefix",Path.GetFileName(statePath));
                string settings=Resolve(root,SettingsName,package.Info.entrypoint);
                byte[] currentSettings;
                try {currentSettings=File.Exists(settings)?ReadBounded(settings,262144):null;}
                catch(IOException){if(installed!=null)throw Error("install.invalid_options",SettingsName);throw;}
                var expectedBefore=new Dictionary<string,string>(Names){{settings,currentSettings==null?null:Digest(currentSettings)},{statePath,stateBefore}};
                var changes=new Dictionary<string,byte[]>(Names);
                var oldRows=installed==null?new Dictionary<string,PackageFile>(Names):installed.files.ToDictionary(row=>row.path,Names);
                var newNames=new HashSet<string>(package.Info.files.Select(row=>row.path),Names);
                foreach(var row in oldRows.Values) {
                    string path=Resolve(root,row.path,installed.entrypoint);byte[] bytes=File.Exists(path)?ReadBounded(path,FileLimit):null;
                    string current=bytes==null?null:Digest(bytes);
                    if(bytes!=null&&(bytes.LongLength!=row.bytes||current!=row.sha256))throw Error("file.modified_or_other_version_suffix",row.path);
                    expectedBefore[path]=current;if(!newNames.Contains(row.path))changes[path]=null;
                }
                foreach(var row in package.Info.files) {
                    string path=Resolve(root,row.path,package.Info.entrypoint),current=ExistingHash(path);
                    if(current!=null&&!oldRows.ContainsKey(row.path))throw Error("install.orphan_file_prefix",row.path);
                    if(expectedBefore.ContainsKey(path)&&current!=expectedBefore[path])throw Error("file.changed_during_check_prefix",row.path);
                    changes[path]=package.Content[row.path];expectedBefore[path]=current;
                }
                changes[settings]=Settings(currentSettings,knownOnly,extraZoomOut,exploredOnly,toggleKey);
                var state=new InstallState{schema="resource-scanner-install-v1",version=Version,entrypoint=package.Info.entrypoint,files=package.Info.files};
                changes[statePath]=Encoding.UTF8.GetBytes(Json.Serialize(state));Change(root,changes,expectedBefore);
            });
        }
        public static void Uninstall(string folder,Package package) {
            Validate(package);string root=GameRoot(folder);Locked(root,delegate {
                EnsureGameClosed();var statePath=Resolve(root,StateName,package.Info.entrypoint);var stateBefore=ExistingHash(statePath);
                var state=ReadState(root,package);
                if(ExistingHash(statePath)!=stateBefore)throw Error("file.changed_during_check_prefix",Path.GetFileName(statePath));
                if(state==null)return;
                var changes=new Dictionary<string,byte[]>(Names);
                var expectedBefore=new Dictionary<string,string>(Names){{statePath,stateBefore}};
                foreach(var row in state.files) {string path=Resolve(root,row.path,state.entrypoint);var current=ExistingHash(path);if(current!=null&&current!=row.sha256)throw Error("file.modified_or_other_version_suffix",row.path);changes[path]=null;expectedBefore[path]=current;}
                // Mutable files are not in the payload ledger. Only these exact
                // names with recognized Scanner contents belong to this cleanup.
                foreach(var name in new[]{"settings.ini","native.log","map.log"}) {
                    var path=Path.Combine(root,"ResourceScanner",name);NoRedirect(path);
                    if(!File.Exists(path))continue;var bytes=ScannerRuntime(path,name);if(bytes==null)continue;
                    changes[path]=null;expectedBefore[path]=Digest(bytes);
                }
                changes[statePath]=null;Change(root,changes,expectedBefore);
                // Unknown names/contents and all directories remain untouched.
            });
        }
    }
}
