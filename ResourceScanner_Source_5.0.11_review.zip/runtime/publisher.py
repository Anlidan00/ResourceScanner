"""Shared-state mapping publisher."""
import ctypes
import struct
from ctypes import wintypes
from state_ipc import TOTAL_BYTES,MAGIC

class StatePublisher:
    def __init__(self,pid,birth,nonce):
        self.k=ctypes.WinDLL('kernel32',use_last_error=True);k=self.k
        k.CreateFileMappingW.argtypes=[wintypes.HANDLE,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.LPCWSTR];k.CreateFileMappingW.restype=wintypes.HANDLE
        k.MapViewOfFile.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,ctypes.c_size_t];k.MapViewOfFile.restype=ctypes.c_void_p
        k.CloseHandle.argtypes=[wintypes.HANDLE];k.UnmapViewOfFile.argtypes=[ctypes.c_void_p]
        self.handle=k.CreateFileMappingW(wintypes.HANDLE(-1),None,4,0,TOTAL_BYTES,'Local\\ResourceScanner.State.v1.'+str(pid));self.address=None
        if not self.handle:raise OSError(ctypes.get_last_error(),'State publication unavailable')
        existing=ctypes.get_last_error()==183
        self.address=k.MapViewOfFile(self.handle,2|4,0,0,TOTAL_BYTES)
        if not self.address:self.close();raise OSError(ctypes.get_last_error(),'State mapping unavailable')
        self.generation=0
        if existing:
            header=ctypes.string_at(self.address,64)
            if header[:8]!=MAGIC or struct.unpack_from('<I',header,32)[0]!=pid or struct.unpack_from('<QQ',header,40)!=(birth,nonce):self.close();raise ValueError('Another state owner exists')
            self.generation=struct.unpack_from('<Q',header,24)[0]&~1
    def write(self,data):
        if not self.address or len(data)!=TOTAL_BYTES:raise ValueError('Invalid state publication')
        even=(self.generation+2)&0xffffffffffffffff
        if not even:even=2
        # x64 aligned8-byte stores are atomic; store ordering publishes body
        # before the final even generation. Native readers double-copy it.
        ctypes.c_uint64.from_address(self.address+24).value=even-1
        body=bytearray(data);struct.pack_into('<Q',body,24,even-1)
        ctypes.memmove(self.address,bytes(body),TOTAL_BYTES)
        ctypes.c_uint64.from_address(self.address+24).value=even;self.generation=even
    def close(self):
        if self.address:self.k.UnmapViewOfFile(self.address);self.address=None
        if self.handle:self.k.CloseHandle(self.handle);self.handle=None
