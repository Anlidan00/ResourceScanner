import json,struct
from pathlib import Path

class LayoutUnavailable(ValueError):
    pass

class Image:
    def __init__(self,path):
        path=Path(path);before=path.stat()
        if not 4096<=before.st_size<=512*1024*1024:raise LayoutUnavailable('Module size outside bounds')
        with path.open('rb')as stream:self.data=stream.read(512*1024*1024+1)
        after=path.stat()
        if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns)or len(self.data)!=before.st_size:raise OSError('Module changed while reading')
        self.sections=[];self.cache={};self.functions=None
        try:self._headers()
        except (struct.error,IndexError,OverflowError)as error:raise LayoutUnavailable('Invalid module headers')from error
        file=Path(__file__).with_name('compat_profile.json')
        try:
            with file.open('rb')as stream:raw=stream.read(128*1024+1)
        except OSError as error:raise LayoutUnavailable('Source pattern data unavailable')from error
        if len(raw)>128*1024:raise LayoutUnavailable('Source patterns outside bounds')
        try:
            self.profiles=json.loads(raw)
            if not isinstance(self.profiles,dict)or type(self.profiles.get('schema'))is not int or self.profiles['schema']!=1:raise ValueError()
        except (ValueError,TypeError,KeyError)as error:raise LayoutUnavailable('Invalid source pattern data')from error
    def _rows(self,group):
        # A broken optional feature must not invalidate independently proven sources.
        if group not in ('hero','save','appearance','knowledge'):raise LayoutUnavailable('Unknown source group')
        rows=self.profiles.get(group)
        if not isinstance(rows,list)or not 1<=len(rows)<=64:raise LayoutUnavailable('Invalid source group')
        keys=[self._pattern(row)[0]for row in rows]
        if len(keys)!=len(set(keys))or (group=='knowledge'and 'controller'not in keys):raise LayoutUnavailable('Invalid source identities')
        return rows
    def _links(self):
        links=self.profiles.get('knowledge_links')
        if not isinstance(links,list)or not 1<=len(links)<=64:raise LayoutUnavailable('Invalid source links')
        try:
            for row in links:
                if not isinstance(row,list)or len(row)!=5:raise ValueError()
                key,caller,offset,data,mask=row;data=bytes.fromhex(data);mask=bytes.fromhex(mask)
                if not isinstance(key,str)or not isinstance(caller,str)or type(offset)is not int or offset<0 or not 1<=len(data)<=128 or len(mask)!=len(data)or any(b not in (0,255)for b in mask)or not any(mask):raise ValueError()
        except (ValueError,TypeError)as error:raise LayoutUnavailable('Invalid source links')from error
        return links
    def _headers(self):
        d=self.data
        if d[:2]!=b'MZ':raise LayoutUnavailable('Invalid module format')
        nt=struct.unpack_from('<I',d,60)[0]
        if nt>1024*1024 or d[nt:nt+4]!=b'PE\0\0':raise LayoutUnavailable('Invalid module signature')
        machine,n=struct.unpack_from('<HH',d,nt+4);optional=struct.unpack_from('<H',d,nt+20)[0];at=nt+24
        if machine!=0x8664 or not 1<=n<=96 or optional<240 or struct.unpack_from('<H',d,at)[0]!=0x20B:raise LayoutUnavailable('Unsupported module layout')
        self.preferred_base=struct.unpack_from('<Q',d,at+24)[0];self.size,self.headers=struct.unpack_from('<II',d,at+56)
        self.exception_directory=struct.unpack_from('<II',d,at+136)if struct.unpack_from('<I',d,at+108)[0]>=4 else (0,0)
        if not 4096<=self.size<=1024*1024*1024 or not 0<self.headers<=len(d):raise LayoutUnavailable('Invalid module bounds')
        for i in range(n):
            p=at+optional+i*40;vs,rva,length,offset=struct.unpack_from('<IIII',d,p+8);flags=struct.unpack_from('<I',d,p+36)[0];span=max(vs,length)
            if rva<self.headers or rva>self.size or span>self.size-rva or offset>len(d)or length>len(d)-offset:raise LayoutUnavailable('Invalid module section')
            if any(rva<old[0]+old[1]and old[0]<rva+span for old in self.sections):raise LayoutUnavailable('Overlapping module sections')
            self.sections.append((rva,span,offset,length,flags))
    def read(self,rva,size):
        if type(rva)is not int or type(size)is not int or rva<0 or size<0 or rva>self.size or size>self.size-rva:raise LayoutUnavailable('Module address outside bounds')
        if rva<self.headers and size<=self.headers-rva:return self.data[rva:rva+size]
        for start,span,offset,length,flags in self.sections:
            if start<=rva and rva-start<=length and size<=length-(rva-start):return self.data[offset+rva-start:offset+rva-start+size]
        raise LayoutUnavailable('Module bytes are not file-backed')
    def executable(self,rva,size=1):
        return any(flags&0x20000000 and start<=rva and rva-start<=span and size<=span-(rva-start)for start,span,offset,length,flags in self.sections)
    def function(self,rva):
        """Use standard x64 unwind ranges to bind witnesses to actual callees.

        Unlike a prologue signature, the range metadata does not depend on the
        compiler's register spills or the number of local variables.
        """
        if self.functions is None:
            at,size=self.exception_directory
            if not 12<=size<=16*1024*1024 or size%12:raise LayoutUnavailable('Function ranges unavailable')
            rows=list(struct.iter_unpack('<III',self.read(at,size)))
            if any(not begin<end or not self.executable(begin,end-begin)or (i and rows[i-1][1]>begin)for i,(begin,end,unwind)in enumerate(rows)):raise LayoutUnavailable('Invalid function ranges')
            self.functions=rows;self.function_starts=[row[0]for row in rows];self.function_rows=set(rows)
        low,high=0,len(self.function_starts)
        while low<high:
            middle=(low+high)//2
            if self.function_starts[middle]<=rva:low=middle+1
            else:high=middle
        index=low-1
        if index<0 or not self.functions[index][0]<=rva<self.functions[index][1]:raise LayoutUnavailable('Source function range unavailable')
        row=self.functions[index];seen=set()
        for depth in range(32):
            if row in seen:raise LayoutUnavailable('Cyclic function unwind chain')
            seen.add(row);header=self.read(row[2],4)
            if header[0]&7!=1:raise LayoutUnavailable('Unsupported function unwind schema')
            flags=header[0]>>3
            if flags&~7:raise LayoutUnavailable('Unsupported function unwind flags')
            if not flags&4:return row[:2]
            if flags&3:raise LayoutUnavailable('Invalid function unwind flags')
            chain=struct.unpack('<III',self.read(row[2]+4+((header[2]+1)&~1)*2,12))
            if chain not in self.function_rows:raise LayoutUnavailable('Function unwind owner unavailable')
            row=chain
        raise LayoutUnavailable('Function unwind chain outside bounds')
    @staticmethod
    def _pattern(row):
        if not isinstance(row,list)or len(row)!=3:raise LayoutUnavailable('Invalid source pattern')
        key,raw,mask=row
        try:data=bytes.fromhex(raw);mask=bytes.fromhex(mask)
        except (ValueError,TypeError)as error:raise LayoutUnavailable('Invalid source pattern encoding')from error
        if not isinstance(key,str)or not 12<=len(data)<=512 or len(data)!=len(mask)or any(b not in (0,255)for b in mask):raise LayoutUnavailable('Invalid source pattern size')
        runs=[];start=None
        for i,b in enumerate(mask+b'\0'):
            if b==255 and start is None:start=i
            if b!=255 and start is not None:runs.append((i-start,start));start=None
        if not runs or max(runs)[0]<4:raise LayoutUnavailable('Source pattern has no anchor')
        return key,data,mask,max(runs)
    def resolve(self,group):
        if group in self.cache:
            value=self.cache[group]
            if value is None:raise LayoutUnavailable('Source layout unavailable')
            return value
        self.cache[group]=None;result={}
        for row in self._rows(group):
            key,data,mask,(anchor_size,anchor_offset)=self._pattern(row);anchor=data[anchor_offset:anchor_offset+anchor_size];hits=[]
            for rva,span,offset,length,flags in self.sections:
                if not flags&0x20000000:continue
                raw=self.data[offset:offset+length];at=0
                while True:
                    found=raw.find(anchor,at)
                    if found<0:break
                    at=found+1;p=found-anchor_offset
                    if p>=0 and p+len(data)<=len(raw)and all(not m or raw[p+i]==data[i]for i,m in enumerate(mask)):
                        hits.append(rva+p)
                        if len(hits)>1:raise LayoutUnavailable('Source layout is ambiguous')
            if len(hits)!=1 or key in result:raise LayoutUnavailable('Source layout unavailable')
            result[key]=(hits[0],data,mask)
        if not result:raise LayoutUnavailable('Source layout unavailable')
        self.cache[group]=result;return result
    def verify(self,group,read,base):
        values=self.resolve(group)
        for rva,data,mask in values.values():
            actual=read(base+rva,len(data))
            if len(actual)!=len(data)or any(m and actual[i]!=data[i]for i,m in enumerate(mask)):raise LayoutUnavailable('Live module differs from resolved source')
        if group=='knowledge':
            targets={}
            for key,caller,offset,raw,mask in self._links():
                if caller not in values or type(offset)is not int or not 0<=offset<=len(values[caller][1])-5:raise LayoutUnavailable('Invalid source call binding')
                at=values[caller][0]+offset;call=read(base+at,5)
                if len(call)!=5 or call[0]!=0xE8:raise LayoutUnavailable('Source call unavailable')
                target=at+5+struct.unpack_from('<i',call,1)[0];data=bytes.fromhex(raw);mask=bytes.fromhex(mask)
                if key in targets and targets[key]!=target:raise LayoutUnavailable('Source callers disagree on target')
                targets[key]=target
                if not 1<=len(data)<=128 or len(mask)!=len(data)or not self.executable(target,len(data)):raise LayoutUnavailable('Source call target unavailable')
                actual=read(base+target,len(data))
                if len(actual)!=len(data)or any(m and actual[i]!=data[i]for i,m in enumerate(mask)):raise LayoutUnavailable('Source call layout differs')
        return values
    def controller(self,read,base):
        rva=self.verify('knowledge',read,base)['controller'][0];actual=read(base+rva,7)
        if len(actual)!=7 or actual[:3]!=b'\x48\x8d\x05':raise LayoutUnavailable('Controller type instruction unavailable')
        table=rva+7+struct.unpack_from('<i',actual,3)[0]
        if table%8 or not any(flags&0x40000000 and not flags&0x20000000 and start<=table and table-start<=length and 64<=length-(table-start)for start,span,offset,length,flags in self.sections):raise LayoutUnavailable('Controller type table unavailable')
        raw=self.read(table,64);targets=struct.unpack('<8Q',raw)
        if any(v<self.preferred_base or not self.executable(v-self.preferred_base)for v in targets):raise LayoutUnavailable('Controller type methods unavailable')
        expected=tuple(base+v-self.preferred_base for v in targets)
        actual=read(base+table,64)
        if len(actual)!=64 or struct.unpack('<8Q',actual)!=expected:raise LayoutUnavailable('Controller type identity changed')
        return table
    def _operand(self,values,key,offset,read,base,size=4):
        if size not in (1,4)or key not in values or not 0<=offset<=len(values[key][1])-size:raise LayoutUnavailable('Source field witness unavailable')
        rva=values[key][0]+offset;expected=self.read(rva,size);actual=read(base+rva,size)
        if len(actual)!=size or actual!=expected:raise LayoutUnavailable('Live source field differs')
        return int.from_bytes(expected,'little')
    def _field(self,values,key,offset,read,base):return self._operand(values,key,offset,read,base)
    def hero_layout(self,read,base):
        values=self.verify('hero',read,base)
        field=lambda key,offset:self._field(values,key,offset,read,base)
        selected=field('h0',19);valid=field('h0',2);loaded=field('loaded',3)
        if valid!=field('h0',11)or valid!=field('loaded',17)or selected!=field('loaded',28)or valid!=selected+2 or field('loaded',64)!=loaded+1 or field('loaded',73)!=loaded+2:raise LayoutUnavailable('Hero selection/load fields disagree')
        if not all(0<v<=4*1024*1024 for v in (selected,loaded))or abs(selected-loaded)<3:raise LayoutUnavailable('Unsupported hero field geometry')
        return dict(selected=selected,loaded=loaded)
    def save_layout(self,read,base):
        values=self.verify('save',read,base)
        directory=self._field(values,'h5',3,read,base);head=self._operand(values,'h6',3,read,base,1)
        last=self._field(values,'h6',10,read,base);first=self._field(values,'h6',17,read,base)
        call_rva=values['h5'][0]+14;call=read(base+call_rva,5)
        if len(call)!=5 or call[0]!=0xe8 or call_rva+5+struct.unpack_from('<i',call,1)[0]!=values['h6'][0]:raise LayoutUnavailable('Save-directory getter binding differs')
        if not 0<directory<=4*1024*1024 or directory%8 or head%8 or not head<first<last<=4096 or first%8 or last!=first+8:raise LayoutUnavailable('Unsupported save-directory geometry')
        return dict(directory=directory,head=head,length=first)
    def appearance_layout(self,read,base):
        """Derive fields from the native profile lookup and its actual UI caller."""
        values=self.verify('appearance',read,base)
        stride=self._field(values,'a0',17,read,base);slots=self._field(values,'a0',23,read,base)
        active=self._field(values,'a0',47,read,base);profile=self._field(values,'a2',2,read,base)
        value=self._field(values,'a2',41,read,base)
        manager=self._field(values,'a2',9,read,base)
        if not (0<manager<=4*1024*1024 and manager%8==0 and 16<=stride<=4096 and stride%8==0 and 0<slots<=1024*1024 and slots%8==0 and active==stride-16 and 0<value<active and 0<profile<=4*1024*1024 and profile%4==0):raise LayoutUnavailable('Unsupported appearance field geometry')
        caller=values['a2'][0]+29;call=read(base+caller,5)
        if len(call)!=5 or call[0]!=0xe8 or caller+5+struct.unpack_from('<i',call,1)[0]!=values['a0'][0]:raise LayoutUnavailable('Appearance lookup caller differs')
        return dict(manager=manager,profile=profile,slots=slots,stride=stride,active=active,value=value)
    def knowledge_layout(self,read,base):
        table=self.controller(read,base);values=self.resolve('knowledge')
        published=self._field(values,'controller',67,read,base);accessed=self._field(values,'controller',78,read,base)
        if published!=accessed or not 0<published<=4*1024*1024 or published%8:raise LayoutUnavailable('Controller publication field differs')
        return table,published
    def projection_layout(self,read,base):
        table,published=self.knowledge_layout(read,base);values=self.resolve('knowledge')
        field=lambda key,offset:self._field(values,key,offset,read,base)
        hero=self.hero_layout(read,base)
        method=self.function(values['k4'][0])
        if method!=self.function(values['k5'][0])or struct.unpack_from('<Q',self.read(table+24,8))[0]!=self.preferred_base+method[0]:raise LayoutUnavailable('Client publication is not the controller method')
        for caller,offset,target in [('k5',53,'k6'),('k15',22,'k16')]:
            at=values[caller][0]+offset;call=read(base+at,5)
            if len(call)!=5 or call[0]!=0xe8 or call!=self.read(at,5)or at+5+struct.unpack_from('<i',call,1)[0]!=self.function(values[target][0])[0]:raise LayoutUnavailable('Knowledge source call binding differs')
        if self.function(values['k16'][0])!=self.function(values['k17'][0]):raise LayoutUnavailable('Personal seed guard/publication functions differ')
        client=field('k4',15);outer=field('k6',22);personal=field('k10',16);active=field('k10',38);seed=field('k16',2)
        if client!=field('k5',3)or outer!=field('k15',3)or personal!=field('k13',11)or personal!=field('k14',13)or active!=field('k14',19):raise LayoutUnavailable('Knowledge owner/map fields disagree')
        if any(seed!=field(key,offset)for key,offset in [('k17',55),('k18',19),('k19',17)]):raise LayoutUnavailable('Personal seed publication/invalidation differs')
        if any(hero['loaded']+2!=field(key,offset)for key,offset in [('k16',35),('k18',12),('k19',9)]):raise LayoutUnavailable('Personal seed and loaded hero differ')
        mode=field('k10',8);manager=field('k15',15);owner=self._operand(values,'controller',74,read,base,1)
        # Storage arithmetic remains an exact protocol witness. Only address
        # operands derived above are flexible; never infer a new storage schema.
        if not all(0<v<=16*1024*1024 for v in (client,outer,personal,active,seed,mode,manager,owner))or any(v%8 for v in (client,outer,personal,manager,owner))or not 138<=active<512 or not 104<=personal or not personal+16<=mode<4096 or 192<=mode<194 or client==owner or outer==manager or any(start<=seed<start+3 for start in hero.values()):raise LayoutUnavailable('Unsupported knowledge field geometry')
        return table,published,dict(hero,client=client,outer=outer,personal=personal,active=active,seed=seed,mode=mode,manager=manager,owner=owner)
