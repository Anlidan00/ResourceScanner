"""Bounded FGOW2 explored-map decoder."""
import hashlib,struct,re
from pathlib import Path
import zstandard
WIDTH = HEIGHT = 1280
BIT_BYTES = WIDTH * HEIGHT // 8

def read_mask(path):
    path = Path(path)
    limit = 32 * 1024 * 1024
    before = path.stat()
    if before.st_size > limit:
        raise ValueError('Unsupported character container')
    with path.open('rb') as stream:
        data = stream.read(limit + 1)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError('Save is being written; retry later')
    if data[:4] != b'SV2C' or len(data) < 48 or len(data) > 32 * 1024 * 1024:
        raise ValueError('Unsupported character container')
    if struct.unpack_from('<H', data, 4)[0] != 2:
        raise ValueError('Unsupported save version')
    found = []
    view = memoryview(data)
    attempts=0
    for m in re.finditer(re.escape(b'(\xb5/\xfd'), data):
        try:
            n = zstandard.frame_content_size(view[m.start():m.start() + 18])
            expected = 8 + 5 + WIDTH * HEIGHT
            if n not in (-1, expected):
                continue
            attempts+=1
            if attempts>256:raise ValueError('Character frame scan outside bounds')
            decoder=zstandard.ZstdDecompressor(max_window_size=8*1024*1024)
            with decoder.stream_reader(view[m.start():],read_size=16384,read_across_frames=False)as prefix:
                if prefix.read(13)!=struct.pack('<II',5+WIDTH*HEIGHT,0)+b'FGOW\x02':continue
            payload = decoder.decompress(view[m.start():], max_output_size=expected)
        except zstandard.ZstdError:
            continue
        if len(payload) != expected or payload[:8] != struct.pack('<II', 5 + WIDTH * HEIGHT, 0) or payload[8:13] != b'FGOW\x02':
            continue
        if found:
            raise ValueError('Expected one FGOW2 mask, got multiple')
        found.append(payload[13:])
    if len(found) != 1:
        raise ValueError(f'Expected one FGOW2 mask, got {len(found)}')
    bits = bytearray(BIT_BYTES)
    for p, v in enumerate(found[0]):
        if v == 255:
            bits[p >> 3] |= 1 << (p & 7)
    return (bytes(bits), {'character_file': str(path.resolve()), 'character_guid': data[12:28].hex(), 'save_sha256': hashlib.sha256(data).hexdigest(), 'save_mtime_ns': after.st_mtime_ns, 'mask_sha256': hashlib.sha256(found[0]).hexdigest(), 'revealed_pixels': found[0].count(255), 'width': WIDTH, 'height': HEIGHT, 'threshold': 255, 'source': 'FGOW2 / SV2C2'})
