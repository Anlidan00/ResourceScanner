"""Read-only frame context shared by ResourceScannerCore."""
import ctypes
import math
import struct
from collections import namedtuple
from ctypes import wintypes

SIZE=256
HEADER=struct.Struct('<8sIIIIQIIQQQ')
MAGIC=b'RSFRAME1'
FILE_MAP_READ=4

class Unavailable(ValueError):pass

class Frame(namedtuple('FrameValues','generation process_id birth nonce sequence sampled_ms availability language flags application ui map_state world_guid hero_guid scope_start_sequence')):
    __slots__=()

    def world_scope(self):
        if self.availability!=1 or self.flags&11!=11 or min(self.application,self.ui,self.map_state)<0x10000 or not 0<self.scope_start_sequence<=self.sequence:
            raise Unavailable('Current map/world context is unavailable')
        return (self.process_id,self.birth,self.nonce,self.application,self.ui,self.map_state,self.world_guid,self.hero_guid,self.scope_start_sequence)

def parse(data:bytes,pid:int,birth:int,now_ms:int,max_age_ms:int=1000)->Frame:
    if len(data)!=SIZE:raise Unavailable('Incomplete frame')
    magic,version,header_bytes,payload_bytes,total,generation,owner,reserved,created,nonce,reserved1=HEADER.unpack_from(data)
    if (magic,version,header_bytes,payload_bytes,total)!=(MAGIC,1,64,192,256):raise Unavailable('Unsupported frame format')
    if generation==0 or generation&1 or reserved or reserved1 or not nonce:raise Unavailable('Frame is changing')
    if (owner,created)!=(pid,birth):raise Unavailable('Frame owner differs')
    sequence,stamp,payload_pid,availability,payload_birth,language,flags=struct.unpack_from('<QQIIQII',data,64)
    if (payload_pid,payload_birth)!=(pid,birth)or availability>3 or flags&~15:raise Unavailable('Invalid frame owner/status')
    if now_ms<stamp or now_ms-stamp>max_age_ms:raise Unavailable('Stale frame')
    geometry=struct.unpack_from('<5f',data,104)
    if any(not math.isfinite(x)for x in geometry):raise Unavailable('Invalid frame geometry')
    scope_start=struct.unpack_from('<Q',data,216)[0]
    if data[124:128]!=bytes(4)or data[224:256]!=bytes(32)or scope_start>sequence:raise Unavailable('Unsupported reserved/scope data')
    application,ui,map_state=struct.unpack_from('<QQQ',data,160)
    return Frame(generation,owner,created,nonce,sequence,stamp,availability,language,flags,application,ui,map_state,data[184:200],data[200:216],scope_start)

class FrameMapping:
    def __init__(self,pid:int,birth:int):
        if not 0<pid<=0xffffffff or not 0<birth<=0xffffffffffffffff:raise ValueError('Invalid process identity')
        self.pid,self.birth=pid,birth;self.k=ctypes.WinDLL('kernel32',use_last_error=True)
        self.k.OpenFileMappingW.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.LPCWSTR];self.k.OpenFileMappingW.restype=wintypes.HANDLE
        self.k.MapViewOfFile.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,ctypes.c_size_t];self.k.MapViewOfFile.restype=ctypes.c_void_p
        self.k.UnmapViewOfFile.argtypes=[ctypes.c_void_p];self.k.CloseHandle.argtypes=[wintypes.HANDLE]
        self.k.GetTickCount64.restype=ctypes.c_ulonglong
        self.handle=self.k.OpenFileMappingW(FILE_MAP_READ,False,'Local\\ResourceScanner.Frame.v1.'+str(pid));self.address=None
        if not self.handle:raise Unavailable('Current core frame publication is unavailable')
        self.address=self.k.MapViewOfFile(self.handle,FILE_MAP_READ,0,0,SIZE)
        if not self.address:self.close();raise Unavailable('Cannot read current frame publication')
    def read(self):
        if not self.address:raise Unavailable('Frame reader closed')
        first=ctypes.string_at(self.address,64);body=ctypes.string_at(self.address,SIZE);last=ctypes.string_at(self.address,64)
        if first!=last or first!=body[:64]:raise Unavailable('Frame changed during capture')
        return parse(body,self.pid,self.birth,self.k.GetTickCount64())
    def close(self):
        if self.address:self.k.UnmapViewOfFile(self.address);self.address=None
        if self.handle:self.k.CloseHandle(self.handle);self.handle=None
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
