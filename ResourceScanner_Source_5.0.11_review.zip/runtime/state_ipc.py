"""Version 1 shared helper-state protocol."""
import hashlib
import struct

MAGIC=b'RSSTATE1'
HEADER_BYTES=256
FOW_BYTES=204800
KNOWN_BYTES=88
TOTAL_BYTES=205152
ROW_COUNT=690
FOW_READY=1
KNOWLEDGE_READY=2

def catalog_digest(item_ids):
    if len(item_ids)!=ROW_COUNT or any(type(x)is not int or not 0<=x<=0xffffffff for x in item_ids):raise ValueError('Invalid catalog item IDs')
    return hashlib.sha256(struct.pack('<690I',*item_ids)).digest()

def encode(frame,session,now_ms,digest,*,generation=2,fow=None,known_rows=None,hero_store=0,hero_index=0,appearance=0,world_guid=bytes(16),hero_guid=bytes(16),capture_ms=None):
    if len(digest)!=32 or len(world_guid)!=16 or len(hero_guid)!=16:raise ValueError('Invalid source identity')
    if generation==0 or generation&1 or not 0<session<=0xffffffffffffffff:raise ValueError('Invalid state generation/session')
    if not 0<=hero_store<=1 or not 0<=hero_index<=16:raise ValueError('Invalid addressed-hero diagnostics')
    if type(appearance)is not int or appearance not in (0,1,2):raise ValueError('Invalid appearance selection')
    if not 0<frame.sampled_ms<=now_ms or now_ms-frame.sampled_ms>1000:raise ValueError('Stale source frame')
    if capture_ms is None:capture_ms=now_ms
    if not frame.sampled_ms<=capture_ms<=now_ms:raise ValueError('Invalid capture timestamp')
    ready=(FOW_READY if fow is not None else 0)|(KNOWLEDGE_READY if known_rows is not None else 0)
    if ready:frame.world_scope()
    if fow is not None and len(fow)!=FOW_BYTES:raise ValueError('Invalid explored-map bitset')
    bits=bytearray(KNOWN_BYTES)
    if known_rows is not None:
        for row in known_rows:
            if type(row)is not int or not 0<=row<ROW_COUNT:raise ValueError('Invalid known row')
            bits[row>>3]|=1<<(row&7)
    out=bytearray(TOTAL_BYTES)
    struct.pack_into('<8sIIIIQIIQQQQ',out,0,MAGIC,1,HEADER_BYTES,TOTAL_BYTES,ready,generation,frame.process_id,0,frame.birth,frame.nonce,now_ms,session)
    out[72:88]=world_guid;out[88:104]=hero_guid;out[104:136]=digest
    struct.pack_into('<4IQQ3Q2I',out,136,1280,1280,FOW_BYTES,KNOWN_BYTES,frame.sequence,capture_ms,frame.application,frame.ui,frame.map_state,hero_store,hero_index)
    struct.pack_into('<I',out,200,appearance)
    if fow is not None:out[HEADER_BYTES:HEADER_BYTES+FOW_BYTES]=fow
    out[HEADER_BYTES+FOW_BYTES:HEADER_BYTES+FOW_BYTES+KNOWN_BYTES]=bits
    return bytes(out)

def validate(data,frame,digest,now_ms,max_age_ms=1000):
    if not 0<frame.sampled_ms<=now_ms or now_ms-frame.sampled_ms>max_age_ms:raise ValueError('Stale source frame')
    if len(data)!=TOTAL_BYTES:raise ValueError('Invalid state size')
    magic,version,header,total,ready,generation,pid,reserved,birth,nonce,stamp,session=struct.unpack_from('<8sIIIIQIIQQQQ',data)
    if (magic,version,header,total)!=(MAGIC,1,HEADER_BYTES,TOTAL_BYTES)or ready&~3 or reserved or not session or not generation or generation&1:raise ValueError('Invalid state header')
    if (pid,birth,nonce)!=(frame.process_id,frame.birth,frame.nonce)or data[104:136]!=digest:raise ValueError('State owner/catalog changed')
    if now_ms<stamp or now_ms-stamp>max_age_ms:raise ValueError('Stale helper state')
    width,height,fb,kb,sequence,capture,app,ui,map_state,store,index=struct.unpack_from('<4IQQ3Q2I',data,136)
    appearance=struct.unpack_from('<I',data,200)[0]
    if (width,height,fb,kb)!=(1280,1280,FOW_BYTES,KNOWN_BYTES)or appearance not in (0,1,2)or data[204:256]!=bytes(52)or data[-8:]!=bytes(8):raise ValueError('Invalid state dimensions/reserved fields')
    if not capture<=stamp<=now_ms or now_ms-capture>max_age_ms or not frame.scope_start_sequence<=sequence<=frame.sequence or not 0<=store<=1 or not 0<=index<=16:raise ValueError('Invalid state source timing')
    if (app,ui,map_state)!=(frame.application,frame.ui,frame.map_state):raise ValueError('State source context changed')
    if ready:frame.world_scope()
    fow=data[HEADER_BYTES:HEADER_BYTES+FOW_BYTES];known=data[HEADER_BYTES+FOW_BYTES:HEADER_BYTES+FOW_BYTES+KNOWN_BYTES]
    if known[-1]or known[-2]&~3:raise ValueError('Out-of-catalog knowledge bits')
    if not ready&FOW_READY and any(fow):raise ValueError('Unavailable FOW has stale data')
    if not ready&KNOWLEDGE_READY and any(known):raise ValueError('Unavailable knowledge has stale data')
    return dict(fow_ready=bool(ready&FOW_READY),knowledge_ready=bool(ready&KNOWLEDGE_READY),session=session,fow=fow,known=known,hero_store=store,hero_index=index,appearance=appearance)
