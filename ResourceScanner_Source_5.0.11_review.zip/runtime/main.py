import sys
sys.dont_write_bytecode=True
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import argparse,ctypes,json,os,time
from frame_ipc import FrameMapping
from state_ipc import encode,catalog_digest
from publisher import StatePublisher
from capture import GameMemory,FogCapture,KnowledgeCapture,CaptureSession
from game_sources import steam_context,save_roots
from lifetime import StopSignal

STARTUP_DELAYS=(.1,.25,.5,1.0)
STORE_REFRESH_SECONDS=5.0

class StoreDiscovery:
    def __init__(self):
        self.account=None;self.roots=[];self.stores=[];self.next_refresh=0
    def get(self,game_dir,now,force=False):
        if not force and now<self.next_refresh:return self.stores
        self.next_refresh=now+STORE_REFRESH_SECONDS
        try:
            roots,account=steam_context()
            valid=type(account)is int and 0<account<=0xffffffff
            if self.account is None:
                if roots:self.roots=list(roots)
                if valid:self.account=account
            elif (not valid or account==self.account)and roots:self.roots=list(roots)
            self.stores=save_roots(game_dir,self.roots,self.account)
        except (OSError,ValueError,TypeError):pass
        return self.stores

def status(root,pid,last,phase,reason,fow=False,knowledge=False):
    key=(phase,reason,fow,knowledge)
    if key==last:return last
    report=dict(app='resource-scanner',status='ready'if fow or knowledge else'unavailable',phase=phase,reason_code=reason,fow_ready=fow,knowledge_ready=knowledge,parent_pid=pid)
    temp=root/('.helper-status-'+os.urandom(8).hex()+'.tmp')
    try:
        with temp.open('x',encoding='utf8')as stream:stream.write(json.dumps(report)+'\n');stream.flush();os.fsync(stream.fileno())
        os.replace(temp,root/'map.log');return key
    except OSError:return last
    finally:
        try:temp.unlink(missing_ok=True)
        except OSError:pass

def run(pid,birth,root,stop_event=None):
    if root.resolve()!=Path(__file__).resolve().parent.parent:raise ValueError('Unexpected helper root')
    catalog=json.loads((root/'catalog_items.json').read_text(encoding='utf8'));ids=catalog['row_item_ids'];digest=catalog_digest(ids)
    if digest.hex()!=catalog['item_id_digest']:raise ValueError('Catalog identity differs')
    k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetTickCount64.restype=ctypes.c_ulonglong
    game=mapping=publisher=stop=None;fog=FogCapture();knowledge=KnowledgeCapture(ids);scope=None;session=CaptureSession();last_log=None
    stores=StoreDiscovery();last_store_hero=None;startup_attempt=0;permanent_startup=False
    try:
        try:stop=StopSignal(stop_event,pid,birth)
        except (OSError,ValueError):
            status(root,pid,last_log,'startup','parent_lifetime_unavailable');return
        if stop.requested():return
        while not stop.requested():
            if game is None:
                if permanent_startup:
                    stop.wait(1.0);continue
                try:
                    game=GameMemory(pid,birth)
                    stores.get(game.path.parent,time.monotonic(),True)
                    startup_attempt=0
                except OSError:
                    last_log=status(root,pid,last_log,'startup','startup_retry')
                    delay=STARTUP_DELAYS[min(startup_attempt,len(STARTUP_DELAYS)-1)];startup_attempt+=1
                    stop.wait(delay);continue
                except ValueError:
                    permanent_startup=True
                    last_log=status(root,pid,last_log,'startup','source_layout_or_identity_unavailable')
                    continue
            if not game.running():
                game.close();game=None;fog.clear();knowledge.clear();scope=None;session.invalidate()
                if publisher:publisher.close();publisher=None
                last_log=status(root,pid,last_log,'startup','parent_handle_retry')
                stop.wait(.25);continue
            frame=None;bits=known=None;metadata={};hero=None;reason='unavailable';capture_ms=int(k.GetTickCount64())
            try:
                if mapping is None:mapping=FrameMapping(pid,birth)
                frame=mapping.read();stop.require_frame(frame);current=frame.world_scope()
                if current!=scope:
                    scope=current;fog.clear();knowledge.clear()
                    if publisher is not None:publisher.close();publisher=None
                if publisher is None:publisher=StatePublisher(pid,birth,frame.nonce)
                hero=game.bind(frame)
                if session.begin(current,hero):fog.clear();knowledge.clear()
                current_stores=stores.get(game.path.parent,time.monotonic(),hero!=last_store_hero);last_store_hero=hero
                capture_ms=int(k.GetTickCount64())
                try:bits,metadata=fog.update(game,hero,current_stores)
                except (OSError,ValueError):fog.clear()
                try:
                    result=knowledge.update(game,frame,mapping,hero)
                    if session.knowledge_context(result['context_token']):
                        bits=None;metadata={};fog.clear();knowledge.clear()
                    elif result['ready']:
                        selected=set(result['known_item_ids']);known=[i for i,item in enumerate(ids)if item and item in selected]
                except (OSError,ValueError):knowledge.clear()
                after=mapping.read();stop.require_frame(after)
                if after.world_scope()!=scope or game.hero()!=hero:raise ValueError('Source changed before publication')
                reason='ready'if bits is not None or known is not None else'unavailable'
            except (OSError,ValueError):
                bits=known=None;metadata={};fog.clear();knowledge.clear();scope=None;session.invalidate()
            if stop.requested():break
            now=int(k.GetTickCount64())
            if bits is None and known is None:capture_ms=now
            if frame is not None and publisher is not None:
                try:
                    appearance=game.appearance()if hero is not None else 0
                    data=encode(frame,max(1,session.number),now,digest,fow=bits,known_rows=known,hero_store=hero.backend if hero else 0,hero_index=hero.index+1 if hero else 0,appearance=appearance,hero_guid=bytes.fromhex(metadata['character_guid'])if bits is not None else bytes(16),capture_ms=capture_ms)
                    publisher.write(data)
                except (OSError,ValueError):bits=known=None;reason='unavailable'
            last_log=status(root,pid,last_log,'capture',reason,bits is not None,known is not None)
            stop.wait(.25)
    finally:
        if publisher:publisher.close()
        if mapping:mapping.close()
        if game:game.close()
        if stop:stop.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--parent-pid',required=True,type=int);parser.add_argument('--parent-birth',required=True,type=int);parser.add_argument('--root',required=True,type=Path);parser.add_argument('--stop-event');args=parser.parse_args();run(args.parent_pid,args.parent_birth,args.root,args.stop_event)
