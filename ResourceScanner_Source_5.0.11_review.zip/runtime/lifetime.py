import ctypes
import time
from ctypes import wintypes

class StopSignal:
    def __init__(self,name,pid,birth=None):
        self.handle=self.parent=None;self.stopped=False;self.nonce=None;self.k=None
        if type(pid)is not int or not 0<pid<=0xffffffff:raise ValueError('Invalid parent PID')
        if birth is not None and(type(birth)is not int or not 0<birth<=0xffffffffffffffff):raise ValueError('Invalid parent creation time')
        if name is not None:
            prefix='Local\\ResourceScanner.Stop.v1.'+str(pid)+'.'
            suffix=name[len(prefix):]if name.startswith(prefix)else''
            if not 1<=len(suffix)<=20 or not suffix.isascii()or not suffix.isdecimal()or not 0<int(suffix)<=0xffffffffffffffff:raise ValueError('Invalid helper stop-event identity')
            self.nonce=int(suffix)
        if name is None and birth is None:return
        self.k=ctypes.WinDLL('kernel32',use_last_error=True);k=self.k
        k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
        k.WaitForMultipleObjects.argtypes=[wintypes.DWORD,ctypes.POINTER(wintypes.HANDLE),wintypes.BOOL,wintypes.DWORD];k.WaitForMultipleObjects.restype=wintypes.DWORD
        k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
        try:
            if birth is not None:
                k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
                k.GetProcessTimes.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME)];k.GetProcessTimes.restype=wintypes.BOOL
                self.parent=k.OpenProcess(0x101000,False,pid)
                if not self.parent:raise OSError(ctypes.get_last_error(),'Parent lifetime unavailable')
                created,exited,kernel,user=(wintypes.FILETIME()for _ in range(4))
                if not k.GetProcessTimes(self.parent,ctypes.byref(created),ctypes.byref(exited),ctypes.byref(kernel),ctypes.byref(user)):raise OSError(ctypes.get_last_error(),'Parent creation time unavailable')
                if (created.dwLowDateTime|(created.dwHighDateTime<<32))!=birth:raise ValueError('Parent creation identity differs')
            if name is not None:
                k.OpenEventW.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.LPCWSTR];k.OpenEventW.restype=wintypes.HANDLE
                self.handle=k.OpenEventW(0x100000,False,name)
                if not self.handle:raise OSError(ctypes.get_last_error(),'Core shutdown event unavailable')
        except Exception:
            self.close();raise
    def require_frame(self,frame):
        if self.nonce is not None and frame.nonce!=self.nonce:raise ValueError('Stop event and core frame instance differ')
    def requested(self):
        if self.stopped:return True
        for handle in(self.parent,self.handle):
            if handle and self.k.WaitForSingleObject(handle,0)!=258:self.stopped=True;break
        return self.stopped
    def wait(self,timeout):
        if not 0<=timeout<=60:raise ValueError('Invalid stop wait')
        if self.requested():return True
        handles=[h for h in(self.parent,self.handle)if h]
        if handles:
            values=(wintypes.HANDLE*len(handles))(*handles)
            if self.k.WaitForMultipleObjects(len(handles),values,False,int(timeout*1000))!=258:self.stopped=True
        else:time.sleep(timeout)
        return self.requested()
    def close(self):
        self.stopped=True
        if self.handle:self.k.CloseHandle(self.handle);self.handle=None
        if self.parent:self.k.CloseHandle(self.parent);self.parent=None
