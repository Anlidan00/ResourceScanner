#pragma once
#include <array>
#include <cstdint>
namespace rs::ui::shell {
struct Labels { std::uint32_t language; const char *font, *title, *waiting, *unavailable; };
inline constexpr std::array<Labels, 15> labels{{
    {1, "western", "ResourceScanner", "Explored-map data is not available yet.", "Explored-area data is unavailable."},
    {3, "western", "Ressourcenscanner", "Daten zur erkundeten Karte sind noch nicht verfügbar.", "Daten zum erkundeten Gebiet sind nicht verfügbar."},
    {5, "western", "Scanner de ressources", "Les données de la carte explorée ne sont pas encore disponibles.", "Les données de la zone explorée sont indisponibles."},
    {6, "western", "Scanner di risorse", "I dati della mappa esplorata non sono ancora disponibili.", "I dati dell’area esplorata non sono disponibili."},
    {7, "western", "Escáner de recursos", "Los datos del mapa explorado aún no están disponibles.", "Los datos de la zona explorada no están disponibles."},
    {9, "western", "Сканер ресурсов", "Данные открытой области карты пока недоступны.", "Данные открытой зоны недоступны."},
    {10, "western", "Skaner zasobów", "Dane odkrytej mapy nie są jeszcze dostępne.", "Dane odkrytego obszaru są niedostępne."},
    {11, "cjk-jp", "資源スキャナー", "探索済みマップのデータはまだ取得できません。", "探索済みエリアのデータを取得できません。"},
    {13, "cjk-kr", "자원 스캐너", "탐험한 지도의 데이터를 아직 사용할 수 없습니다.", "탐험한 지역의 데이터를 사용할 수 없습니다."},
    {16, "western", "Scanner de recursos", "Os dados do mapa explorado ainda não estão disponíveis.", "Os dados da área explorada não estão disponíveis."},
    {17, "thai", "", "", ""},
    {18, "western", "Kaynak Tarayıcı", "Keşfedilen harita verileri henüz kullanılamıyor.", "Keşfedilen bölge verileri kullanılamıyor."},
    {20, "cjk-sc", "资源扫描器", "已探索地图数据暂不可用。", "已探索区域数据不可用。"},
    {21, "cjk-tc", "資源掃描器", "已探索地圖資料暫時無法使用。", "已探索區域資料無法使用。"},
    {34, "western", "Сканер ресурсів", "Дані дослідженої карти поки недоступні.", "Дані дослідженої області недоступні."},
}};
inline const Labels& get(std::uint32_t language) noexcept {
    for (const auto& item : labels) if (item.language == language) return item;
    return labels.front();
}
}
