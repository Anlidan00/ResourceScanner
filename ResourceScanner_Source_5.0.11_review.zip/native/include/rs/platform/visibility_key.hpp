#pragma once
#include <atomic>
#include <windows.h>

namespace rs::platform {
inline constexpr bool valid_visibility_key(unsigned key) noexcept {
    return key==8||key==9||key==13||key==19||key==20||(key>=32&&key<=40)||key==45||key==46||
        (key>=48&&key<=57)||(key>=65&&key<=90)||(key>=96&&key<=135)||key==144||key==145||
        (key>=186&&key<=192)||(key>=219&&key<=222)||key==226;
}
inline std::atomic_uint configured_visibility_key{VK_INSERT};
inline unsigned visibility_key() noexcept {
    return configured_visibility_key.load(std::memory_order_relaxed);
}
inline void set_visibility_key(unsigned key) noexcept {
    configured_visibility_key.store(valid_visibility_key(key)?key:VK_INSERT,std::memory_order_relaxed);
}
inline unsigned read_visibility_key(const wchar_t* settings) noexcept {
    const auto key=settings&&*settings?GetPrivateProfileIntW(L"Scanner",L"ToggleKey",VK_INSERT,settings):VK_INSERT;
    return valid_visibility_key(key)?key:VK_INSERT;
}
}
