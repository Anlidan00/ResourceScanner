#pragma once
#include <filesystem>
#include <string_view>
#include <cstdint>
namespace rs::platform {
std::filesystem::path module_directory() noexcept;
std::filesystem::path data_directory() noexcept;
std::uint64_t instance_nonce() noexcept;
// Fixed product log, best effort; no exceptions cross a game callback.
void log(std::string_view phase, std::string_view message) noexcept;
}
