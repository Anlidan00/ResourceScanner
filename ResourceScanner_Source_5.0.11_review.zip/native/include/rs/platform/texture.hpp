#pragma once
#include <cstddef>
#include <cstdint>

namespace rs::platform {
using TextureId = std::uint64_t;
// Invoke from RenderCallback only. A zero result leaves the caller free to retry
// after a device/swapchain has become available. Input bytes are copied. IDs are
// valid only for FrameContext.texture_generation; discard cached IDs on change.
TextureId create_texture_rgba(std::uint32_t width, std::uint32_t height,
                             const void* pixels, std::size_t bytes,
                             std::size_t row_pitch = 0) noexcept;
// Destruction is delayed until all submissions using the descriptor have retired.
void defer_destroy_texture(TextureId texture) noexcept;
}
