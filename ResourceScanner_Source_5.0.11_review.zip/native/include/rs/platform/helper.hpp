#pragma once

#include <cstdint>
#include <string>

namespace rs::platform {

struct HelperOptions {
    // All paths resolve beneath this module's directory. No CWD/PATH lookup.
    std::wstring relative_executable;
    std::wstring relative_script;
    std::uint32_t parent_process_id{};
    std::uint64_t parent_creation_time{};
    std::wstring stop_event;
};

class HelperProcess final {
public:
    HelperProcess() noexcept = default;
    ~HelperProcess();
    HelperProcess(const HelperProcess&) = delete;
    HelperProcess& operator=(const HelperProcess&) = delete;
    bool start(const std::wstring& module_directory, const HelperOptions& options) noexcept;
    // Cooperative helper stop is requested by its parent identity/liveness.
    // This class never terminates an unrelated process or starts a console.
    void close_handles() noexcept;
    [[nodiscard]] std::uint32_t process_id() const noexcept;
    bool wait_exit(std::uint32_t timeout_ms) const noexcept;
private:
    void* process_{};
    void* thread_{};
    std::uint32_t process_id_{};
};

} // namespace rs::platform
