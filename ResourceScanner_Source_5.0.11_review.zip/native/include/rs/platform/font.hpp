#pragma once
#include <filesystem>
#include <string_view>
struct ImFont;struct ImFontAtlas;
namespace rs::platform {
// Roles: western,cjk-jp,cjk-kr,cjk-sc,cjk-tc,thai. Regional Han destinations
// are separate even when some codepoints overlap. Call after backend init.
ImFont* font(std::string_view role) noexcept;
bool font_available(std::string_view role) noexcept;
// Load manifest-admitted fonts and an optional installed Western base.
bool initialize_fonts(ImFontAtlas*,const std::filesystem::path& fonts_directory) noexcept;
void forget_fonts() noexcept;
}
