#pragma once

#include <cstdint>
#include <rs/game/frame.hpp>

struct ImGuiContext;

namespace rs::platform {

struct FrameContext {
    ImGuiContext* imgui{};
    void* native_window{};
    std::uint32_t framebuffer_width{};
    std::uint32_t framebuffer_height{};
    float delta_seconds{};
    float dpi_scale{1.0F};
    std::uint64_t texture_generation{};
    game::Frame game{};
};

using RenderCallback = void (*)(void* user, const FrameContext& frame) noexcept;

struct RenderClient {
    std::uint32_t structure_bytes{sizeof(RenderClient)};
    std::uint32_t version{1};
    void* user{};
    RenderCallback render{};
    void* sampler_user{};
    game::FrameSampler sample_game{};
};

// Registered before startup, or atomically between frames. A callback runs only
// after a valid ImGui NewFrame and before Render; exceptions must not escape it.
bool set_render_client(const RenderClient& client) noexcept;
bool start() noexcept;
void request_stop() noexcept;
bool stop(std::uint32_t timeout_ms) noexcept;

} // namespace rs::platform
