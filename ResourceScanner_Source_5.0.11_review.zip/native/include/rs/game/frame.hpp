#pragma once

#include <array>
#include <cstdint>

namespace rs::game {

struct Vec2 { float x{}, y{}; };
struct Rect { float left{}, top{}, right{}, bottom{}; };

struct Projection {
    Vec2 world_center{};
    Vec2 screen_center{};
    float pixels_per_world_unit{};
    Rect screen_bounds{};
};

enum class Availability : std::uint32_t {
    unavailable, compatible, unsupported_source, changing_context
};

// Value snapshot only: consumers never dereference the diagnostic addresses.
// Geometry is in client-area pixels. World coordinates keep the catalog units.
struct Frame {
    std::uint64_t sequence{};
    std::uint64_t scope_start_sequence{};
    std::uint64_t sampled_at_ms{};
    std::uint64_t process_creation_time{};
    std::uint32_t process_id{};
    std::uint32_t native_language_id{1};
    Availability source{Availability::unavailable};
    bool map_open{};
    bool projection_ready{};
    bool hud_bounds_ready{};
    bool world_ready{};
    Projection projection{};
    Rect map_content{};
    std::uintptr_t application_address{};
    std::uintptr_t ui_address{};
    std::uintptr_t map_state_address{};
    std::array<std::uint8_t, 16> world_guid{};
    std::array<std::uint8_t, 16> hero_guid{};
    // Native control geometry only. This tail is NOT serialized into Frame or
    // State shared-memory protocols, and optional failure never closes the map.
    std::array<Rect,32> ui_blockers{};
    std::uint32_t ui_blocker_count{};
    bool ui_blockers_ready{};
    // Native-only lifetime token copied into a rendered tracking hit. An old
    // render may never acquire a new map lifetime merely by reusing addresses.
    std::uint64_t tracking_generation{};
    // Optional native sidebar anchors; never part of either IPC wire format.
    Rect sidebar_upper{}, sidebar_lower{};
    bool sidebar_bounds_ready{};
};

// Source adapters receive bounded read-only memory access, also injectable in
// unit tests. Engine functions are not invoked by a sampling implementation.
struct MemoryReader {
    void* user{};
    bool (*copy)(void* user, std::uintptr_t source, void* destination,
                 std::uint64_t bytes) noexcept{};
};

using FrameSampler = Frame (*)(void* user, std::uint64_t now_ms) noexcept;

} // namespace rs::game
