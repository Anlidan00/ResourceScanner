#pragma once
#include <rs/game/frame.hpp>

namespace rs::game {
enum class TrackingShape : std::uint8_t { circle, rounded_rectangle };
struct TrackingHitArea {
    Rect bounds{}; // client-area pixels, same space as Frame.projection
    float rounding{};
    TrackingShape shape{TrackingShape::circle};
};
struct TrackingHit {
    Frame scope{};
    std::uintptr_t native_window{};
    std::uint64_t source_point_id{};
    float x{},y{},z{}; // catalog WORLD metres, including primary-source Y
    std::uint8_t source_flags{}; // bit0 MUST attest a primary-joined Y; Y=0 alone does not
    std::array<TrackingHitArea,2> areas{}; // main marker and optional method badge
    std::uint8_t area_count{};
};
// Publish the current eligible hovered marker on every visible UI frame.
// No engine API is called here. The native RMB edge owns request submission.
bool publish_tracking_hit(const TrackingHit&) noexcept;
// Call on frames with no eligible marker, hidden UI, menus or unavailable data.
// Clearing hover never forwards a release from an already-owned RMB gesture.
void clear_tracking_hit() noexcept;
} // namespace rs::game
