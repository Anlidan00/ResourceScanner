#pragma once
#include <cstddef>
#include <cstdint>

namespace rs::game::ipc {
inline constexpr char mapping_prefix[] = "Local\\ResourceScanner.Frame.v1.";
inline constexpr char magic[8] = {'R','S','F','R','A','M','E','1'};
inline constexpr std::uint32_t version = 1;
enum Flag : std::uint32_t { map_open=1, projection_ready=2, hud_bounds_ready=4, world_ready=8 };
#pragma pack(push, 1)
struct Header {
    char magic[8];
    std::uint32_t version, header_bytes, payload_bytes, total_bytes;
    std::uint64_t generation; // odd while writing; reader accepts identical even copies
    std::uint32_t process_id, reserved0;
    std::uint64_t process_creation_time, instance_nonce, reserved1;
};
struct Payload {
    std::uint64_t sequence, sampled_at_ms;
    std::uint32_t process_id, availability;
    std::uint64_t process_creation_time;
    std::uint32_t native_language_id, flags;
    float world_center_x, world_center_z; // world metres, not packed game integers
    float screen_center_x, screen_center_y, pixels_per_world_unit;
    std::uint32_t reserved0;
    float screen_left, screen_top, screen_right, screen_bottom;
    float content_left, content_top, content_right, content_bottom;
    std::uint64_t application_address, ui_address, map_state_address;
    std::uint8_t world_guid[16], hero_guid[16];
    std::uint64_t scope_start_sequence;
    std::uint8_t reserved1[32];
};
struct Snapshot { Header header; Payload payload; };
#pragma pack(pop)
static_assert(sizeof(Header)==64 && sizeof(Payload)==192 && sizeof(Snapshot)==256);
static_assert(offsetof(Header,generation)==24 && offsetof(Payload,application_address)==96);
// Payload availability: 0 unavailable, 1 compatible, 2 unsupported, 3 changing.
// This is diagnostic/context publication only. It conveys no FOW/knowledge truth.
}
