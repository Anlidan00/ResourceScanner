#pragma once
#include <rs/game/frame.hpp>
#include <array>
#include <span>
namespace rs::game {
struct StateSnapshot {
    bool fow_ready{},knowledge_ready{};
    std::uint64_t published_at_ms{},captured_at_ms{},session{},source_frame_sequence{};
    std::uint32_t appearance{}; // 0 unknown, 1 normal, 2 alternate
    std::array<std::uint8_t,16> world_guid{},hero_guid{};
    std::array<std::uint8_t,204800> fow{};
    std::array<std::uint8_t,88> known_rows{};
    bool known(std::uint32_t row)const noexcept {return knowledge_ready&&row<690&&(known_rows[row/8]&(1u<<(row%8)))!=0;}
};
// Input is the SHA256 of 690 little-endian u32 catalog item IDs (None => 0).
bool read_state(const Frame&,const std::array<std::uint8_t,32>& expected_catalog,
                std::uint64_t now_ms,StateSnapshot&) noexcept;
// Bounded shared-state validator.
bool decode_state(std::span<const std::uint8_t>,const Frame&,std::uint64_t expected_nonce,
                  const std::array<std::uint8_t,32>& expected_catalog,
                  std::uint64_t now_ms,StateSnapshot&) noexcept;
}
