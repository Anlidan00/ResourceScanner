#pragma once
#include <cstdint>

namespace rs::game {
// Defaults describe the saved offline capture. Live integration always supplies
// operands decoded from the current executable, independently of MapState size.
struct NativeLayout {
    std::uint32_t world_page{0x31E70};
    std::uint32_t language_owner{0x35290};
    std::uint32_t ui_language{0xF5C};
    std::uint32_t language_id{0xD8};
    std::uint64_t map_literal{0x6A533A7BC1DBE699ULL};
    bool operator==(const NativeLayout&) const=default;
};
}
