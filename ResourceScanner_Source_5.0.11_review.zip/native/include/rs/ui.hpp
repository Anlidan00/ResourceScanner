#pragma once
#include <rs/platform/render.hpp>
namespace rs::ui {
void render(void* user, const platform::FrameContext& frame) noexcept;
bool finish_loading(unsigned timeout_ms) noexcept;
}
