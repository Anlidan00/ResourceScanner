#pragma once
#include <array>
#include <cstdint>
#include <string_view>

namespace rs::ui::options {
// UI notice key: ui.absent_global. Item and creature names remain game data.
struct Notice { std::uint32_t language;const char* absent_global; };
inline constexpr std::array<Notice,15> notices{{
    {1,"No sources found on the map."},
    {3,"Keine Quellen auf der Karte gefunden."},
    {5,"Aucune source trouvée sur la carte."},
    {6,"Nessuna fonte trovata sulla mappa."},
    {7,"No se encontraron fuentes en el mapa."},
    {9,"Источники на карте не найдены."},
    {10,"Nie znaleziono źródła na mapie."},
    {11,"見つかりません。"},
    {13,"발견되지 않았습니다."},
    {16,"Nenhuma fonte encontrada no mapa."},
    // Existing Thai composite glyphs for logical "ไม่พบ". No new font data.
    {17,"\uE0E3\uE077\uE0A1\uE000"},
    {18,"Haritada kaynak bulunamadı."},
    {20,"未发现。"},
    {21,"未發現。"},
    {34,"Джерела на карті не знайдені."}
}};
inline const char* label(std::uint32_t language,std::string_view key) noexcept {
    if(key!="ui.absent_global")return "";
    for(const auto& notice:notices)if(notice.language==language)return notice.absent_global;
    return notices.front().absent_global;
}
}
