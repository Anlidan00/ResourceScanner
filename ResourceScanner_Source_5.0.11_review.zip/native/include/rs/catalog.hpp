#pragma once
#include <array>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace rs::catalog {
using Text = std::uint32_t;
struct Point {
    std::uint32_t resource{}, source{};
    float x{}, y{}, z{}, blocks{};
    std::uint8_t tier{}, flags{};
};
struct Resource {
    std::string id;
    std::uint32_t item{}, category{}, icon{}, source_begin{}, source_count{}, point_begin{}, point_count{};
    bool inventory{}, craftable{}, chest{};
};
struct PortraitState { std::uint32_t icon{}, condition{}; };
struct Source {
    std::uint32_t resource{}, method{}, source_class{}, tier{};
    float blocks{};
    std::vector<PortraitState> portraits;
};
struct Icon { std::uint32_t width{}, height{}; std::uint64_t offset{}, bytes{}; };
struct SourceText { Text action{}, reason{}, detail{}; };
struct Ingredient {
    std::uint32_t icon{0xFFFFFFFFU}, item{}, amount{}, group{};
    Text text{};
    std::string style, role;
};
struct Recipe { std::uint32_t id{}; std::vector<Ingredient> ingredients; };
struct Place { Text heading{}; std::vector<Recipe> recipes; };
struct RecipeLayer { std::uint32_t resource{}; std::vector<Place> places; };
struct TextKeyHash {
    using is_transparent = void;
    std::size_t operator()(std::string_view key) const noexcept { return std::hash<std::string_view>{}(key); }
};
struct Locale {
    std::string tag, font_role;
    std::uint32_t native_id{};
    std::vector<Text> names, display_names, titles, notes;
    std::vector<SourceText> sources;
    std::vector<std::uint32_t> ranks;
    std::unordered_map<std::string, Text, TextKeyHash, std::equal_to<>> labels;
    std::vector<RecipeLayer> recipes;
};
class Catalog {
public:
    std::vector<Resource> resources;
    std::vector<Source> sources;
    std::vector<Point> points;
    std::vector<Icon> icons;
    std::vector<Locale> locales;
    std::vector<std::string> texts;
    std::vector<std::uint8_t> pixels;
    std::uint32_t categories{};
    std::array<std::uint8_t, 32> item_digest{};
    const std::string& text(Text index) const noexcept;
    const std::string& label(const Locale&, const char* key) const noexcept;
    const Locale& locale(std::uint32_t native_id) const noexcept;
};
struct LoadResult { std::shared_ptr<const Catalog> value; std::string error; };
LoadResult load(const std::filesystem::path&) noexcept;
bool revealed(float world_x, float world_z, const std::uint8_t* bits,
              std::size_t bytes) noexcept;
} // namespace rs::catalog
