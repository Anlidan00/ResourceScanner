#include <rs/ui.hpp>
#include <rs/ui_shell.hpp>
#include <rs/ui_options.hpp>
#include <rs/method_icons.hpp>
#include <rs/catalog.hpp>
#include <rs/game/state.hpp>
#include <rs/game/tracking.hpp>
#include <rs/platform/font.hpp>
#include <rs/platform/paths.hpp>
#include <rs/platform/visibility_key.hpp>
#include <rs/platform/texture.hpp>
#include <imgui.h>
#include <imgui_internal.h>
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <future>
#include <limits>
#include <memory>
#include <numeric>
#include <string>
#include <unordered_set>
#include <vector>

namespace rs::ui {
namespace {
constexpr ImU32 gold=IM_COL32(211,188,128,255), ink=IM_COL32(20,20,20,240);
constexpr ImU32 light=IM_COL32(233,226,207,255), muted=IM_COL32(165,159,146,255);
constexpr ImU32 orange=IM_COL32(242,166,90,255), red=IM_COL32(224,91,91,255);
constexpr ImU32 route_gold=IM_COL32(229,193,90,255);
constexpr float ui_font_size=21.0F,recipe_font_size=17.5F;
constexpr std::array<ImU32,3> tiers{IM_COL32(96,198,126,255),IM_COL32(91,173,239,255),IM_COL32(177,130,226,255)};
struct Marker { std::uint32_t point{};ImVec2 xy; };
struct State {
    std::future<catalog::LoadResult> loading;
    std::shared_ptr<const catalog::Catalog> data;
    bool started{},failed{},enabled{true},known_only{true},explored_only{true},all_points_ready{},toggle_down{};
    unsigned font_language{};
    std::vector<platform::TextureId> textures;
    std::array<platform::TextureId,14> method_textures{};
    std::vector<std::uint8_t> selected;
    std::array<bool,8> filters{true,true,true,true,true,true,true,true};
    std::array<char,512> query{};
    std::vector<std::wstring> names_folded;
    std::vector<std::uint32_t> methods,explored;
    std::vector<Marker> markers;
    std::uint64_t explored_stamp{},explored_session{};
    std::uint64_t texture_generation{};
    game::StateSnapshot snapshot;
    game::StateSnapshot pending_snapshot;
    game::Frame accepted_frame;
    std::uint64_t accepted_nonce{};
    std::uint64_t portrait_scope{};
    std::uint32_t portrait_point{0xFFFFFFFFU},portrait_appearance{};
    int portrait_frame{-2};
    double portrait_started{};
    bool snapshot_valid{};
    std::filesystem::path ini;
};
// Explicit process lifetime; loading is joined by finish_loading before unloading
// the core. Avoid a future destructor waiting under the Windows loader lock.
State& state() { static State* value=new State;return *value; }
float clamp(float value,float low,float high) { return std::max(low,std::min(value,high)); }
std::wstring fold(const std::string& value) {
    if(value.empty()) return {};
    const int n=MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,value.data(),static_cast<int>(value.size()),nullptr,0);
    if(n<=0)return {};
    std::wstring wide(static_cast<std::size_t>(n),L'\0');
    MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,value.data(),static_cast<int>(value.size()),wide.data(),n);
    const int out=LCMapStringEx(LOCALE_NAME_INVARIANT,LCMAP_LOWERCASE,wide.data(),n,nullptr,0,nullptr,nullptr,0);
    if(out<=0)return wide;
    std::wstring result(static_cast<std::size_t>(out),L'\0');
    LCMapStringEx(LOCALE_NAME_INVARIANT,LCMAP_LOWERCASE,wide.data(),n,result.data(),out,nullptr,nullptr,0);
    for(auto& c:result)if(c==L'\u0451')c=L'\u0435';
    return result;
}
void save_selection(State& s) {
    if(s.ini.empty()||!s.ini.is_absolute())return;
    std::wstring joined;
    for(std::size_t i=0;i<s.selected.size();++i)if(s.selected[i]) {
        if(!joined.empty())joined+=L'|';
        const auto& id=s.data->resources[i].id;
        joined.append(id.begin(),id.end());
    }
    WritePrivateProfileStringW(L"Scanner",L"Layers",joined.c_str(),s.ini.c_str());
}
void initialize(State& s) {
    const auto directory=platform::data_directory();
    if(directory.empty()||!directory.is_absolute()) {s.failed=true;s.started=true;platform::log("paths","Module data directory is unavailable");return;}
    s.ini=directory/L"settings.ini";
    platform::set_visibility_key(platform::read_visibility_key(s.ini.c_str()));
    s.enabled=GetPrivateProfileIntW(L"Scanner",L"Enabled",1,s.ini.c_str())!=0;
    s.known_only=GetPrivateProfileIntW(L"Scanner",L"KnownItemsOnly",1,s.ini.c_str())!=0;
    s.explored_only=GetPrivateProfileIntW(L"Scanner",L"ExploredOnly",1,s.ini.c_str())!=0;
    const auto path=directory/L"resource_scanner.rscn.zst";
    s.loading=std::async(std::launch::async,[path]{return catalog::load(path);});s.started=true;
}
void receive_catalog(State& s) {
    if(s.data||s.failed||!s.loading.valid()||s.loading.wait_for(std::chrono::seconds(0))!=std::future_status::ready)return;
    auto result=s.loading.get();
    if(!result.value){s.failed=true;platform::log("catalog",result.error);return;}
    s.failed=true;
    const auto loaded=std::move(result.value);
    // Admit the catalog only after every dependent row table is ready.
    // A failed allocation must not expose partially initialized row state.
    std::vector<platform::TextureId> textures(loaded->icons.size());
    std::vector<std::uint8_t> selected(loaded->resources.size());
    std::vector<std::uint32_t> methods(selected.size());
    std::array<wchar_t,32768> value{};GetPrivateProfileStringW(L"Scanner",L"Layers",L"",value.data(),static_cast<DWORD>(value.size()),s.ini.c_str());
    const std::wstring settings=value.data();std::unordered_set<std::wstring> tokens;
    for(std::size_t at=0;at<settings.size();) {const auto end=settings.find(L'|',at);tokens.insert(settings.substr(at,end==std::wstring::npos?end:end-at));if(end==std::wstring::npos)break;at=end+1;}
    for(std::size_t i=0;i<selected.size();++i) {
        const auto& id=loaded->resources[i].id;const std::wstring wid(id.begin(),id.end());
        selected[i]=tokens.count(wid)!=0;
    }
    s.textures=std::move(textures);s.selected=std::move(selected);s.methods=std::move(methods);s.data=loaded;s.failed=false;
}
ImTextureID texture(State& s,std::uint32_t index) {
    if(index>=s.textures.size())return ImTextureID{};
    auto& id=s.textures[index];
    if(!id){const auto& i=s.data->icons[index];id=platform::create_texture_rgba(i.width,i.height,s.data->pixels.data()+i.offset,static_cast<std::size_t>(i.bytes));}
    return static_cast<ImTextureID>(id);
}
void method(ImDrawList* draw,State& s,unsigned kind,ImVec2 origin,float size,ImU32 color=IM_COL32_WHITE) {
    if(kind>=s.method_textures.size())return;
    auto& id=s.method_textures[kind];
    if(!id) {
        std::array<std::uint8_t,art::edge*art::edge*4> rgba{};
        for(std::size_t i=0;i<art::method_alpha[kind].size();++i) {
            rgba[i*4]=rgba[i*4+1]=rgba[i*4+2]=255;
            rgba[i*4+3]=art::method_alpha[kind][i];
        }
        id=platform::create_texture_rgba(art::edge,art::edge,rgba.data(),rgba.size());
    }
    if(id)draw->AddImage(static_cast<ImTextureID>(id),origin,ImVec2(origin.x+size,origin.y+size),ImVec2(0,0),ImVec2(1,1),color);
}
bool icon_button(State& s,unsigned kind,ImU32 color,float size,const char* id) {
    const auto at=ImGui::GetCursorScreenPos();ImGui::InvisibleButton(id,ImVec2(size,size));method(ImGui::GetWindowDrawList(),s,kind,at,size,color);return ImGui::IsItemHovered();
}
const char* method_key(unsigned kind) {
    static constexpr const char* keys[]{"method_info.15","method_info.0","method_info.1","method_info.6","method_info.8","method_info.9","method_info.10","method_info.11","method_info.13","method_info.14","method_info.17","method_info.18"};
    return kind<12?keys[kind]:"ui.absent";
}
struct TipScope {
    bool open{};
    TipScope(ImVec2 wanted,float scale=1,bool transparent=false) {
        const auto& io=ImGui::GetIO();wanted.x=std::min(wanted.x,io.DisplaySize.x-24);wanted.y=std::min(wanted.y,io.DisplaySize.y-24);
        const auto mouse=io.MousePos;ImVec2 at(mouse.x+18,mouse.y-wanted.y-18);
        at.x=clamp(at.x,12,std::max(12.0F,io.DisplaySize.x-wanted.x-12));at.y=clamp(at.y,12,std::max(12.0F,io.DisplaySize.y-wanted.y-12));
        ImGui::SetNextWindowPos(at);ImGui::SetNextWindowSize(wanted);
        ImGui::PushStyleColor(ImGuiCol_WindowBg,transparent?0:ink);
        ImGui::PushStyleColor(ImGuiCol_PopupBg,transparent?0:ink);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,5.0F);
        ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding,5.0F);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize,0.0F);
        ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize,0.0F);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,transparent?ImVec2(0,0):ImVec2(10*scale,8*scale));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(0,0));
        // A real tooltip is rendered above normal windows and their child lists.
        // It never takes focus from the search field or the game map.
        open=ImGui::Begin("##resource_tip",nullptr,ImGuiWindowFlags_Tooltip|ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoInputs|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse|ImGuiWindowFlags_NoFocusOnAppearing);
        ImGui::SetWindowFontScale(scale);
    }
    ~TipScope(){ImGui::End();ImGui::PopStyleVar(6);ImGui::PopStyleColor(2);}
};
void simple_tip(const std::string& text) {
    if(text.empty())return;const auto size=ImGui::CalcTextSize(text.c_str());TipScope tip(ImVec2(size.x+20,size.y+16));if(tip.open)ImGui::TextUnformatted(text.c_str());
}
struct RecipeRowBox { const catalog::Ingredient* ingredient{};ImRect box; };
struct RecipeCardBox { ImRect box;std::vector<RecipeRowBox> rows; };
struct RecipePlaceBox { catalog::Text heading{};ImRect box;ImVec2 heading_pos;std::vector<RecipeCardBox> cards; };
struct RecipeLayout { ImVec2 size;float font{},line_gap{},icon{};std::vector<RecipePlaceBox> places; };
// The same rectangles measure and paint the complete recipe list. No independent
// Dummy/ItemSpacing cursor arithmetic can make a later station overlap a card.
RecipeLayout recipe_layout(const catalog::Catalog& data,const catalog::RecipeLayer& layer,float font) {
    RecipeLayout result;result.font=font;result.icon=font;result.line_gap=6;
    constexpr float outer=6,place_padding=4,card_padding=6,card_vertical_padding=2,card_gap=2,icon_gap=5;
    float text_width=0;
    for(const auto& place:layer.places) {
        text_width=std::max(text_width,ImGui::CalcTextSize(data.text(place.heading).c_str()).x);
        for(const auto& card:place.recipes)for(const auto& in:card.ingredients)
            text_width=std::max(text_width,(in.role=="alternative-caption"?0:font+icon_gap)+ImGui::CalcTextSize(data.text(in.text).c_str()).x+2*card_padding);
    }
    result.size.x=text_width+2*(outer+place_padding);
    float y=outer;
    for(const auto& place:layer.places) {
        RecipePlaceBox group;group.heading=place.heading;group.box.Min={outer,y};
        group.heading_pos={outer+place_padding,y+place_padding};
        y+=place_padding+font+4;
        for(const auto& recipe:place.recipes) {
            RecipeCardBox card;card.box.Min={outer+place_padding,y};y+=card_vertical_padding;
            for(const auto& in:recipe.ingredients) {
                card.rows.push_back({&in,ImRect(ImVec2(card.box.Min.x+card_padding,y),ImVec2(result.size.x-outer-place_padding-card_padding,y+font))});
                y+=font+result.line_gap;
            }
            if(!card.rows.empty())y-=result.line_gap;
            y+=card_vertical_padding;card.box.Max={result.size.x-outer-place_padding,y};
            group.cards.push_back(std::move(card));y+=card_gap;
        }
        if(!group.cards.empty())y-=card_gap;
        y+=place_padding;group.box.Max={result.size.x-outer,y};
        result.places.push_back(std::move(group));y+=4;
    }
    if(!result.places.empty())y-=4;
    result.size.y=y+outer;return result;
}
ImVec2 offset_point(ImVec2 origin,ImVec2 point,float scale) {return {origin.x+point.x*scale,origin.y+point.y*scale};}
ImRect offset_box(ImVec2 origin,const ImRect& box,float scale) {return {offset_point(origin,box.Min,scale),offset_point(origin,box.Max,scale)};}
struct FontSizeScope {
    explicit FontSizeScope(float size){ImGui::PushFont(ImGui::GetFont(),size);}
    ~FontSizeScope(){ImGui::PopFont();}
};
void recipe_tip(State& s,const catalog::Locale& locale,unsigned row) {
    FontSizeScope recipe_font(recipe_font_size);
    const catalog::RecipeLayer* layer{};for(const auto& x:locale.recipes)if(x.resource==row){layer=&x;break;}
    if(!layer){simple_tip(s.data->label(locale,"ui.craft"));return;}
    const auto layout=recipe_layout(*s.data,*layer,ImGui::GetFontSize());
    const auto& io=ImGui::GetIO();const float scale=std::min({1.0F,(io.DisplaySize.y-40)/layout.size.y,(io.DisplaySize.x-40)/layout.size.x});
    TipScope tip(ImVec2(layout.size.x*scale,layout.size.y*scale),scale,true);if(!tip.open)return;
    auto* draw=ImGui::GetWindowDrawList();const auto origin=ImGui::GetWindowPos();
    draw->AddRectFilled(origin,offset_point(origin,layout.size,scale),ink,5*scale);
    for(const auto& place:layout.places) {
        const auto group=offset_box(origin,place.box,scale);
        draw->AddRectFilled(group.Min,group.Max,IM_COL32(40,40,36,255),4*scale);
        draw->AddText(offset_point(origin,place.heading_pos,scale),IM_COL32(223,199,139,255),s.data->text(place.heading).c_str());
        for(const auto& card:place.cards) {
            const auto box=offset_box(origin,card.box,scale);
            draw->AddRectFilled(box.Min,box.Max,IM_COL32(57,53,43,255),3*scale);
            for(std::size_t ri=0;ri<card.rows.size();++ri) {
                const auto& entry=card.rows[ri];const auto& in=*entry.ingredient;
                if(in.role=="alternative-caption") {
                    std::size_t end=ri+1;
                    while(end<card.rows.size()&&card.rows[end].ingredient->group==in.group&&card.rows[end].ingredient->role!="alternative-caption")++end;
                    ImRect alternatives=entry.box;alternatives.Min.x-=2;alternatives.Min.y-=1;
                    alternatives.Max.y=card.rows[end-1].box.Max.y+1;alternatives.Max.x+=2;
                    const auto area=offset_box(origin,alternatives,scale);
                    draw->AddRectFilled(area.Min,area.Max,IM_COL32(68,62,49,255),3*scale);
                }
                const auto pos=offset_point(origin,entry.box.Min,scale);
                if(in.icon!=0xFFFFFFFFU)if(const auto tex=texture(s,in.icon))draw->AddImage(tex,pos,ImVec2(pos.x+layout.icon*scale,pos.y+layout.icon*scale));
                draw->AddText(ImVec2(pos.x+(in.role=="alternative-caption"?0:layout.icon+5)*scale,pos.y),in.style=="muted"?IM_COL32(198,187,156,255):light,s.data->text(in.text).c_str());
            }
        }
    }
}
struct PointTipLayout { ImVec2 size;ImRect portrait,text;float line{},portrait_side{}; };
PointTipLayout point_tip_layout(float text_width,float font,unsigned lines,bool portrait) {
    PointTipLayout result;result.line=font+3;result.portrait_side=portrait?3*result.line-3+16:0;
    const float text_height=std::max(1u,lines)*result.line-3+16;
    result.size={text_width+20+(portrait?result.portrait_side+8:0),std::max(result.portrait_side,text_height)};
    result.portrait={ImVec2(0,(result.size.y-result.portrait_side)/2),ImVec2(result.portrait_side,(result.size.y+result.portrait_side)/2)};
    const float text_left=portrait?result.portrait_side+8:0;
    result.text={ImVec2(text_left,(result.size.y-text_height)/2),ImVec2(result.size.x,(result.size.y+text_height)/2)};
    return result;
}
void point_tip(State& s,const catalog::Locale& locale,const Marker& marker) {
    const auto& p=s.data->points[marker.point];const auto& source=s.data->sources[p.source];const auto& text=locale.sources[p.source];
    const auto& title=s.data->text(locale.titles[p.resource]);const auto& action=s.data->text(text.action);const auto& reason=s.data->text(text.reason);
    std::string first=title.empty()?action:action.empty()?title:title+" — "+action;
    const char* key=p.tier==2?"ui.tier.vein":p.tier==1?"ui.tier.guaranteed":"ui.tier.possible";
    std::string second=s.data->label(locale,key)+(reason.empty()?"":" — "+reason);
    std::string third=p.tier==2?s.data->text(text.detail):std::string{};
    if(!third.empty()) {
        auto pattern=s.data->label(locale,"ui.vein_size");const auto token=pattern.find("%.*s");
        if(token!=std::string::npos){pattern.replace(token,4,third);third=std::move(pattern);}
    }
    unsigned portrait=0xFFFFFFFFU;std::vector<unsigned> active;
    for(const auto& state:source.portraits)if(state.condition==0||state.condition==s.snapshot.appearance)active.push_back(state.icon);
    if(s.portrait_point!=marker.point||s.portrait_scope!=s.accepted_frame.scope_start_sequence||s.portrait_appearance!=s.snapshot.appearance||s.portrait_frame+1<ImGui::GetFrameCount()){
        s.portrait_point=marker.point;s.portrait_scope=s.accepted_frame.scope_start_sequence;s.portrait_appearance=s.snapshot.appearance;s.portrait_started=ImGui::GetTime();
    }
    s.portrait_frame=ImGui::GetFrameCount();
    if(!active.empty())portrait=active[static_cast<std::size_t>((ImGui::GetTime()-s.portrait_started)/2)%active.size()];
    float width=std::max(ImGui::CalcTextSize(first.c_str()).x,ImGui::CalcTextSize(second.c_str()).x);width=std::max(width,ImGui::CalcTextSize(third.c_str()).x);
    const auto layout=point_tip_layout(width,ImGui::GetFontSize(),third.empty()?2:3,portrait!=0xFFFFFFFFU);
    const auto& io=ImGui::GetIO();const float scale=std::min({1.0F,(io.DisplaySize.x-40)/layout.size.x,(io.DisplaySize.y-40)/layout.size.y});
    TipScope tip(ImVec2(layout.size.x*scale,layout.size.y*scale),scale,true);if(!tip.open)return;
    auto* draw=ImGui::GetWindowDrawList();const auto origin=ImGui::GetWindowPos();
    const auto text_box=offset_box(origin,layout.text,scale);
    draw->AddRectFilled(text_box.Min,text_box.Max,ink,5*scale);
    if(portrait!=0xFFFFFFFFU) {
        const auto box=offset_box(origin,layout.portrait,scale);const float side=layout.portrait_side*scale;
        draw->AddRectFilled(box.Min,box.Max,ink,5*scale);
        for(int ring=16;ring>0;--ring){const float t=ring/16.0F;draw->AddCircleFilled(ImVec2(box.Min.x+side/2,box.Min.y+side/2),side*.48F*t,IM_COL32(98,102,109,ring==16?0:3),32);}
        const auto tex=texture(s,portrait);if(tex)draw->AddImageRounded(tex,box.Min,box.Max,ImVec2(0,0),ImVec2(1,1),IM_COL32_WHITE,5*scale);
    }
    const ImVec2 text_pos(text_box.Min.x+10*scale,text_box.Min.y+8*scale);
    draw->AddText(text_pos,gold,first.c_str());draw->AddText(ImVec2(text_pos.x,text_pos.y+layout.line*scale),tiers[p.tier],second.c_str());
    if(!third.empty())draw->AddText(ImVec2(text_pos.x,text_pos.y+2*layout.line*scale),light,third.c_str());
}
void refresh_explored(State& s) {
    if(!s.explored_only) {
        if(!s.all_points_ready) {
            s.explored.resize(s.data->points.size());
            std::iota(s.explored.begin(),s.explored.end(),0U);
            std::fill(s.methods.begin(),s.methods.end(),0U);
            for(const auto& point:s.data->points)s.methods[point.resource]|=1U<<s.data->sources[point.source].method;
            s.all_points_ready=true;
        }
        return;
    }
    if(s.all_points_ready){s.all_points_ready=false;s.explored_stamp=0;s.explored_session=0;}
    if(!s.snapshot_valid||!s.snapshot.fow_ready){s.explored.clear();std::fill(s.methods.begin(),s.methods.end(),0);s.explored_stamp=0;return;}
    if(s.explored_stamp==s.snapshot.captured_at_ms&&s.explored_session==s.snapshot.session)return;
    s.explored.clear();std::fill(s.methods.begin(),s.methods.end(),0);
    for(std::size_t i=0;i<s.data->points.size();++i){const auto& p=s.data->points[i];if(catalog::revealed(p.x,p.z,s.snapshot.fow.data(),s.snapshot.fow.size())){s.explored.push_back(static_cast<unsigned>(i));s.methods[p.resource]|=1U<<s.data->sources[p.source].method;}}
    s.explored_stamp=s.snapshot.captured_at_ms;s.explored_session=s.snapshot.session;
}
bool known(const State& s,unsigned row) {return !s.known_only||!s.data->resources[row].inventory||(s.snapshot_valid&&s.snapshot.knowledge_ready&&s.snapshot.known(row));}
bool unknown(const State& s,unsigned row) {return s.known_only&&s.data->resources[row].inventory&&s.snapshot_valid&&s.snapshot.knowledge_ready&&!s.snapshot.known(row);}
void receive_state(State& s,const game::Frame& frame,std::uint64_t now) {
    if(game::read_state(frame,s.data->item_digest,now,s.pending_snapshot)) {
        s.snapshot=std::move(s.pending_snapshot);s.accepted_frame=frame;s.accepted_nonce=platform::instance_nonce();s.snapshot_valid=true;return;
    }
    const auto& old=s.accepted_frame;
    const bool same=frame.map_open&&frame.world_ready&&frame.source==game::Availability::compatible&&
        frame.sampled_at_ms&&now>=frame.sampled_at_ms&&now-frame.sampled_at_ms<=1000&&
        old.process_id==frame.process_id&&old.process_creation_time==frame.process_creation_time&&
        old.application_address==frame.application_address&&old.ui_address==frame.ui_address&&old.map_state_address==frame.map_state_address&&
        s.accepted_nonce&&s.accepted_nonce==platform::instance_nonce()&&frame.scope_start_sequence&&
        s.snapshot.source_frame_sequence>=frame.scope_start_sequence&&s.snapshot.source_frame_sequence<=frame.sequence;
    const auto nonzero=[](const auto& guid){return std::any_of(guid.begin(),guid.end(),[](auto v){return v!=0;});};
    const bool guid_ok=(!nonzero(frame.world_guid)||frame.world_guid==s.snapshot.world_guid)&&(!nonzero(frame.hero_guid)||frame.hero_guid==s.snapshot.hero_guid);
    const bool fresh=s.snapshot.captured_at_ms&&s.snapshot.published_at_ms&&now>=s.snapshot.captured_at_ms&&now>=s.snapshot.published_at_ms&&
        now-s.snapshot.captured_at_ms<=1000&&now-s.snapshot.published_at_ms<=1000;
    // Keep the original capture age during an optimistic-copy race. No synthetic
    // heartbeat and no old-world/old-map/old-process fallback is published.
    s.snapshot_valid=s.snapshot_valid&&same&&guid_ok&&fresh;
    if(!s.snapshot_valid)s.snapshot={};
}
float collapsed_panel_height(const State& s,float scale) {
    const float font=ImGui::GetFontSize(),gap=std::ceil(3*scale);
    // Match the fixed panel's padding and controls, including pixel rounding.
    // Search and expanded rows never change its base size.
    float height=2*std::ceil(8*scale)+3*(std::ceil(font)+gap)+
        3*(std::ceil(5*scale)+gap)+std::ceil(std::max(font,21.25F*scale))+gap+6*scale;
    for(unsigned category=0;category<s.data->categories;++category){
        const auto row=std::find_if(s.data->resources.begin(),s.data->resources.end(),[&](const auto& r){return r.category==category;});
        if(row==s.data->resources.end())continue;
        height+=std::ceil(font+6*scale)+2*gap;
        if(!row->inventory)height+=std::ceil(5*scale);
    }
    if(s.known_only&&(!s.snapshot_valid||!s.snapshot.knowledge_ready))height+=std::ceil(font)+gap;
    return std::ceil(height);
}
game::Rect panel_bounds(const State& s,const platform::FrameContext& frame) {
    const float height=static_cast<float>(frame.framebuffer_height),width=static_cast<float>(frame.framebuffer_width);
    const float scale=clamp(height/1440.0F,.65F,1.6F);
    // The optional anchors come from the same validated native widgets already
    // used to protect game controls. Fall back to their reference layout when
    // the current UI tree cannot supply an unambiguous pair.
    float upper=height*(306.4F/1440),lower=height*(968.2667F/1440);
    const auto& g=frame.game;
    if(std::isfinite(g.map_content.top)&&std::isfinite(g.map_content.bottom)&&
       std::max(upper,g.map_content.top)<std::min(lower,g.map_content.bottom)){
        upper=std::max(upper,g.map_content.top);lower=std::min(lower,g.map_content.bottom);
    }
    if(g.sidebar_bounds_ready&&std::isfinite(g.sidebar_upper.bottom)&&std::isfinite(g.sidebar_lower.top)&&
       g.sidebar_upper.bottom>=g.map_content.top&&g.sidebar_lower.top<=g.map_content.bottom&&g.sidebar_upper.bottom<g.sidebar_lower.top){
        upper=g.sidebar_upper.bottom;lower=g.sidebar_lower.top;
    }
    const float panel_height=std::min(collapsed_panel_height(s,scale),std::max(1.0F,lower-upper));
    const float top=std::floor((upper+lower-panel_height)*.5F);
    return {40*scale,top,40*scale+std::min(520*scale,width*.42F),top+panel_height};
}
void map_markers(State& s,const platform::FrameContext& frame,const catalog::Locale& locale,float size) {
    if(!frame.game.world_ready||!frame.game.projection_ready||!frame.game.hud_bounds_ready){game::clear_tracking_hit();return;}
    if(s.explored_only&&(!s.snapshot_valid||!s.snapshot.fow_ready)){game::clear_tracking_hit();return;}
    const auto& g=frame.game;const auto& projection=g.projection;const auto clip=g.map_content;
    if(!(projection.pixels_per_world_unit>0)||!std::isfinite(projection.pixels_per_world_unit)){game::clear_tracking_hit();return;}
    const auto panel=panel_bounds(s,frame);
    // Include the lower-right method badge and hover outline in the envelope.
    const float radius=size*.5F,reach=radius*1.6F+1;
    const auto blocked=[&](ImVec2 pos) {
        const auto overlaps=[&](const game::Rect& r) {
            return std::isfinite(r.left)&&std::isfinite(r.top)&&std::isfinite(r.right)&&std::isfinite(r.bottom)&&
                r.right>r.left&&r.bottom>r.top&&pos.x+reach>=r.left&&pos.x-reach<=r.right&&pos.y+reach>=r.top&&pos.y-reach<=r.bottom;
        };
        if(overlaps(panel))return true;
        for(std::size_t i=0;i<std::min<std::size_t>(g.ui_blocker_count,g.ui_blockers.size());++i)
            if(overlaps(g.ui_blockers[i]))return true;
        return false;
    };
    s.markers.clear();
    for(const auto index:s.explored) {
        const auto& p=s.data->points[index];if(!s.selected[p.resource]||!known(s,p.resource))continue;
        const auto method_id=s.data->sources[p.source].method;if(method_id<8&&!s.filters[method_id])continue;
        ImVec2 pos(projection.screen_center.x+(p.x-projection.world_center.x)*projection.pixels_per_world_unit,
                   projection.screen_center.y-(p.z-projection.world_center.y)*projection.pixels_per_world_unit);
        if(!std::isfinite(pos.x)||!std::isfinite(pos.y))continue;
        if(pos.x+size<clip.left||pos.x-size>clip.right||pos.y+size<clip.top||pos.y-size>clip.bottom)continue;
        if(blocked(pos))continue;
        s.markers.push_back({index,pos});
    }
    auto* draw=ImGui::GetBackgroundDrawList();draw->PushClipRect(ImVec2(clip.left,clip.top),ImVec2(clip.right,clip.bottom),true);
    const auto mouse=ImGui::GetIO().MousePos;float nearest=std::numeric_limits<float>::infinity();const Marker* hovered{};
    // Paint a complete marker at a time. A later image can no longer cover
    // another marker's tier outline while leaving its badge on a different layer.
    for(const auto& marker:s.markers) {
        const auto& point=s.data->points[marker.point];const auto& source=s.data->sources[point.source];
        const auto& resource=s.data->resources[point.resource];
        const bool square=!resource.inventory&&source.method==9;
        const ImVec2 lo(marker.xy.x-radius,marker.xy.y-radius),hi(marker.xy.x+radius,marker.xy.y+radius);
        const float rounding=square?radius*.35F:radius;
        if(square)draw->AddRectFilled(lo,hi,ink,rounding);
        else draw->AddCircleFilled(marker.xy,radius,ink,32);
        if(const auto tex=texture(s,resource.icon))draw->AddImageRounded(tex,ImVec2(lo.x+2,lo.y+2),ImVec2(hi.x-2,hi.y-2),ImVec2(0,0),ImVec2(1,1),IM_COL32_WHITE,std::max(0.0F,rounding-2));
        if(square)draw->AddRect(lo,hi,tiers[point.tier],rounding,0,1.4F);
        else draw->AddCircle(marker.xy,radius,tiers[point.tier],32,1.4F);
        const float badge=size*.65F,offset=radius*.70710678F;
        const ImVec2 badge_center(marker.xy.x+offset,marker.xy.y+offset);
        const ImVec2 badge_pos(badge_center.x-badge/2,badge_center.y-badge/2);
        draw->AddCircleFilled(badge_center,badge/2+1,ink,24);
        method(draw,s,source.method,badge_pos,badge);
        draw->AddCircle(badge_center,badge/2+1,muted,24,1);
        const float dx=marker.xy.x-mouse.x,dy=marker.xy.y-mouse.y,d=dx*dx+dy*dy;
        const float corner_x=std::max(0.0F,std::abs(dx)-(radius-rounding));
        const float corner_y=std::max(0.0F,std::abs(dy)-(radius-rounding));
        const bool on_main=square?corner_x*corner_x+corner_y*corner_y<=rounding*rounding:d<=radius*radius;
        const float badge_x=badge_center.x-mouse.x,badge_y=badge_center.y-mouse.y;
        const bool on_badge=badge_x*badge_x+badge_y*badge_y<=(badge/2+1)*(badge/2+1);
        if((on_main||on_badge)&&d<=nearest){nearest=d;hovered=&marker;}
    }
    const bool over_panel=mouse.x>=panel.left&&mouse.x<panel.right&&mouse.y>=panel.top&&mouse.y<panel.bottom;
    if(hovered&&!over_panel&&mouse.x>=clip.left&&mouse.x<clip.right&&mouse.y>=clip.top&&mouse.y<clip.bottom&&!ImGui::GetIO().WantCaptureMouse) {
        const auto& point=s.data->points[hovered->point];
        if(!s.data->resources[point.resource].inventory&&s.data->sources[point.source].method==9)
            draw->AddRect(ImVec2(hovered->xy.x-radius-3,hovered->xy.y-radius-3),ImVec2(hovered->xy.x+radius+3,hovered->xy.y+radius+3),IM_COL32_WHITE,radius*.35F+3,0,1.4F);
        else draw->AddCircle(hovered->xy,radius+3,IM_COL32_WHITE,32,1.4F);
    }else hovered=nullptr;
    draw->PopClipRect(); // Tooltip windows deliberately escape the map-only clip.
    if(hovered) {
        const auto& point=s.data->points[hovered->point];
        const bool square=!s.data->resources[point.resource].inventory&&s.data->sources[point.source].method==9;
        const float offset=radius*.70710678F,badge_radius=size*.325F+1;
        const game::Vec2 badge_center{hovered->xy.x+offset,hovered->xy.y+offset};
        game::TrackingHit hit{};hit.scope=frame.game;
        hit.native_window=reinterpret_cast<std::uintptr_t>(frame.native_window);
        hit.source_point_id=static_cast<std::uint64_t>(hovered->point)+1;
        hit.x=point.x;hit.y=point.y;hit.z=point.z;hit.source_flags=point.flags;
        hit.areas[0]={{hovered->xy.x-radius,hovered->xy.y-radius,hovered->xy.x+radius,hovered->xy.y+radius},square?radius*.35F:radius,square?game::TrackingShape::rounded_rectangle:game::TrackingShape::circle};
        hit.areas[1]={{badge_center.x-badge_radius,badge_center.y-badge_radius,badge_center.x+badge_radius,badge_center.y+badge_radius},badge_radius,game::TrackingShape::circle};
        hit.area_count=2;
        if(!game::publish_tracking_hit(hit))game::clear_tracking_hit();
        point_tip(s,locale,*hovered);
    }else game::clear_tracking_hit();
}
struct PanelStyle {
    static constexpr std::array<std::pair<ImGuiCol,ImU32>,23> colors{{
        {ImGuiCol_WindowBg,IM_COL32(32,33,37,240)},{ImGuiCol_ChildBg,0},
        {ImGuiCol_Border,IM_COL32(141,128,92,230)},{ImGuiCol_Text,light},{ImGuiCol_TextDisabled,muted},
        {ImGuiCol_FrameBg,IM_COL32(50,51,56,255)},{ImGuiCol_FrameBgHovered,IM_COL32(71,70,60,255)},
        {ImGuiCol_FrameBgActive,IM_COL32(92,85,64,255)},{ImGuiCol_CheckMark,IM_COL32(197,172,106,255)},
        {ImGuiCol_Button,IM_COL32(63,58,45,255)},{ImGuiCol_ButtonHovered,IM_COL32(102,88,59,255)},
        {ImGuiCol_ButtonActive,IM_COL32(141,119,73,255)},
        {ImGuiCol_Header,IM_COL32(57,55,47,255)},{ImGuiCol_HeaderHovered,IM_COL32(97,88,61,255)},
        {ImGuiCol_HeaderActive,IM_COL32(132,115,72,255)},
        {ImGuiCol_ScrollbarBg,IM_COL32(37,38,42,160)},{ImGuiCol_ScrollbarGrab,IM_COL32(101,92,69,230)},
        {ImGuiCol_ScrollbarGrabHovered,IM_COL32(139,123,83,255)},{ImGuiCol_ScrollbarGrabActive,IM_COL32(181,156,96,255)},
        {ImGuiCol_Separator,IM_COL32(141,128,92,180)},{ImGuiCol_NavCursor,gold},
        {ImGuiCol_TextSelectedBg,IM_COL32(141,119,73,100)},{ImGuiCol_PopupBg,ink}
    }};
    explicit PanelStyle(float scale) {
        for(const auto& [key,color]:colors)ImGui::PushStyleColor(key,color);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,5*scale);
        ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding,4*scale);
        ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding,5*scale);
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding,3*scale);
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarRounding,3*scale);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize,1.0F);
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize,0.0F);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(10*scale,8*scale));
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,ImVec2(5*scale,3*scale));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(5*scale,3*scale));
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarSize,8*scale);
    }
    ~PanelStyle(){ImGui::PopStyleVar(11);ImGui::PopStyleColor(static_cast<int>(colors.size()));}
};
void panel(State& s,const platform::FrameContext& frame,const catalog::Locale& locale,float scale) {
    const auto bounds=panel_bounds(s,frame);const float panel_width=bounds.right-bounds.left,panel_height=bounds.bottom-bounds.top;
    ImGui::SetNextWindowPos(ImVec2(bounds.left,bounds.top),ImGuiCond_Always);ImGui::SetNextWindowSize(ImVec2(panel_width,panel_height));
    PanelStyle theme(scale);
    ImGui::Begin("##resource_scanner",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoScrollWithMouse|ImGuiWindowFlags_NoScrollbar);
    auto line=[&](float thickness){const auto pos=ImGui::GetCursorScreenPos();ImGui::GetWindowDrawList()->AddLine(pos,ImVec2(pos.x+ImGui::GetContentRegionAvail().x,pos.y),IM_COL32(175,153,95,145),thickness);ImGui::Dummy(ImVec2(0,5*scale));};
    const auto& title=s.data->label(locale,"ui.title");ImGui::SetCursorPosX(std::max(8.0F,(panel_width-ImGui::CalcTextSize(title.c_str()).x)/2));ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(gold),"%s",title.c_str());line(1.8F);
    ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(gold),"%s",s.data->label(locale,"ui.filter").c_str());
    const float button=21.25F*scale,spacing=5*scale;const float right=ImGui::GetWindowContentRegionMax().x;
    ImGui::SameLine(std::max(ImGui::GetCursorPosX(),right-8*(button+spacing)));
    for(unsigned n=0;n<8;++n){ImGui::PushID(static_cast<int>(n));const bool hover=icon_button(s,n,s.filters[n]?IM_COL32_WHITE:IM_COL32(103,104,109,180),button,"filter");if(ImGui::IsItemClicked())s.filters[n]=!s.filters[n];if(hover)simple_tip(s.data->label(locale,method_key(n)));ImGui::PopID();if(n<7)ImGui::SameLine(0,spacing);}
    line(1.8F);ImGui::SetNextItemWidth(-1);ImGui::InputTextWithHint("##search",s.data->label(locale,"ui.search").c_str(),s.query.data(),s.query.size());line(1);
    if(ImGui::SmallButton(s.data->label(locale,"ui.hide_all").c_str())){std::fill(s.selected.begin(),s.selected.end(),0);save_selection(s);}
    if(s.known_only&&(!s.snapshot_valid||!s.snapshot.knowledge_ready))ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(orange),"%s",s.data->label(locale,"ui.knowledge_unavailable").c_str());
    ImGui::BeginChild("##resource_rows",ImVec2(0,0),ImGuiChildFlags_None,ImGuiWindowFlags_NoBackground);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(5*scale,0));
    const auto query=fold(s.query.data());const bool invalid_query=s.query[0]!='\0'&&query.empty();
    const float row_height=std::max({24*scale,ImGui::GetFontSize()+5,ImGui::GetFrameHeight()+2*scale}),badge=17*scale,icon_gap=4*scale;
    for(unsigned category=0;category<s.data->categories;++category) {
        std::vector<unsigned> rows;for(unsigned n=0;n<s.data->resources.size();++n)if(!invalid_query&&s.data->resources[n].category==category&&(query.empty()||s.names_folded[n].find(query)!=std::wstring::npos))rows.push_back(n);
        if(rows.empty())continue;
        std::stable_sort(rows.begin(),rows.end(),[&](auto a,auto b){const auto ua=unknown(s,a),ub=unknown(s,b);return ua!=ub?!ua:locale.ranks[a]<locale.ranks[b];});
        if(!s.data->resources[rows.front()].inventory)line(1);
        const std::string category_key="category."+std::to_string(category);ImGui::PushID(static_cast<int>(category));
        static constexpr std::array<ImU32,14> category_colors{
            IM_COL32(53,76,82,210),IM_COL32(70,71,72,210),IM_COL32(88,72,53,210),IM_COL32(55,74,49,210),
            IM_COL32(84,77,48,210),IM_COL32(82,65,51,210),IM_COL32(84,54,54,210),IM_COL32(64,76,65,210),
            IM_COL32(79,72,61,210),IM_COL32(69,58,85,210),IM_COL32(68,75,54,210),IM_COL32(80,69,81,210),
            IM_COL32(50,77,88,210),IM_COL32(69,65,91,210)};
        const auto category_color=category_colors[category%category_colors.size()];
        ImGui::PushStyleColor(ImGuiCol_Header,category_color);ImGui::PushStyleColor(ImGuiCol_HeaderHovered,category_color);ImGui::PushStyleColor(ImGuiCol_HeaderActive,category_color);
        if(!query.empty())ImGui::SetNextItemOpen(true,ImGuiCond_Always);
        else ImGui::SetNextItemOpen(false,ImGuiCond_Once);
        const bool open=ImGui::CollapsingHeader(s.data->label(locale,category_key.c_str()).c_str(),ImGuiTreeNodeFlags_AllowOverlap);
        const auto category_max=ImGui::GetItemRectMax();ImGui::SameLine(ImGui::GetWindowContentRegionMax().x-38*scale);
        bool all=std::all_of(rows.begin(),rows.end(),[&](auto n){return s.selected[n]!=0;});
        if(ImGui::SmallButton(s.data->label(locale,all?"ui.text.dc9337ff5b42":"ui.text.c3089753a246").c_str())){for(auto n:rows)s.selected[n]=!all;save_selection(s);}
        ImGui::PopStyleColor(3);(void)category_max;ImGui::Dummy(ImVec2(0,3*scale));
        if(open){ImGuiListClipper clipper;clipper.Begin(static_cast<int>(rows.size()),row_height);
        while(clipper.Step())for(int row_index=clipper.DisplayStart;row_index<clipper.DisplayEnd;++row_index) {
            const auto row=rows[static_cast<std::size_t>(row_index)];
            const auto& resource=s.data->resources[row];const bool unlearned=unknown(s,row);
            const bool waiting=s.known_only&&resource.inventory&&(!s.snapshot_valid||!s.snapshot.knowledge_ready);ImGui::PushID(static_cast<int>(row));
            const auto start=ImGui::GetCursorScreenPos();auto* draw=ImGui::GetWindowDrawList();const float full=ImGui::GetContentRegionAvail().x;
            bool checked=s.selected[row]!=0;ImGui::SetCursorScreenPos(ImVec2(start.x,start.y+(row_height-ImGui::GetFrameHeight())/2));if(ImGui::Checkbox("##selected",&checked)){s.selected[row]=checked;save_selection(s);}
            const float left=start.x+row_height+4*scale;const auto tex=texture(s,resource.icon);if(tex)draw->AddImage(tex,ImVec2(left,start.y+2*scale),ImVec2(left+row_height-4*scale,start.y+row_height-2*scale));
            std::vector<unsigned> badges;
            if(unlearned)badges.push_back(13);
            else if(waiting)badges.push_back(12);
            else {for(unsigned n=0;n<10;++n)if(s.methods[row]&(1U<<n))badges.push_back(n);if(resource.chest)badges.push_back(11);if(resource.craftable)badges.push_back(10);if(badges.empty())badges.push_back(12);}
            const float badge_width=static_cast<float>(badges.size())*(badge+icon_gap),name_x=left+row_height+3*scale,badges_x=start.x+full-badge_width;
            if(unlearned||waiting)draw->AddRectFilled(ImVec2(name_x-2*scale,start.y+scale),ImVec2(start.x+full,start.y+row_height-scale),IM_COL32(64,64,69,140),3*scale);
            const auto& name=s.data->text(locale.display_names[row]);const float text_y=start.y+(row_height-ImGui::GetFontSize())/2;
            draw->PushClipRect(ImVec2(name_x,start.y),ImVec2(std::max(name_x,badges_x-5*scale),start.y+row_height),true);draw->AddText(ImVec2(name_x,text_y),unlearned?muted:light,name.c_str());draw->PopClipRect();
            for(unsigned i=0;i<badges.size();++i) {
                const auto kind=badges[i];ImGui::SetCursorScreenPos(ImVec2(badges_x+i*(badge+icon_gap),start.y+(row_height-badge)/2));ImGui::PushID(static_cast<int>(i));
                const bool hovered=icon_button(s,kind,kind==13?red:kind==12?orange:kind>=10?route_gold:IM_COL32_WHITE,badge,"method");
                if(hovered) {
                    if(kind==10)recipe_tip(s,locale,row);
                    else if(kind==13)simple_tip(s.data->label(locale,"ui.unknown"));
                    else if(kind==12){
                        bool fish=false;for(unsigned n=0;n<resource.source_count;++n)fish|=s.data->sources[resource.source_begin+n].method==8;
                        const bool scope_ready=!s.explored_only||(s.snapshot_valid&&s.snapshot.fow_ready);
                        const char* key=waiting?"ui.knowledge_unavailable":!scope_ready?"ui.unavailable":resource.inventory?"ui.absent":fish?"ui.fish_absent":"ui.tame_absent";
                        const auto& note=s.data->text(locale.notes[row]);
                        if(!waiting&&scope_ready&&!note.empty())simple_tip(note);
                        else if(!waiting&&scope_ready&&!s.explored_only)simple_tip(options::label(locale.native_id,"ui.absent_global"));
                        else simple_tip(s.data->label(locale,key));
                    }
                    else if(kind==11){const auto& note=s.data->text(locale.notes[row]);simple_tip(note.empty()?s.data->label(locale,"ui.chest"):note);}
                    else simple_tip(s.data->label(locale,method_key(kind)));
                }
                ImGui::PopID();
            }
            ImGui::SetCursorScreenPos(start);ImGui::Dummy(ImVec2(full,row_height));ImGui::PopID();
        }}
        ImGui::PopID();ImGui::Dummy(ImVec2(0,3*scale));
    }
    ImGui::PopStyleVar();ImGui::EndChild();ImGui::End();
}
} // namespace
void render(void*,const platform::FrameContext& frame) noexcept {
    ImGuiErrorRecoveryState saved{};bool recovery_ready=false;
    const auto recover=[&]() noexcept {
        if(!recovery_ready||!frame.imgui)return;
        ImGui::SetCurrentContext(frame.imgui);auto& io=ImGui::GetIO();
        const bool assertion=io.ConfigErrorRecoveryEnableAssert,debug=io.ConfigErrorRecoveryEnableDebugLog,tip=io.ConfigErrorRecoveryEnableTooltip;
        io.ConfigErrorRecoveryEnableAssert=false;io.ConfigErrorRecoveryEnableDebugLog=false;io.ConfigErrorRecoveryEnableTooltip=false;
        ImGui::ErrorRecoveryTryToRecoverState(&saved);
        io.ConfigErrorRecoveryEnableAssert=assertion;io.ConfigErrorRecoveryEnableDebugLog=debug;io.ConfigErrorRecoveryEnableTooltip=tip;
    };
    try {
        if(!frame.imgui){game::clear_tracking_hit();return;}ImGui::SetCurrentContext(frame.imgui);ImGui::ErrorRecoveryStoreState(&saved);recovery_ready=true;
        auto& s=state();if(!s.started)initialize(s);receive_catalog(s);
        const bool pressed=(GetAsyncKeyState(static_cast<int>(platform::visibility_key()))&0x8000)!=0;
        if(pressed&&!s.toggle_down&&GetForegroundWindow()==frame.native_window){s.enabled=!s.enabled;if(!s.ini.empty()&&s.ini.is_absolute())WritePrivateProfileStringW(L"Scanner",L"Enabled",s.enabled?L"1":L"0",s.ini.c_str());}s.toggle_down=pressed;
        if(!frame.game.map_open||!s.enabled){game::clear_tracking_hit();return;}
        if(!s.data){
            game::clear_tracking_hit();
            const auto& requested=shell::get(frame.game.native_language_id);
            const auto& labels=platform::font_available(requested.font)?requested:shell::get(1);
            auto* font=platform::font(labels.font);if(font)ImGui::PushFont(font,ui_font_size);
            ImGui::SetNextWindowPos(ImVec2(40,std::max(160.0F,frame.framebuffer_height*.23F)),ImGuiCond_Always);
            ImGui::SetNextWindowBgAlpha(.88F);
            ImGui::Begin("##resource_status",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_AlwaysAutoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings);
            ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(gold),"%s",labels.title);
            ImGui::TextUnformatted(s.failed?labels.unavailable:labels.waiting);ImGui::End();if(font)ImGui::PopFont();return;
        }
        if(s.texture_generation!=frame.texture_generation){std::fill(s.textures.begin(),s.textures.end(),0);s.method_textures.fill(0);s.texture_generation=frame.texture_generation;}
        const auto& requested_locale=s.data->locale(frame.game.native_language_id);
        const auto& locale=platform::font_available(requested_locale.font_role)?requested_locale:s.data->locale(1);
        if(s.font_language!=locale.native_id){s.names_folded.clear();for(const auto index:locale.names)s.names_folded.push_back(fold(s.data->text(index)));s.font_language=locale.native_id;}
        auto* font=platform::font(locale.font_role);if(font)ImGui::PushFont(font,ui_font_size);
        const float scale=clamp(frame.framebuffer_height/1440.0F,.65F,1.6F);
        receive_state(s,frame.game,GetTickCount64());refresh_explored(s);
        map_markers(s,frame,locale,34*scale);panel(s,frame,locale,scale);
        if(font)ImGui::PopFont();
    } catch(const std::exception& error){game::clear_tracking_hit();recover();platform::log("ui",error.what());}
    catch(...){game::clear_tracking_hit();recover();platform::log("ui","Unexpected UI failure");}
}
bool finish_loading(unsigned timeout_ms) noexcept {
    try {auto& s=state();return !s.loading.valid()||s.loading.wait_for(std::chrono::milliseconds(timeout_ms))==std::future_status::ready;}
    catch(...){return false;}
}
} // namespace rs::ui
