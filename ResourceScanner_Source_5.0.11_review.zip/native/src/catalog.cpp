#include <rs/catalog.hpp>
#include <nlohmann/json.hpp>
#include <zstd.h>
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <bcrypt.h>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <utility>

namespace rs::catalog {
namespace {
using Json = nlohmann::json;
constexpr std::size_t max_bytes = 512ULL * 1024 * 1024;
void require(bool ok, const char* why) { if (!ok) throw std::runtime_error(why); }
std::uint32_t u32(const std::uint8_t* p) {
    return std::uint32_t(p[0]) | std::uint32_t(p[1]) << 8 |
           std::uint32_t(p[2]) << 16 | std::uint32_t(p[3]) << 24;
}
std::uint64_t u64(const std::uint8_t* p) { return u32(p) | std::uint64_t(u32(p + 4)) << 32; }
float f32(const std::uint8_t* p) { const auto v = u32(p); float f; std::memcpy(&f, &v, 4); return f; }
std::array<std::uint8_t, 32> digest(const std::uint8_t* p, std::size_t n) {
    BCRYPT_ALG_HANDLE algorithm{}; BCRYPT_HASH_HANDLE hash{};
    std::vector<std::uint8_t> object;
    std::array<std::uint8_t, 32> out{};
    try {
        require(BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0) >= 0, "SHA256 provider unavailable");
        DWORD needed{}, length{};
        require(BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH, reinterpret_cast<PUCHAR>(&length), sizeof(length), &needed, 0) >= 0 && length && length < 65536, "SHA256 object length");
        object.resize(length);
        require(BCryptCreateHash(algorithm, &hash, object.data(), length, nullptr, 0, 0) >= 0, "SHA256 creation failed");
        require(n <= std::numeric_limits<ULONG>::max(), "SHA256 input bound");
        require(BCryptHashData(hash, const_cast<PUCHAR>(p), static_cast<ULONG>(n), 0) >= 0, "SHA256 input failed");
        require(BCryptFinishHash(hash, out.data(), static_cast<ULONG>(out.size()), 0) >= 0, "SHA256 finish failed");
    } catch (...) {
        if (hash) BCryptDestroyHash(hash);
        if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0);
        throw;
    }
    BCryptDestroyHash(hash); BCryptCloseAlgorithmProvider(algorithm, 0);
    return out;
}
std::uint32_t crc32(const std::uint8_t* p, std::size_t n) {
    std::uint32_t value = ~0U;
    for (std::size_t i = 0; i < n; ++i) {
        value ^= p[i];
        for (unsigned bit = 0; bit != 8; ++bit) value = (value >> 1) ^ (0xEDB88320U & (0U - (value & 1)));
    }
    return ~value;
}
struct Block { const std::uint8_t* p{}; std::size_t bytes{}; std::uint64_t count{}; std::uint32_t stride{}; };
std::unordered_map<std::string, Block> sections(const std::vector<std::uint8_t>& raw) {
    require(raw.size() >= 64 && raw.size() <= max_bytes, "Catalog size outside bounds");
    require(std::memcmp(raw.data(), "RSCN\0\0\0\0", 8) == 0 && u32(raw.data()+8) == 1 && u32(raw.data()+12) == 64 && u32(raw.data()+20) == 0, "Unsupported catalog header");
    const auto count = u32(raw.data()+16);
    require(count && count <= 64 && 64 + std::size_t(count)*40 <= raw.size() && u64(raw.data()+24) == raw.size(), "Catalog directory bound");
    const auto hash = digest(raw.data()+64, raw.size()-64);
    require(std::memcmp(hash.data(), raw.data()+32, 32) == 0, "Catalog payload digest differs");
    std::unordered_map<std::string, Block> result;
    std::uint64_t end = 64 + std::uint64_t(count)*40;
    for (std::uint32_t i = 0; i < count; ++i) {
        const auto* d = raw.data()+64+std::size_t(i)*40;
        std::string name;
        bool padding = false;
        for (unsigned j = 0; j < 8; ++j) {
            if (!d[j]) { padding = true; continue; }
            require(!padding && ((d[j] >= 'A' && d[j] <= 'Z') || (d[j] >= '0' && d[j] <= '9') || d[j] == '_'), "Invalid section identifier");
            name += char(d[j]);
        }
        const auto offset = u64(d+8), bytes = u64(d+16), items = u64(d+24);
        const auto stride = u32(d+32);
        require(!name.empty() && !result.count(name) && offset%16 == 0 && offset >= end && offset <= raw.size() && bytes <= raw.size()-offset, "Invalid section range");
        require(items <= 0xFFFFFFFFULL && (!stride || (items <= max_bytes/stride && items*stride == bytes)), "Invalid section dimensions");
        require(std::all_of(raw.begin()+static_cast<std::ptrdiff_t>(end), raw.begin()+static_cast<std::ptrdiff_t>(offset), [](auto v){return !v;}), "Nonzero section padding");
        require(crc32(raw.data()+offset, static_cast<std::size_t>(bytes)) == u32(d+36), "Section CRC differs");
        result.emplace(name, Block{raw.data()+offset, static_cast<std::size_t>(bytes), items, stride});
        end = offset + bytes;
    }
    require(end == raw.size(), "Trailing catalog data");
    require(result.count("META") && result.count("POINTS") && result.count("RGBA"), "Required catalog section missing");
    return result;
}
std::uint32_t unsigned_value(const Json& value) {
    require(value.is_number_integer(),"Expected an unsigned integer");
    if(value.is_number_unsigned()) {
        const auto n=value.get<std::uint64_t>();require(n<=0xFFFFFFFFULL,"Unsigned integer overflow");return static_cast<std::uint32_t>(n);
    }
    const auto n=value.get<std::int64_t>();require(n>=0&&n<=0xFFFFFFFFLL,"Unsigned integer range");return static_cast<std::uint32_t>(n);
}
std::uint32_t number(const Json& value, const char* key) { return unsigned_value(value.at(key)); }
std::uint32_t optional_number(const Json& value,const char* key,std::uint32_t fallback=0) {
    const auto it=value.find(key);return it==value.end()||it->is_null()?fallback:unsigned_value(*it);
}
Text text_index(const Json& value, std::size_t count) { const auto n=unsigned_value(value); require(n<count,"Text index outside pool"); return n; }
std::vector<Text> text_indices(const Json& value, std::size_t count) {
    require(value.is_array(), "Text indices must be an array");
    std::vector<Text> out; out.reserve(value.size());
    for (const auto& v:value) out.push_back(text_index(v,count));
    return out;
}
std::vector<std::uint8_t> read_file(const std::filesystem::path& path) {
    std::ifstream stream(path, std::ios::binary | std::ios::ate);
    require(bool(stream), "Cannot open resource catalog");
    const auto end=stream.tellg();
    require(end>=0 && static_cast<std::uint64_t>(end)<=max_bytes, "Stored catalog size outside bounds");
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(end));
    stream.seekg(0); require(bool(stream.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()))),"Short resource catalog read");
    char extra{}; require(!stream.get(extra),"Catalog changed during read");
    if (bytes.size()>=4 && u32(bytes.data()) == 0xFD2FB528U) {
        const auto size=ZSTD_getFrameContentSize(bytes.data(),bytes.size());
        require(size!=ZSTD_CONTENTSIZE_ERROR && size!=ZSTD_CONTENTSIZE_UNKNOWN && size>=64 && size<=max_bytes,"Compressed catalog size outside bounds");
        require(ZSTD_findFrameCompressedSize(bytes.data(),bytes.size())==bytes.size(),"Trailing compressed catalog frame");
        std::vector<std::uint8_t> raw(static_cast<std::size_t>(size));
        const auto got=ZSTD_decompress(raw.data(),raw.size(),bytes.data(),bytes.size());
        require(!ZSTD_isError(got) && got==raw.size(),"Catalog decompression failed");
        return raw;
    }
    return bytes;
}
} // namespace

const std::string& Catalog::text(Text index) const noexcept {
    static const std::string empty;
    return index<texts.size()?texts[index]:empty;
}
const std::string& Catalog::label(const Locale& l,const char* key) const noexcept {
    const auto it=l.labels.find(key);
    if(it!=l.labels.end()) return text(it->second);
    static const std::string empty;
    return empty;
}
const Locale& Catalog::locale(std::uint32_t id) const noexcept {
    for(const auto& l:locales) if(l.native_id==id) return l;
    for(const auto& l:locales) if(l.native_id==1) return l;
    return locales.front();
}
bool revealed(float x,float z,const std::uint8_t* bits,std::size_t bytes) noexcept {
    if(!bits || bytes!=204800 || !std::isfinite(x) || !std::isfinite(z) || x<0 || z<0 || x>=10240 || z>=10240) return false;
    const auto px=static_cast<unsigned>(x/8), py=1279-static_cast<unsigned>(z/8);
    const auto bit=py*1280+px;
    return (bits[bit/8] & (1U<<(bit%8)))!=0;
}
LoadResult load(const std::filesystem::path& path) noexcept {
    try {
        auto bytes=read_file(path);
        const auto blocks=sections(bytes);
        const auto meta=blocks.at("META"), points=blocks.at("POINTS"), rgba=blocks.at("RGBA");
        require(meta.bytes<=192ULL*1024*1024 && points.stride==28 && points.count<=8000000,"Catalog section model bound");
        auto j=Json::parse(meta.p,meta.p+meta.bytes);
        require(number(j,"schema_version")==1,"Unsupported catalog model");
        auto out=std::make_shared<Catalog>();
        out->texts=j.at("text_pool").get<std::vector<std::string>>();
        require(!out->texts.empty() && out->texts.size()<=2000000,"Text pool bound");
        for(const auto& t:out->texts) require(t.size()<=65536 && t.find('\0')==std::string::npos,"Invalid catalog string");
        out->categories=static_cast<std::uint32_t>(j.at("categories").size());
        require(out->categories && out->categories<=128,"Category count bound");
        for(const auto& v:j.at("resources")) {
            Resource r; r.id=v.at("id").get<std::string>(); r.item=number(v,"item_id");r.category=number(v,"category");r.icon=number(v,"icon");
            r.source_begin=number(v,"source_begin");r.source_count=number(v,"source_count");r.point_begin=number(v,"point_begin");r.point_count=number(v,"point_count");
            r.inventory=v.at("inventory_item").get<bool>();r.craftable=v.at("craftable").get<bool>();r.chest=v.at("chest_eligible").get<bool>();
            require(number(v,"index")==out->resources.size() && r.category<out->categories,"Resource identity/range"); out->resources.push_back(std::move(r));
        }
        require(!out->resources.empty() && out->resources.size()<=10000,"Resource count bound");
        for(const auto& v:j.at("icons")) {
            Icon i{number(v,"width"),number(v,"height"),v.at("byte_offset").get<std::uint64_t>(),v.at("byte_length").get<std::uint64_t>()};
            require(number(v,"index")==out->icons.size() && i.width && i.height && i.width<=4096 && i.height<=4096 && i.bytes==std::uint64_t(i.width)*i.height*4 && i.offset<=rgba.bytes && i.bytes<=rgba.bytes-i.offset,"Icon range"); out->icons.push_back(i);
        }
        for(const auto& v:j.at("sources")) {
            Source s; s.resource=number(v,"resource_index");s.method=number(v,"method");s.source_class=number(v,"source_class");s.tier=number(v,"tier");s.blocks=v.value("approx_blocks",0.0F);
            require(number(v,"index")==out->sources.size() && s.resource<out->resources.size() && s.method<12 && s.tier<=2 && std::isfinite(s.blocks) && s.blocks>=0,"Source range");
            for(const auto& state:v.at("portrait_states")) { const auto icon=number(state,"icon"),condition=number(state,"condition");require(icon<out->icons.size()&&condition<=2,"Portrait icon/condition range");s.portraits.push_back({icon,condition}); }
            out->sources.push_back(std::move(s));
        }
        out->points.reserve(static_cast<std::size_t>(points.count));
        for(std::uint64_t i=0;i<points.count;++i) {
            const auto* p=points.p+i*28;
            Point v{u32(p),u32(p+4),f32(p+8),f32(p+12),f32(p+16),f32(p+20),p[24],p[25]};
            require(v.resource<out->resources.size() && v.source<out->sources.size() && out->sources[v.source].resource==v.resource && v.tier<=2 && !(v.flags&~1) && p[26]==0 && p[27]==0,"Point identity/range");
            require(std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z)&&std::isfinite(v.blocks)&&v.blocks>=0,"Point geometry"); out->points.push_back(v);
        }
        std::vector<std::uint8_t> ids;
        for(std::size_t i=0;i<out->resources.size();++i) {
            const auto& r=out->resources[i];
            require(r.icon<out->icons.size() && r.source_begin<=out->sources.size() && r.source_count<=out->sources.size()-r.source_begin && r.point_begin<=out->points.size() && r.point_count<=out->points.size()-r.point_begin,"Resource spans");
            for(std::uint32_t n=0;n<r.source_count;++n) require(out->sources[r.source_begin+n].resource==i,"Source span owner");
            for(std::uint32_t n=0;n<r.point_count;++n) require(out->points[r.point_begin+n].resource==i,"Point span owner");
            for(unsigned n=0;n<4;++n) ids.push_back(static_cast<std::uint8_t>(r.item>>(8*n)));
        }
        out->item_digest=digest(ids.data(),ids.size());
        for(const auto& v:j.at("locales")) {
            Locale l;l.tag=v.at("tag").get<std::string>();l.native_id=number(v,"native_id");l.font_role=v.at("font_role").get<std::string>();
            l.names=text_indices(v.at("rows_logical"),out->texts.size());l.display_names=text_indices(v.at("rows_display"),out->texts.size());
            l.titles=text_indices(v.at("titles_display"),out->texts.size());
            l.notes=text_indices(v.contains("notes_display")?v.at("notes_display"):v.at("notes_logical"),out->texts.size());
            for(const auto& rank:v.at("row_ranks")) {const auto n=unsigned_value(rank);require(n<out->resources.size(),"Locale rank range");l.ranks.push_back(n);}
            require(l.names.size()==out->resources.size()&&l.display_names.size()==l.names.size()&&l.titles.size()==l.names.size()&&l.notes.size()==l.names.size()&&l.ranks.size()==l.names.size(),"Locale resource closure");
            for(const char* key:{"static_display","semantic_display"}) for(auto it=v.at(key).begin();it!=v.at(key).end();++it) l.labels[it.key()]=text_index(it.value(),out->texts.size());
            for(const auto& s:v.at("sources_view")) l.sources.push_back({text_index(s.at("action_display"),out->texts.size()),text_index(s.at("reason_display"),out->texts.size()),text_index(s.at("vein_detail_display"),out->texts.size())});
            require(l.sources.size()==out->sources.size(),"Locale source closure");
            for(const auto& layer:v.at("recipe_layers")) {
                RecipeLayer rl;rl.resource=number(layer,"resource_index");require(rl.resource<out->resources.size(),"Recipe resource range");
                for(const auto& place:layer.at("places")) {
                    Place pl;pl.heading=text_index(place.at("heading_display"),out->texts.size());
                    for(const auto& recipe:place.at("recipes")) {
                        Recipe re;re.id=number(recipe,"recipe_id");
                        for(const auto& row:recipe.at("rows")) {
                            Ingredient in;in.icon=optional_number(row,"icon_index",0xFFFFFFFFU);in.item=optional_number(row,"item_id");in.amount=optional_number(row,"amount_u32");in.group=number(row,"group_index");in.text=text_index(row.at("text_display"),out->texts.size());in.style=row.at("style").get<std::string>();in.role=row.at("role").get<std::string>();
                            require((in.icon==0xFFFFFFFFU&&in.role=="alternative-caption")||in.icon<out->icons.size(),"Recipe icon range");re.ingredients.push_back(std::move(in));
                        }
                        pl.recipes.push_back(std::move(re));
                    }
                    rl.places.push_back(std::move(pl));
                }
                l.recipes.push_back(std::move(rl));
            }
            require(std::none_of(out->locales.begin(),out->locales.end(),[&](const auto& old){return old.native_id==l.native_id;}),"Duplicate native locale");out->locales.push_back(std::move(l));
        }
        require(!out->locales.empty()&&std::any_of(out->locales.begin(),out->locales.end(),[](const auto& l){return l.native_id==1;}),"English fallback unavailable");
        out->pixels.assign(rgba.p,rgba.p+rgba.bytes);
        return {std::move(out),{}};
    } catch(const std::exception& e) { return {{},e.what()}; }
    catch(...) { return {{},"Unknown catalog failure"}; }
}
} // namespace rs::catalog
