#pragma once
// Optional native control/input areas. Only explicit GAME widget scopes are
// selected; whole viewport, map image and full-height layout parents are not.
void collect_ui_blockers(Read& read,Frame& output,std::uintptr_t builder,std::uintptr_t arena,std::uintptr_t list,
                         std::uintptr_t commit,std::uintptr_t ui_frame,std::uint64_t ui_time)noexcept{
    output.sidebar_bounds_ready=false;
    try{
        constexpr std::uint64_t left_key=0x7CDBAF8FF444C1B8ULL,right_key=0x9DD5F4A51595D5FEULL,
            stats_key=0x1342A8EA1B9CD903ULL,title_key=0xDFC334B43D1B81A0ULL;
        struct View {std::uintptr_t address{},previous{},next{},arena{},backend{},root{};std::uint32_t generation{};float scale{},x{},y{};};
        auto view=[&](std::uintptr_t address,View& v){std::array<std::uint8_t,0x90> raw{};if(!read.copy(address,raw.data(),raw.size()))return false;
            auto q=[&](unsigned at){std::uintptr_t value{};std::memcpy(&value,raw.data()+at,8);return value;};
            v.address=address;v.previous=q(0);v.next=q(8);v.arena=q(0x10);v.backend=q(0x18);v.root=q(0x50);
            std::memcpy(&v.scale,raw.data()+0x20,4);std::memcpy(&v.x,raw.data()+0x24,4);std::memcpy(&v.y,raw.data()+0x28,4);std::memcpy(&v.generation,raw.data()+0x80,4);
            return v.arena==arena&&v.backend==builder&&std::isfinite(v.scale)&&v.scale>0&&v.scale<=16&&std::isfinite(v.x)&&std::isfinite(v.y);};
        std::uintptr_t first{},again{};if(!read.get(list+8,first))return;
        std::vector<View> views;std::uintptr_t at=first,previous{};
        while(at){if(views.size()>=64||std::any_of(views.begin(),views.end(),[&](auto& v){return v.address==at;}))return;
            View v{};if(!view(at,v)||v.previous!=previous)return;views.push_back(v);previous=at;at=v.next;}
        struct Pending {std::uintptr_t address{};unsigned group{};};
        std::vector<Node> checked;std::array<Rect,32> result{};std::uint32_t count{};std::array<Rect,2> unions{};std::array<bool,2> has_union{};
        unsigned upper_scopes{},lower_scopes{};Rect lower{};
        auto pixel_rect=[&](const Node& n,const View& v,Rect& r){if(n.rect[2]==0||n.rect[3]==0)return false;r=transform(n,v.scale,v.x,v.y);
            if(!finite_rect(r))return false;r={std::max(r.left,output.map_content.left),std::max(r.top,output.map_content.top),std::min(r.right,output.map_content.right),std::min(r.bottom,output.map_content.bottom)};return finite_rect(r);};
        auto append=[&](const Rect& r){if(count>=result.size())return false;result[count++]=r;return true;};
        std::size_t total{};
        for(auto& v:views){if(!v.root)continue;Node root{};if(!read.node(v.root,root)||root.parent||root.frame!=arena||root.viewport!=v.address)return;
            std::vector<Pending> pending{{v.root,0}};std::vector<std::uintptr_t> seen;
            while(!pending.empty()){
                auto item=pending.back();pending.pop_back();if(++total>2048||std::find(seen.begin(),seen.end(),item.address)!=seen.end())return;
                seen.push_back(item.address);Node n{};if(!read.node(item.address,n)||n.frame!=arena||n.viewport!=v.address)return;
                unsigned group=item.group;
                if(n.generation==v.generation){
                    if(n.literal==left_key){group=1;++upper_scopes;checked.push_back(n);}if(n.literal==right_key)group=2;
                    if(group&&n.count==0){Rect rect{};if(pixel_rect(n,v,rect)){auto& u=unions[group-1];if(!has_union[group-1]){u=rect;has_union[group-1]=true;}
                        else u={std::min(u.left,rect.left),std::min(u.top,rect.top),std::max(u.right,rect.right),std::max(u.bottom,rect.bottom)};checked.push_back(n);}}
                    if(n.literal==stats_key){++lower_scopes;Rect rect{};if(pixel_rect(n,v,rect)){if(!append(rect))return;lower=rect;checked.push_back(n);}}
                    if(n.literal==title_key){Node body{};
                        // This specific map-point card's titleGroup is inside
                        // literal1 card body, directly below its viewport root.
                        // The root itself is fullscreen and is never excluded.
                        if(!read.node(n.parent,body)||body.literal!=1||body.parent!=v.root||body.frame!=arena||body.viewport!=v.address||body.generation!=v.generation)return;
                        const auto raw_body=transform(body,v.scale,v.x,v.y),full=transform(root,v.scale,v.x,v.y);
                        if(raw_body.left<=full.left&&raw_body.top<=full.top&&raw_body.right>=full.right&&raw_body.bottom>=full.bottom)return;
                        Rect rect{};if(pixel_rect(body,v,rect)){
                            if(!append(rect))return;checked.push_back(n);checked.push_back(body);}}
                }else if(n.literal==left_key||n.literal==right_key)group=0;
                auto child=n.first;std::uintptr_t last{};
                for(std::uint64_t i=0;i<n.count;++i){Node c{};if(!child||!read.node(child,c)||c.parent!=n.address||c.previous!=last)return;
                    pending.push_back({child,group});last=child;child=c.next;}
                if(child||last!=n.last)return;
            }
        }
        for(unsigned i=0;i<2;++i)if(has_union[i]&&!append(unions[i]))return;
        for(auto& n:checked){Node again_node{};if(!read.node(n.address,again_node)||again_node.rect!=n.rect||again_node.literal!=n.literal||again_node.parent!=n.parent||
            again_node.frame!=n.frame||again_node.viewport!=n.viewport||again_node.generation!=n.generation)return;}
        for(auto& v:views){View after{};if(!view(v.address,after)||after.previous!=v.previous||after.next!=v.next||after.root!=v.root||after.generation!=v.generation||after.scale!=v.scale||after.x!=v.x||after.y!=v.y)return;}
        const auto ui=ui_frame-0x10;std::uint64_t time{};
        if(!read.get(list+8,again)||again!=first||!read.get(builder,again)||again!=arena||!read.get(builder+0x10,again)||again!=list||
           !read.get(ui+0xE90,again)||again!=commit||!read.get(ui+0x68,again)||again!=ui||
           !read.get(output.application_address+0x5B0,again)||again!=ui||!read.get(ui_frame+8,time)||time!=ui_time)return;
        output.ui_blockers=result;output.ui_blocker_count=count;output.ui_blockers_ready=true;
        if(upper_scopes==1&&lower_scopes==1&&has_union[0]&&finite_rect(lower)&&unions[0].bottom<lower.top){
            output.sidebar_upper=unions[0];output.sidebar_lower=lower;output.sidebar_bounds_ready=true;}
    }catch(...){/* Optional UI protection degrades independently of map data. */}
}
