#pragma once
#include "layout_profile.hpp"

namespace rs::game::compat {
template<class T>inline bool operand(const Image& image,std::uint32_t at,T& value)noexcept {
    const auto* bytes=image.bytes(at,sizeof(value));if(!bytes)return false;
    std::memcpy(&value,bytes,sizeof(value));return true;
}
inline bool field_offset(std::uint32_t value,std::uint32_t alignment=1)noexcept {
    return value>=0x20&&value<=0x100000&&!(value&(alignment-1));
}
// The page accessor reads the same published transient frame used by the map
// renderer. Its null-context fallback is the field offset minus the 16-byte
// context header. Decode both and require that relation, rather than inferring
// an unrelated context layout from the number of bytes allocated for MapState.
inline bool resolve_page(const Image& image,std::uint32_t root,std::uint32_t& page)noexcept {
    page=0;std::uint32_t at{},source{},fallback{},decoded{};
    if(!image.find(layout_profile::page,at)||!image.primary_contains(at,layout_profile::page.size)||
       !image.relative(at,3,7,source)||source!=root||!operand(image,at+8,fallback)||!operand(image,at+28,decoded)||
       !field_offset(decoded,8)||fallback>UINT32_MAX-16||fallback+16!=decoded||
       !image.unchanged(at,layout_profile::page))return false;
    page=decoded;return true;
}
inline bool resolve_map_literal(const Image& image,std::uint64_t& literal)noexcept {
    literal=0;std::uint32_t request{},at{};std::uint64_t identity{};
    if(!observer::find_request(image,request,identity)||!image.find(layout_profile::map_literal,at)||
       !image.primary_contains(at,layout_profile::map_literal.size)||image.primary(at).begin!=image.primary(request).begin||
       !operand(image,at+2,literal)||!literal||!image.unchanged(at,layout_profile::map_literal)){literal=0;return false;}
    return true;
}
inline bool resolve_language(const Image& image,NativeLayout& layout)noexcept {
    layout.language_owner=layout.ui_language=layout.language_id=0;
    std::uint32_t at{},ui_setter{},loca_setter{},owner{},ui_field{},ui_write{},loca_field{},loca_write{};
    if(!image.find(layout_profile::language_route,at)||!image.primary_contains(at,layout_profile::language_route.size)||
       !operand(image,at+3,owner)||!field_offset(owner,8)||
       !image.relative(at+14,1,5,loca_setter)||!image.relative(at+28,1,5,ui_setter)||
       image.primary(ui_setter).begin!=ui_setter||image.primary(loca_setter).begin!=loca_setter||
       !image.primary_contains(ui_setter,layout_profile::ui_language_setter.size)||
       !image.primary_contains(loca_setter,layout_profile::language_setter.size)||
       !image.bytes(ui_setter,layout_profile::ui_language_setter.size)||!image.bytes(loca_setter,layout_profile::language_setter.size)||
       !matches(image.bytes(ui_setter,layout_profile::ui_language_setter.size),layout_profile::ui_language_setter)||
       !matches(image.bytes(loca_setter,layout_profile::language_setter.size),layout_profile::language_setter)||
       !operand(image,ui_setter+11,ui_field)||!operand(image,ui_setter+19,ui_write)||ui_field!=ui_write||!field_offset(ui_field,4)||
       !operand(image,loca_setter+11,loca_field)||!operand(image,loca_setter+19,loca_write)||loca_field!=loca_write||!field_offset(loca_field,4)||
       !image.unchanged(at,layout_profile::language_route)||!image.unchanged(ui_setter,layout_profile::ui_language_setter)||
       !image.unchanged(loca_setter,layout_profile::language_setter))return false;
    layout.language_owner=owner;layout.ui_language=ui_field;layout.language_id=loca_field;return true;
}
inline bool resolve_layout(MemoryReader reader,std::uintptr_t base,std::uint32_t root,NativeLayout& output)noexcept {
    output={};output.world_page=0;output.map_literal=0;
    output.language_owner=output.ui_language=output.language_id=0;
    try {Image image;NativeLayout result{};
        if(!image.load(reader,base)||!resolve_page(image,root,result.world_page)||!resolve_map_literal(image,result.map_literal))return false;
        // Localization is independent. Unproven language operands never make
        // the map unavailable, and never fall back to reading a guessed field.
        resolve_language(image,result);output=result;return true;
    }catch(...){return false;}
}
}
