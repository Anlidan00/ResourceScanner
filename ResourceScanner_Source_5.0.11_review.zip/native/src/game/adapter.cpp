#include <rs/game/adapter.hpp>
#include <rs/platform/paths.hpp>
#include <windows.h>
#include <MinHook.h>
#include <array>
#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <mutex>
#include <vector>
#include "observer_binding.hpp"
#include "layout_binding.hpp"
#include "zoom_out.hpp"
#include "tracking_internal.hpp"

namespace rs::game {
namespace {
NativeLayout native_layout{};
constexpr std::uint64_t image_key=0x3F267F93B50D2258ULL;
constexpr std::uint64_t header_key=0xEE08F2156F8EA3E3ULL;
constexpr std::uint64_t hints_key=0x54771979F7129697ULL;
std::uintptr_t root_rva{};std::uint32_t map_state_bytes{};std::uint64_t map_state_key{};
struct Node {
    std::uintptr_t address{},parent{},previous{},next{},first{},last{},frame{},viewport{};
    std::uint64_t count{},literal{};std::uint32_t generation{};std::array<float,4> rect{};
    bool operator==(const Node&)const=default;
};
struct Read {
    MemoryReader reader;std::uint64_t bytes{};
    bool copy(std::uintptr_t p,void* out,std::size_t n) {
        if(!p||p<0x10000||p>0x00007FFFFFFEFFFFULL||n>0x10000||p+n<p||bytes+n>2*1024*1024)return false;
        bytes+=n;return reader.copy&&reader.copy(reader.user,p,out,n);
    }
    template<class T>bool get(std::uintptr_t p,T& v){return copy(p,&v,sizeof(v));}
    bool pointer(std::uintptr_t p,std::uintptr_t& out){return get(p,out)&&out>=0x10000&&out<=0x00007FFFFFFEFFFFULL;}
    bool node(std::uintptr_t address,Node& node){
        std::array<std::uint8_t,0x128> raw{};if(!copy(address,raw.data(),raw.size()))return false;
        auto ptr=[&](std::size_t at){std::uintptr_t value;std::memcpy(&value,raw.data()+at,8);return value;};
        node.address=address;node.parent=ptr(0);node.previous=ptr(8);node.next=ptr(0x10);node.first=ptr(0x18);
        node.last=ptr(0x20);node.count=ptr(0x28);node.literal=ptr(0x38);node.frame=ptr(0x48);node.viewport=ptr(0x50);
        std::memcpy(&node.generation,raw.data()+0x68,4);std::memcpy(node.rect.data(),raw.data()+0x114,16);
        return node.count<=2048;
    }
};
bool finite_rect(const Rect& r){return std::isfinite(r.left)&&std::isfinite(r.top)&&std::isfinite(r.right)&&std::isfinite(r.bottom)
    &&r.right>r.left&&r.bottom>r.top&&std::abs(r.left)<1e7f&&std::abs(r.top)<1e7f&&std::abs(r.right)<1e7f&&std::abs(r.bottom)<1e7f;}
Rect transform(const Node& node,float scale,float x,float y){
    return {node.rect[0]*scale+x,node.rect[1]*scale+y,(node.rect[0]+node.rect[2])*scale+x,(node.rect[1]+node.rect[3])*scale+y};
}
#include "hud_blockers.hpp"
bool own_copy(void*,std::uintptr_t p,void* target,std::uint64_t bytes)noexcept{
    SIZE_T done{};return ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<const void*>(p),target,static_cast<SIZE_T>(bytes),&done)&&done==bytes;
}
bool supported_language(std::uint32_t id){constexpr std::uint32_t ids[]{1,3,5,6,7,9,10,11,13,16,17,18,20,21,34};return std::find(std::begin(ids),std::end(ids),id)!=std::end(ids);}
struct RequestedMap {std::uintptr_t state{},ui_context_frame{},backend{};};
std::mutex cache_mutex,request_mutex;Frame cached{};RequestedMap requested{};std::uintptr_t game_base{};
std::uint32_t last_language=1;
using AllocateState=std::uintptr_t(__fastcall*)(std::uintptr_t,std::uint64_t,std::uint64_t,std::uintptr_t,std::uint32_t);
using CommitLayout=std::uint32_t(__fastcall*)(std::uintptr_t,std::uintptr_t);
AllocateState allocate_state{};CommitLayout commit_layout{};std::array<void*,2> hook_targets{};std::atomic_bool active{};bool hooks_created{};
std::uintptr_t __fastcall observe_state(std::uintptr_t element,std::uint64_t key,std::uint64_t size,std::uintptr_t type,std::uint32_t flags){
    auto result=allocate_state(element,key,size,type,flags);
    if(active.load(std::memory_order_acquire)&&key==map_state_key&&size==map_state_bytes){
        world_zoom::note_requested_state(result);
        Read read{{nullptr,own_copy}};RequestedMap next{};std::uintptr_t root{},root2{},ui_frame{},backend{},canvas{},viewport{},viewport_backend{};
        if(result&&read.pointer(game_base+root_rva,root)&&read.pointer(root+0x10,ui_frame)&&read.pointer(root+0x18,backend)&&
           read.pointer(element+0x48,canvas)&&read.pointer(element+0x50,viewport)&&read.pointer(viewport+0x18,viewport_backend)&&viewport_backend==backend&&
           read.get(game_base+root_rva,root2)&&root2==root)next={result,ui_frame,backend};
        {std::lock_guard lock(request_mutex);if(!active.load())return result;requested=next;}
        tracking_detail::observe_request(next.state,next.ui_context_frame,next.backend);
    }
    return result;
}
std::uint32_t __fastcall observe_commit(std::uintptr_t root,std::uintptr_t builder){
    auto result=commit_layout(root,builder);
    if(!active.load(std::memory_order_acquire))return result;
    RequestedMap request;{std::lock_guard lock(request_mutex);request=requested;}
    auto frame=capture_from_commit({nullptr,own_copy},root,builder,
        request.backend==builder?request.state:0,request.backend==builder?request.ui_context_frame:0,GetTickCount64(),map_state_bytes,map_state_key,native_layout);
    tracking_detail::observe_frame(frame);
    std::lock_guard lock(cache_mutex);
    if(!active.load())return result;
    if(frame.native_language_id)last_language=supported_language(frame.native_language_id)?frame.native_language_id:1;
    frame.native_language_id=last_language;cached=frame;return result;
}
}

Frame capture_from_commit(const MemoryReader& reader,std::uintptr_t commit_root,std::uintptr_t builder,std::uintptr_t state,std::uintptr_t ui_context_frame,std::uint64_t now,std::uint32_t expected_state_bytes,std::uint64_t expected_state_key,const NativeLayout& layout)noexcept {
    Frame output{};output.sampled_at_ms=now;output.native_language_id=0;
    try {
        if(!expected_state_key||expected_state_bytes<0x60||expected_state_bytes>0x10000||(expected_state_bytes&7)||
           !compat::field_offset(layout.world_page,8)||!layout.map_literal)return output;
        Read read{reader};std::uintptr_t frame{},viewport_list{},ui{},app_owner{},app{},view{},state_owner{},ctx{},game_ui{};
        std::uint64_t initial_identity{};std::uint32_t initial_size{};
        if(state<0x10028||!read.get(state-0x28,initial_identity)||initial_identity!=expected_state_key||
           !read.get(state-0x18,initial_size)||initial_size!=expected_state_bytes)return output;

        // Backend[0] owns UiElement arena records. Backend[10] is a separate
        // viewport-list record (119040C..419), not the arena owner itself.
        if(!commit_root||!builder||ui_context_frame<0x10010||!read.pointer(builder,frame)||!read.pointer(builder+0x10,viewport_list))return output;
        ui=ui_context_frame-0x10;std::uintptr_t self{},back{};
        if(!read.pointer(ui+0x68,self)||self!=ui||!read.pointer(ui,app_owner)||app_owner<0x468)return output;
        app=app_owner-0x468;if(!read.pointer(app+0x5B0,back)||back!=ui||!read.pointer(ui+0xE90,back)||back!=commit_root)return output;
        output.application_address=app;output.ui_address=ui;
        std::uint32_t language{},language2{};std::uintptr_t loca{};
        std::uint32_t again1{},again2{};std::uintptr_t self2{},back2{},loca2{};
        if(layout.language_owner&&layout.ui_language&&layout.language_id&&read.get(ui+layout.ui_language,language)&&language>0&&read.pointer(app+layout.language_owner,loca)&&read.get(loca+layout.language_id,language2)&&language==language2&&
           read.get(ui+layout.ui_language,again1)&&again1==language&&read.get(loca+layout.language_id,again2)&&again2==language&&
           read.get(ui+0x68,self2)&&self2==ui&&read.get(app+0x5B0,back2)&&back2==ui&&read.get(app+layout.language_owner,loca2)&&loca2==loca)
            output.native_language_id=supported_language(language)?language:1;
        // BC1E87 writes the frame data view at RBP+30==transientRoot+D0.
        // Derive it from the live frame rather than retaining that stack root.
        if(!read.pointer(ui_context_frame+0x48,view)||!read.pointer(view,state_owner)||!read.pointer(state_owner+0x38,game_ui))return output;
        ctx=view;
        std::uint8_t play{},screen{},page{};
        if(!read.get(state_owner+0xC,play)||!read.get(game_ui+0x1CD8,screen)||!read.get(ctx+layout.world_page,page))return output;
        output.source=Availability::compatible;
        if(play!=7||screen!=5||page!=1)return output;
        output.map_open=true;
        std::uintptr_t element{},viewport{},first_viewport{};std::uint64_t stamp{},current_stamp{},state_time{},ui_time{},state_key{};std::uint32_t state_size{};
        if(expected_state_bytes<0x40||expected_state_bytes>0x10000||!state||!read.pointer(state+0x18,element)||!read.pointer(viewport_list+8,first_viewport)||
           !read.get(state-0x28,state_key)||state_key!=expected_state_key||!read.get(state-0x18,state_size)||state_size!=expected_state_bytes||
           !read.get(state,state_time)||!read.get(ui_context_frame+8,ui_time)||
           !read.get(viewport_list,current_stamp)||!read.get(state-0x38,stamp)||stamp!=current_stamp)return output;
        // C1EA57..62 skips C1EB70 after MapState initialization. Its body[0]
        // timestamp is intentionally old on a stationary map; it is NOT the
        // current UI frame clock. Current ownership/generation below determines
        // availability, while both timestamps are only reread for coherence.
        Node map{};if(!read.node(element,map)||map.literal!=layout.map_literal||map.frame!=frame)return output;
        viewport=map.viewport;std::uintptr_t viewport_frame{},viewport_root{};
        std::uint32_t generation{};float scale{},origin_x{},origin_y{};std::uintptr_t viewport_builder{};
        if(!read.pointer(viewport+0x10,viewport_frame)||viewport_frame!=frame||!read.pointer(viewport+0x50,viewport_root)||
           !read.pointer(viewport+0x18,viewport_builder)||viewport_builder!=builder||
           !read.get(viewport+0x80,generation)||map.generation!=generation||!read.get(viewport+0x20,scale)||
           !read.get(viewport+0x24,origin_x)||!read.get(viewport+0x28,origin_y)||!std::isfinite(scale)||scale<=0||scale>16)return output;
        bool member=false;auto current_viewport=first_viewport;
        for(unsigned i=0;i<64&&current_viewport;++i){if(current_viewport==viewport){member=true;break;}
            std::uintptr_t next{};if(!read.get(current_viewport+8,next)||next==current_viewport)return output;current_viewport=next;}
        if(!member)return output;
        std::uintptr_t ancestor=element;bool reached=false;
        for(unsigned i=0;i<32;++i){if(ancestor==viewport_root){reached=true;break;}Node n{};
            if(!read.node(ancestor,n)||n.viewport!=viewport||n.frame!=frame||!n.parent)return output;
            Node parent{};if(!read.node(n.parent,parent))return output;
            if(!n.previous){if(parent.first!=ancestor)return output;}else{std::uintptr_t next{};if(!read.get(n.previous+0x10,next)||next!=ancestor)return output;}
            ancestor=n.parent;}
        if(!reached)return output;
        Node root_node{};if(!read.node(viewport_root,root_node))return output;
        Rect full=transform(root_node,scale,origin_x,origin_y);if(!finite_rect(full))return output;
        Node image{},header{},hints{},footer{};bool found_image=false,found_header=false,found_hints=false;
        std::vector<std::uintptr_t> pending{viewport_root},seen;seen.reserve(512);
        while(!pending.empty()){
            auto p=pending.back();pending.pop_back();if(seen.size()>=2048||std::find(seen.begin(),seen.end(),p)!=seen.end())return output;
            seen.push_back(p);Node n{};if(!read.node(p,n)||n.viewport!=viewport||n.frame!=frame)return output;
            if(n.generation==generation){
                if(n.literal==image_key){if(found_image)return output;image=n;found_image=true;}
                if(n.literal==header_key){if(found_header)return output;header=n;found_header=true;}
                if(n.literal==hints_key){if(found_hints)return output;hints=n;found_hints=true;}
            }
            auto child=n.first;std::uintptr_t previous{};
            for(std::uint64_t i=0;i<n.count;++i){Node c{};if(!child||!read.node(child,c)||c.parent!=p||c.previous!=previous)return output;
                pending.push_back(child);previous=child;child=c.next;}
            if(child||previous!=n.last)return output;
        }
        if(!found_image||!found_header||!found_hints||!read.node(hints.parent,footer)||footer.frame!=frame||footer.viewport!=viewport||footer.generation!=generation)return output;
        auto image_bounds=transform(image,scale,origin_x,origin_y);auto h=transform(header,scale,origin_x,origin_y);auto f=transform(footer,scale,origin_x,origin_y);
        if(!finite_rect(image_bounds)||!finite_rect(h)||!finite_rect(f))return output;
        if(h.left>full.left+1||h.right<full.right-1||f.left>full.left+1||f.right<full.right-1)return output;
        Rect content{full.left,std::max(full.top,h.bottom),full.right,std::min(full.bottom,f.top)};
        if(!finite_rect(content))return output;
        float world_width{},world_height{};if(!read.get(state+0x38,world_width)||!read.get(state+0x3C,world_height)||
            !std::isfinite(world_width)||!std::isfinite(world_height)||world_width<=0||world_height<=0||world_width>1e6f||world_height>1e6f)return output;
        const float sx=(image_bounds.right-image_bounds.left)/world_width,sy=(image_bounds.bottom-image_bounds.top)/world_height;
        if(!std::isfinite(sx)||!std::isfinite(sy)||sx<=0||sy<=0||sx>1e5f||sy>1e5f||std::abs(sx-sy)>std::max(sx,sy)*0.001f)return output;
        std::uintptr_t commit_root2{},frame2{},list2{},ui2{},state_root2{},view2{},state_owner2{},game_ui2{},builder2{};std::uint64_t stamp2{},state_time2{},ui_time2{},state_key2{};std::uint32_t gen2{},state_size2{};
        std::uint8_t play2{},screen2{},page2{};Node image2{},header2{},footer2{},map2{},root_node2{};
        float world_width2{},world_height2{};std::uint64_t state_stamp2{};
        float scale2{},origin_x2{},origin_y2{};std::uintptr_t viewport_root2{},viewport_frame2{};
        if(!read.get(ui+0xE90,commit_root2)||commit_root2!=commit_root||!read.get(builder,frame2)||frame2!=frame||!read.get(builder+0x10,list2)||list2!=viewport_list||!read.get(app+0x5B0,ui2)||ui2!=ui||
           !read.get(ui_context_frame+0x48,view2)||view2!=view||!read.get(view,state_owner2)||state_owner2!=state_owner||!read.get(state_owner+0x38,game_ui2)||game_ui2!=game_ui||
           !read.get(state,state_time2)||state_time2!=state_time||!read.get(ui_context_frame+8,ui_time2)||ui_time2!=ui_time||
           !read.get(state+0x18,state_root2)||state_root2!=element||!read.get(viewport_list,stamp2)||stamp2!=current_stamp||
           !read.get(state-0x38,state_stamp2)||state_stamp2!=stamp||
           !read.get(state+0x38,world_width2)||world_width2!=world_width||!read.get(state+0x3C,world_height2)||world_height2!=world_height||
           !read.get(state-0x28,state_key2)||state_key2!=state_key||!read.get(state-0x18,state_size2)||state_size2!=state_size||
           !read.get(viewport+0x80,gen2)||gen2!=generation||!read.get(state_owner+0xC,play2)||play2!=play||
           !read.get(game_ui+0x1CD8,screen2)||screen2!=screen||!read.get(ctx+layout.world_page,page2)||page2!=page||
           !read.node(map.address,map2)||map2!=map||!read.node(root_node.address,root_node2)||root_node2!=root_node||
           !read.node(image.address,image2)||image2!=image||!read.node(header.address,header2)||header2!=header||
           !read.node(footer.address,footer2)||footer2!=footer||
           !read.get(viewport+0x20,scale2)||scale2!=scale||!read.get(viewport+0x24,origin_x2)||origin_x2!=origin_x||
           !read.get(viewport+0x28,origin_y2)||origin_y2!=origin_y||!read.get(viewport+0x50,viewport_root2)||viewport_root2!=viewport_root||
           !read.get(viewport+0x10,viewport_frame2)||viewport_frame2!=frame||!read.get(viewport+0x18,builder2)||builder2!=builder){output.source=Availability::changing_context;return output;}
        output.map_state_address=state;output.projection.world_center={world_width*.5f,world_height*.5f};
        output.projection.screen_center={(image_bounds.left+image_bounds.right)*.5f,(image_bounds.top+image_bounds.bottom)*.5f};
        output.projection.pixels_per_world_unit=sx;output.projection.screen_bounds=full;output.map_content=content;
        output.projection_ready=true;output.hud_bounds_ready=true;output.world_ready=true;
        collect_ui_blockers(read,output,builder,frame,viewport_list,commit_root,ui_context_frame,ui_time);return output;
    }catch(...){return output;}
}

bool start_adapter()noexcept {
    if(active)return true;game_base=reinterpret_cast<std::uintptr_t>(GetModuleHandleW(nullptr));if(!game_base)return false;
    if(hooks_created){
        compat::ObserverBinding binding{};NativeLayout layout{};
        // Stop restores the entry bytes. Never enable a retained trampoline
        // against changed code, moved targets, or a different layout binding.
        if(!compat::resolve_observers({nullptr,own_copy},game_base,binding)||
           !compat::resolve_layout({nullptr,own_copy},game_base,binding.root,layout)||layout!=native_layout||
           reinterpret_cast<std::uintptr_t>(hook_targets[0])!=game_base+binding.allocate||
           reinterpret_cast<std::uintptr_t>(hook_targets[1])!=game_base+binding.commit||
           root_rva!=binding.root||map_state_bytes!=binding.state_bytes||map_state_key!=binding.state_key){
            platform::log("game-adapter","Retained map observer binding changed; restart unavailable");return false;}
        for(auto p:hook_targets)if(MH_EnableHook(p)!=MH_OK){for(auto target:hook_targets)MH_DisableHook(target);return false;}
        active=true;if(!world_zoom::start(game_base))platform::log("game-zoom","Source profile unavailable; native map zoom retained");
        if(!tracking_detail::start(game_base))platform::log("tracking","Optional source profile unavailable; native map RMB retained");return true;
    }
    compat::ObserverBinding binding{};NativeLayout layout{};
    if(!compat::resolve_observers({nullptr,own_copy},game_base,binding)||
       !compat::resolve_layout({nullptr,own_copy},game_base,binding.root,layout)){platform::log("game-adapter","Map layout unavailable");return false;}
    root_rva=binding.root;map_state_bytes=binding.state_bytes;map_state_key=binding.state_key;native_layout=layout;
    auto init=MH_Initialize();if(init!=MH_OK&&init!=MH_ERROR_ALREADY_INITIALIZED)return false;
    hook_targets={reinterpret_cast<void*>(game_base+binding.allocate),reinterpret_cast<void*>(game_base+binding.commit)};
    if(MH_CreateHook(hook_targets[0],reinterpret_cast<void*>(observe_state),reinterpret_cast<void**>(&allocate_state))!=MH_OK)return false;
    if(MH_CreateHook(hook_targets[1],reinterpret_cast<void*>(observe_commit),reinterpret_cast<void**>(&commit_layout))!=MH_OK){MH_RemoveHook(hook_targets[0]);return false;}
    hooks_created=true;
    if(MH_EnableHook(hook_targets[0])!=MH_OK||MH_EnableHook(hook_targets[1])!=MH_OK){for(auto p:hook_targets)MH_DisableHook(p);return false;}
    active=true;platform::log("game-adapter","Independent source observers installed");
    if(!world_zoom::start(game_base))platform::log("game-zoom","Source profile unavailable; native map zoom retained");
    if(!tracking_detail::start(game_base))platform::log("tracking","Optional source profile unavailable; native map RMB retained");return true;
}
void stop_adapter()noexcept{const bool was_active=active.exchange(false,std::memory_order_acq_rel);tracking_detail::stop();world_zoom::stop();if(was_active){for(auto p:hook_targets)MH_DisableHook(p);}{std::lock_guard lock(cache_mutex);cached={};}{std::lock_guard lock(request_mutex);requested={};}}
Frame sample(void*,std::uint64_t now)noexcept {
    std::lock_guard lock(cache_mutex);auto output=cached;
    if(now<output.sampled_at_ms||now-output.sampled_at_ms>250){output.map_open=false;output.projection_ready=false;output.hud_bounds_ready=false;output.world_ready=false;output.source=Availability::unavailable;output.ui_blocker_count=0;output.ui_blockers_ready=false;}
    return output;
}
}

