#pragma once
#include "tracking_logic.hpp"
namespace rs::game::tracking_detail {
struct SourceRequest {std::uintptr_t state{},ui_frame{},backend{};std::uint64_t epoch{};};
bool capture_context(const MemoryReader&,std::uintptr_t game_base,const SourceRequest&,
                     std::uintptr_t application,std::uintptr_t input_view,bool published,
                     Context&) noexcept;
void observe_request(std::uintptr_t state,std::uintptr_t ui_frame,std::uintptr_t backend) noexcept;
void observe_frame(Frame&) noexcept;
bool start(std::uintptr_t executable_base) noexcept;
void stop() noexcept;
}
