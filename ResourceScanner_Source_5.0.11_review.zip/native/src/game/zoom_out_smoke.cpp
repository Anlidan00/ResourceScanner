#include "zoom_out.hpp"
#include <windows.h>
#include <cstdio>
#include <limits>
#include <filesystem>

namespace {
using namespace rs::game::world_zoom;
struct Fixture {
    alignas(16) std::array<std::uint8_t,0x300> bytes{};
    unsigned writes{},reads{},inside{},mode{};
    bool refuse{},mutate{};
    std::uintptr_t state() noexcept {return reinterpret_cast<std::uintptr_t>(bytes.data()+0x60);}
    template<class T> void put(std::size_t off,T value){std::memcpy(bytes.data()+0x60+off,&value,sizeof(value));}
    template<class T> T get(std::size_t off){T out{};std::memcpy(&out,bytes.data()+0x60+off,sizeof(out));return out;}
    static bool read(void* user,std::uintptr_t address,void* out,std::size_t count) noexcept {
        auto& f=*static_cast<Fixture*>(user);++f.reads;auto first=reinterpret_cast<std::uintptr_t>(f.bytes.data());
        if(address<first||address+count>first+f.bytes.size())return false;
        std::memcpy(out,reinterpret_cast<void*>(address),count);return true;
    }
    static bool exchange(void* user,std::uintptr_t address,std::uint64_t before,std::uint64_t after) noexcept {
        auto& f=*static_cast<Fixture*>(user);if(f.refuse)return false;
        if(address!=f.state()+0x50)return false;
        std::uint64_t current{};std::memcpy(&current,reinterpret_cast<void*>(address),8);
        if(current!=before)return false;
        std::memcpy(reinterpret_cast<void*>(address),&after,8);++f.writes;return true;
    }
    Memory memory() noexcept {return {this,read,exchange};}
    void init(){bytes.fill(0);auto s=state();std::memcpy(reinterpret_cast<void*>(s-0x28),&state_key,8);
        std::uint32_t size=0x260;std::memcpy(reinterpret_cast<void*>(s-0x18),&size,4);
        put(0x38,10240.f);put(0x3C,10240.f);for(unsigned i=0;i<4;++i)put(0x40+4*i,float(16>>i));
        put(0x50,std::uint32_t{0x7FC00001});put(0x54,std::uint32_t{0xABCDEF04});}
};
std::uint8_t inner(std::uintptr_t arg){auto& f=*reinterpret_cast<Fixture*>(arg);note_state(f.state());
    if(f.get<std::uint8_t>(0x54)==5&&f.get<float>(0x50)==f.get<float>(0x4C)*.5f)++f.inside;return 0xA7;}
std::uint8_t render(std::uintptr_t arg){auto& f=*reinterpret_cast<Fixture*>(arg);
    if(f.mode==5||f.mode==6)note_requested_state(f.state());else note_state(f.state());
    if(f.mode==6){if(f.get<std::uint8_t>(0x54)!=4)throw 9;note_state(f.state());} // after native initializer
    if(f.get<std::uint8_t>(0x54)==5&&f.get<float>(0x50)==f.get<float>(0x4C)*.5f)++f.inside;
    if(f.mode==1)throw 7;
    if(f.mode==2)RaiseException(0xE0421212,0,0,nullptr);
    if(f.mode==3){if(call(f.memory(),inner,arg)!=0xA7)throw 8;}
    if(f.mode==4)f.put(0x50,std::uint64_t{0x0000000500000042});
    return 0xD3;
}
bool structured(Fixture* f){
    __try {call(f->memory(),render,reinterpret_cast<std::uintptr_t>(f));}
    __except(GetExceptionCode()==0xE0421212?EXCEPTION_EXECUTE_HANDLER:EXCEPTION_CONTINUE_SEARCH){return true;}
    return false;
}
}
int main(){
    Fixture f;unsigned checks{};
    auto reset=[&](){f=Fixture{};f.init();};reset();auto original=f.bytes;
    note_state(f.state());if(f.bytes!=original)return 1;++checks; // no WORLD scope
    if(call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f))!=0xD3||f.inside!=1||f.writes!=2||f.bytes!=original)return 2;++checks;
    reset();f.mode=1;try{call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));return 3;}catch(int value){if(value!=7||f.bytes!=original||f.writes!=2)return 4;}++checks;
    reset();f.mode=2;if(!structured(&f)||f.bytes!=original||f.writes!=2)return 5;++checks;
    reset();f.mode=3;if(call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f))!=0xD3||f.inside!=2||f.writes!=2||f.bytes!=original)return 6;++checks;
    reset();f.mode=5;call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));if(f.inside!=1||f.bytes!=original||f.writes!=2)return 33;++checks;
    reset();f.mode=5;f.bytes[0x50]=1;auto initializing=f.bytes;call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));
    if(f.inside||f.writes||f.bytes!=initializing)return 34;++checks;
    reset();f.mode=6;f.bytes[0x50]=1;initializing=f.bytes;call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));
    if(f.inside!=1||f.writes!=2||f.bytes!=initializing)return 35;++checks;
    reset();f.mode=4;call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));if(f.writes!=1||f.get<std::uint64_t>(0x50)!=0x0000000500000042)return 7;++checks;
    for(unsigned bad=0;bad<12;++bad){reset();switch(bad){
        case 0:f.put(0x54,std::uint8_t{0});break;case 1:f.put(0x54,std::uint8_t{5});break;
        case 2:f.put(0x44,32.f);break;case 3:f.put(0x4C,0.f);break;
        case 4:f.put(0x40,std::numeric_limits<float>::quiet_NaN());break;case 5:f.put(0x3C,0.f);break;
        case 6:f.put(0x38,std::numeric_limits<float>::infinity());break;case 7:f.put(0x40,2048.f);break;
        case 8:{std::uint64_t v=0;std::memcpy(reinterpret_cast<void*>(f.state()-0x28),&v,8);break;}
        case 9:{std::uint32_t v=0x261;std::memcpy(reinterpret_cast<void*>(f.state()-0x18),&v,4);break;}
        case 10:f.refuse=true;break;case 11:f.put(0x48,-1.f);break;}
        const auto before=f.bytes;call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));
        if(f.writes||f.bytes!=before)return 10+bad;++checks;}
    reset();Scope scope{};scope.memory=f.memory();if(!extend(scope,f.state()))return 30;
    f.put(0x40,15.f);if(restore(scope)||f.writes!=1)return 31;++checks; // never overwrite a later config edit
    reset();scope={};scope.memory=f.memory();if(extend(scope,f.state()+1)||f.writes)return 32;++checks;
    for(float last:{.25f,.5f,1.f,2.f,4.f,8.f,64.f}){reset();for(unsigned i=0;i<4;++i)f.put(0x40+4*i,last*float(1<<(3-i)));
        const auto before=f.bytes;call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));
        if(f.inside!=1||f.writes!=2||f.bytes!=before)return 36;++checks;}
    reset();f.put(0x4C,std::numeric_limits<float>::denorm_min());auto tiny=f.bytes;
    call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));if(f.writes||f.bytes!=tiny)return 37;++checks;
    reset();bound_state_key=0x2372EA49B9C1EF1EULL;bound_state_bytes=0x270;
    std::memcpy(reinterpret_cast<void*>(f.state()-0x28),&bound_state_key,8);std::memcpy(reinterpret_cast<void*>(f.state()-0x18),&bound_state_bytes,4);
    const auto current_before=f.bytes;call(f.memory(),render,reinterpret_cast<std::uintptr_t>(&f));
    if(f.inside!=1||f.writes!=2||f.bytes!=current_before)return 43;++checks;
    bound_state_key=state_key;bound_state_bytes=0x260;
    const auto ini=std::filesystem::current_path()/L"zoom-policy-fixture.ini";DeleteFileW(ini.c_str());
    if(!settings_enabled(ini.c_str())||!settings_enabled(nullptr))return 38;++checks;
    if(!start(0,false)||start(0,true))return 39;++checks; // disabled skips even source/target access
    if(!WritePrivateProfileStringW(L"Scanner",L"Other",L"0",ini.c_str())||!settings_enabled(ini.c_str()))return 40;++checks;
    if(!WritePrivateProfileStringW(L"Scanner",L"ExtraZoomOut",L"0",ini.c_str())||settings_enabled(ini.c_str())||!start(0,settings_enabled(ini.c_str())))return 41;++checks;
    if(!WritePrivateProfileStringW(L"Scanner",L"ExtraZoomOut",L"1",ini.c_str())||!settings_enabled(ini.c_str()))return 42;++checks;
    WritePrivateProfileStringW(nullptr,nullptr,nullptr,ini.c_str());DeleteFileW(ini.c_str());
    std::printf("PASS scoped WORLD zoom %u cases; dynamic2x; normal/C++/SEH/nested restoration; settings ON/OFF/missing; exact tail padding; invalid states unchanged\n",checks);return 0;
}
