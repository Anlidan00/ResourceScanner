#include <rs/game/state.hpp>
#include <rs/platform/paths.hpp>
#include <windows.h>
#include <cstring>
#include <string>
#include <cstdio>
namespace {template<class T>void put(std::uint8_t* p,std::size_t n,T v){std::memcpy(p+n,&v,sizeof(v));}}
int main(){
    rs::game::Frame frame{};frame.source=rs::game::Availability::compatible;frame.map_open=frame.projection_ready=frame.world_ready=true;
    frame.application_address=0x100000;frame.ui_address=0x200000;frame.map_state_address=0x300000;
    frame.process_id=GetCurrentProcessId();FILETIME c{},e{},k{},u{};if(!GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u))return 1;
    frame.process_creation_time=std::uint64_t(c.dwLowDateTime)|(std::uint64_t(c.dwHighDateTime)<<32);frame.sequence=10;frame.scope_start_sequence=7;
    const auto name=L"Local\\ResourceScanner.State.v1."+std::to_wstring(frame.process_id);
    auto mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,205152,name.c_str());if(!mapping||GetLastError()==ERROR_ALREADY_EXISTS)return 2;
    auto* bytes=static_cast<std::uint8_t*>(MapViewOfFile(mapping,FILE_MAP_WRITE,0,0,205152));if(!bytes)return 3;
    std::memset(bytes,0,205152);std::memcpy(bytes,"RSSTATE1",8);
    put(bytes,8,1u);put(bytes,12,256u);put(bytes,16,205152u);put(bytes,20,2u);put(bytes,24,std::uint64_t{2});
    put(bytes,32,frame.process_id);put(bytes,40,frame.process_creation_time);put(bytes,48,rs::platform::instance_nonce());
    const auto now=GetTickCount64();frame.sampled_at_ms=now;put(bytes,56,now);put(bytes,64,std::uint64_t{1});put(bytes,136,1280u);put(bytes,140,1280u);
    put(bytes,144,204800u);put(bytes,148,88u);put(bytes,152,std::uint64_t{8});put(bytes,160,now);
    put(bytes,168,frame.application_address);put(bytes,176,frame.ui_address);put(bytes,184,frame.map_state_address);bytes[205056]=1;
    std::array<std::uint8_t,32> digest{};rs::game::StateSnapshot out{};unsigned checks{};
    if(!rs::game::read_state(frame,digest,now,out)||!out.known(0)||out.fow_ready)return 4;++checks;
    put(bytes,24,std::uint64_t{3});if(rs::game::read_state(frame,digest,now,out)||out.knowledge_ready)return 5;++checks;
    put(bytes,24,std::uint64_t{4});put(bytes,160,now-1001);if(rs::game::read_state(frame,digest,now,out))return 6;++checks;
    put(bytes,160,now);frame.scope_start_sequence=9;if(rs::game::read_state(frame,digest,now,out))return 7;++checks;
    put(bytes,152,std::uint64_t{9});if(!rs::game::read_state(frame,digest,now,out))return 8;++checks;
    put(bytes,168,std::uint64_t{0x500000});if(rs::game::read_state(frame,digest,now,out))return 9;++checks;
    UnmapViewOfFile(bytes);CloseHandle(mapping);std::printf("PASS %u actual OWN mapping readonly-consumer/scope/TTL/seqlock checks\n",checks);return 0;
}
