#pragma once
#include "native_profile.hpp"
#include "layout_binding.hpp"
namespace rs::game::compat {
struct ZoomBinding {std::uint32_t render{},initialize{},caller{},state_bytes{};std::uint64_t state_key{};bool operator==(const ZoomBinding&)const=default;};
struct TrackingBinding {std::uint32_t query{},commands{},dispatch{},caller{},root{},vtable{},state_bytes{};std::uint64_t state_key{};std::uint32_t world_page{},controller{},other{};std::uint64_t map_literal{};bool operator==(const TrackingBinding&)const=default;};
inline bool request_identity(const Image& image,std::uint32_t& request,std::uint64_t& key,std::uint32_t& size)noexcept {
    if(!observer::find_request(image,request,key)||!image.primary_contains(request,44))return false;
    auto p=image.bytes(request+16,4);if(!p)return false;std::memcpy(&size,p,4);
    return (size>=0x60&&size<=0x10000&&!(size&7))&&image.unchanged(request,44);
}
inline bool published_root(const Image& image,std::uint32_t& root)noexcept {
    std::uint32_t store{};return image.find(observer::root_store,store)&&image.primary_contains(store,observer::root_store.size)&&
        image.relative(store,17,21,root)&&!(root&7)&&image.contains(root,8,IMAGE_SCN_MEM_READ|IMAGE_SCN_MEM_WRITE,false)&&image.unchanged(store,observer::root_store);
}
inline bool resolve_zoom_profile(const Image& image,ZoomBinding& b,const Pattern* patterns,std::uint32_t root)noexcept {
    std::uint32_t request{},render_root{},target{};
    if(!request_identity(image,request,b.state_key,b.state_bytes))return false;
    std::array<std::uint32_t,9> at{};
    // Config-source table offsets and the error-reporting branch body are
    // unrelated to our temporary state-table edit. Only the constructor,
    // table consumers, clamp math and the calls connecting them are required.
    constexpr unsigned required[]{0,1,2,3,4,5,6,7,8};
    for(auto i:required)if(!image.find(patterns[i],at[i])||!image.primary_contains(at[i],patterns[i].size))return false;
    auto same=[&](unsigned a,unsigned c){return image.primary(at[a]).end&&image.primary(at[a]).begin==image.primary(at[c]).begin;};
    b.render=at[0];b.initialize=at[4];b.caller=at[1]+24;
    if(image.primary(b.render).begin!=b.render||image.primary(b.initialize).begin!=b.initialize||image.primary(request).begin!=b.render||
       !same(0,1)||!same(0,2)||!same(4,5)||!same(6,7)||
       !image.relative(at[0],19,23,render_root)||render_root!=root||
       !image.relative(at[1]+19,1,5,target)||target!=b.initialize||
       !image.relative(at[2]+19,1,5,target)||image.primary(at[3]).begin!=target||
       !image.relative(at[2]+27,1,5,target)||image.primary(at[6]).begin!=target||
       !image.relative(at[3]+37,1,5,target)||image.primary(at[8]).begin!=target)return false;
    std::uint32_t flag{};constexpr std::uint8_t flag_bytes[]={0x0f,0xb6,0x41,0xf0,0xc3};
    if(!image.relative(request+39,1,5,flag)||!image.contains(flag,5,IMAGE_SCN_MEM_EXECUTE,true)||!image.bytes(flag,5)||
        std::memcmp(image.bytes(flag,5),flag_bytes,5)||!image.unchanged(flag,5))return false;
    for(auto i:required)if(!image.unchanged(at[i],patterns[i]))return false;
    return true;
}
inline bool resolve_zoom(MemoryReader read,std::uintptr_t base,ZoomBinding& out)noexcept {
    out={};try {Image image;if(!image.load(read,base))return false;std::uint32_t root{};
        if(!published_root(image,root))return false;
        ZoomBinding selected{};unsigned count{};
        for(bool current:{false,true}){ZoomBinding candidate{};
            if(resolve_zoom_profile(image,candidate,current?native_profile::zoom_current:native_profile::zoom_old,root)&&
               candidate.state_bytes>=(current?0x270u:0x260u)){selected=candidate;++count;}}
        if(count!=1)return false;out=selected;return true;
    }catch(...){return false;}
}
inline bool resolve_tracking(MemoryReader read,std::uintptr_t base,TrackingBinding& out)noexcept {
    out={};try {Image image;if(!image.load(read,base))return false;TrackingBinding b{};std::uint32_t request{},target{};
        if(!request_identity(image,request,b.state_key,b.state_bytes)||!published_root(image,b.root))return false;
        if(!resolve_page(image,b.root,b.world_page)||!resolve_map_literal(image,b.map_literal))return false;
        const auto* patterns=native_profile::tracking_old;
        std::array<std::uint32_t,12> at{};for(unsigned i=0;i<at.size();++i)
            if(i!=3&&(!image.find(patterns[i],at[i])||!image.primary_contains(at[i],patterns[i].size)))return false;
        at[3]=image.primary(at[4]).begin;
        if(!at[3]||!image.primary_contains(at[3],20)||!image.bytes(at[3],20)||std::memcmp(image.bytes(at[3],20),patterns[3].bytes,20))return false;
        auto same=[&](unsigned a,unsigned c){return image.primary(at[a]).end&&image.primary(at[a]).begin==image.primary(at[c]).begin;};
        b.query=at[0];b.commands=at[3];b.dispatch=at[5];b.caller=at[1]+54;
        if(image.primary(b.query).begin!=b.query||image.primary(b.commands).begin!=b.commands||image.primary(b.dispatch).begin!=b.dispatch||
           image.primary(at[7]).begin!=at[7]||!same(3,4)||!same(5,6)||!same(7,8)||
           !image.relative(at[1]+16,1,5,target)||target!=b.query||!image.relative(at[1]+49,1,5,target)||target!=b.query||
           !image.relative(at[4]+50,1,5,target)||target!=b.dispatch||!image.relative(at[6]+12,1,5,target)||target!=at[7]||
           !image.relative(at[11],3,7,b.vtable)||!image.contains(b.vtable,8,IMAGE_SCN_MEM_READ,false))return false;
        // The command route and controller constructor must independently name
        // the same app member; its read and write operands must also agree.
        std::uint32_t controller_again{},controller_read{};
        if(!operand(image,at[4]+3,b.other)||!operand(image,at[4]+38,b.controller)||
           !operand(image,at[11]+67,controller_again)||!operand(image,at[11]+78,controller_read)||
           !field_offset(b.other,8)||!field_offset(b.controller,8)||b.other==b.controller||
           b.controller!=controller_again||b.controller!=controller_read)return false;
        // The native packet kind is translated through two embedded tables.
        // Derive both addresses from the validated dispatch instructions.
        std::uint32_t image_zero{},selectors{},jumps{},case_target{},default_target{};std::uint8_t selector{};
        if(!image.relative(at[7]+36,2,6,default_target)||image.primary(default_target).begin!=at[7]||
           !image.relative(at[7]+46,3,7,image_zero)||image_zero||!image.live(at[7]+72,selectors)||!image.live(at[7]+80,jumps)||
           selectors>UINT32_MAX-0x41||
           !image.contains(selectors+0x41,1,IMAGE_SCN_MEM_READ|IMAGE_SCN_MEM_EXECUTE,true)||
           !image.live(selectors+0x41,selector)||jumps>UINT32_MAX-std::uint32_t(selector)*4||
           !image.contains(jumps+selector*4,4,IMAGE_SCN_MEM_READ|IMAGE_SCN_MEM_EXECUTE,true)||
           !image.live(jumps+selector*4,case_target)||case_target!=at[8]||
           !image.unchanged(selectors+0x41,1)||!image.unchanged(jumps+selector*4,4))return false;
        for(unsigned i=0;i<at.size();++i)if(i!=3&&!image.unchanged(at[i],patterns[i]))return false;
        if(!image.unchanged(at[3],20))return false;
        out=b;return true;
    }catch(...){return false;}
}
}

