#pragma once
#include "observer_profile.hpp"
namespace rs::game::compat {
inline bool resolve_observers(MemoryReader read,std::uintptr_t base,ObserverBinding& output)noexcept {
    output={};
    try {Image image;if(!image.load(read,base))return false;
        ObserverBinding result{};std::uint32_t root_store{},request{},rectangle{},dimensions{},called{};
        if(!image.find(observer::allocate,result.allocate)||!image.find(observer::commit,result.commit)||
           !image.find(observer::root_store,root_store)||!observer::find_request(image,request,result.state_key))return false;
        const auto allocate_function=image.primary(result.allocate),commit_function=image.primary(result.commit),map_function=image.primary(request);
        if(allocate_function.begin!=result.allocate||commit_function.begin!=result.commit||!map_function.end||
           !image.contains(allocate_function.begin,allocate_function.end-allocate_function.begin,IMAGE_SCN_MEM_EXECUTE,true)||
           !image.contains(commit_function.begin,commit_function.end-commit_function.begin,IMAGE_SCN_MEM_EXECUTE,true)||
           !image.find(observer::rectangle,rectangle)||!image.find(observer::dimensions,dimensions)||
           image.primary(rectangle).begin!=commit_function.begin||image.primary(dimensions).begin!=map_function.begin||
           !image.function_contains(result.allocate,observer::allocate.size)||!image.function_contains(result.commit,observer::commit.size)||
           !image.function_contains(request,33)||!image.function_contains(rectangle,observer::rectangle.size)||
           !image.function_contains(dimensions,observer::dimensions.size)||!image.function_contains(root_store,observer::root_store.size)||
           !image.primary(root_store).end)return false;
        const auto* call=image.bytes(request+28,5);const auto* size=image.bytes(request+16,4);
        if(!call||call[0]!=0xE8||!size||!image.relative(request+28,1,5,called)||called!=result.allocate||
           !image.relative(root_store,17,21,result.root)||result.root%8||
           !image.contains(result.root,8,IMAGE_SCN_MEM_READ|IMAGE_SCN_MEM_WRITE,false))return false;
        std::memcpy(&result.state_bytes,size,4);if(result.state_bytes<0x60||result.state_bytes>0x10000||(result.state_bytes&7))return false;
        std::uintptr_t root_value{};if(!image.live(result.root,root_value))return false;
        // Masks tolerate relocation between builds, not concurrent changes
        // within this captured image. Include the complete allocator CALL.
        if(!image.unchanged(result.allocate,observer::allocate)||!image.unchanged(result.commit,observer::commit)||
           !image.unchanged(root_store,observer::root_store)||!image.unchanged(request,33)||
           !image.unchanged(rectangle,observer::rectangle)||!image.unchanged(dimensions,observer::dimensions))return false;
        output=result;return true;
    }catch(...){return false;}
}
}
