#include <rs/game/state.hpp>
#include <rs/platform/paths.hpp>
#include <windows.h>
#include <algorithm>
#include <cstring>
#include <string>
#include <vector>
namespace rs::game {
namespace {
template<class T>T value(std::span<const std::uint8_t> bytes,std::size_t offset){T result{};std::memcpy(&result,bytes.data()+offset,sizeof(T));return result;}
bool zero(std::span<const std::uint8_t> s){return std::all_of(s.begin(),s.end(),[](auto b){return b==0;});}
bool valid_frame(const Frame& f){return f.source==Availability::compatible&&f.map_open&&f.projection_ready&&f.world_ready&&f.application_address&&f.ui_address&&f.map_state_address&&f.process_id&&f.process_creation_time&&f.scope_start_sequence&&f.scope_start_sequence<=f.sequence;}
struct StateView {
    HANDLE mapping{};const std::uint8_t* view{};
    ~StateView(){if(view)UnmapViewOfFile(view);if(mapping)CloseHandle(mapping);}
};
}
bool decode_state(std::span<const std::uint8_t> b,const Frame& f,std::uint64_t nonce,const std::array<std::uint8_t,32>& catalog,std::uint64_t now,StateSnapshot& out)noexcept {
    out={};if(b.size()!=205152||!valid_frame(f)||!nonce||!f.sampled_at_ms||now<f.sampled_at_ms||now-f.sampled_at_ms>1000)return false;
    if(std::memcmp(b.data(),"RSSTATE1",8)||value<std::uint32_t>(b,8)!=1||value<std::uint32_t>(b,12)!=256||value<std::uint32_t>(b,16)!=205152)return false;
    const auto flags=value<std::uint32_t>(b,20);const auto generation=value<std::uint64_t>(b,24);
    const auto published=value<std::uint64_t>(b,56),captured=value<std::uint64_t>(b,160),seq=value<std::uint64_t>(b,152);
    if(flags>3||!generation||(generation&1)||value<std::uint32_t>(b,32)!=f.process_id||value<std::uint32_t>(b,36)!=0||
       value<std::uint64_t>(b,40)!=f.process_creation_time||value<std::uint64_t>(b,48)!=nonce||
       !published||!captured||now<published||now<captured||now-published>1000||now-captured>1000||published<captured||
       !value<std::uint64_t>(b,64)||seq>f.sequence||seq<f.scope_start_sequence||
       std::memcmp(b.data()+104,catalog.data(),32)||value<std::uint32_t>(b,136)!=1280||value<std::uint32_t>(b,140)!=1280||
       value<std::uint32_t>(b,144)!=204800||value<std::uint32_t>(b,148)!=88||
       value<std::uint64_t>(b,168)!=f.application_address||value<std::uint64_t>(b,176)!=f.ui_address||value<std::uint64_t>(b,184)!=f.map_state_address||
       value<std::uint32_t>(b,192)>1||value<std::uint32_t>(b,196)>16||value<std::uint32_t>(b,200)>2||!zero(b.subspan(204,52))||!zero(b.subspan(205144,8))||b[205143]!=0||(b[205142]&0xFC))return false;
    if(!zero(f.world_guid)&&std::memcmp(b.data()+72,f.world_guid.data(),16))return false;
    if(!zero(f.hero_guid)&&std::memcmp(b.data()+88,f.hero_guid.data(),16))return false;
    if(!(flags&1)&&!zero(b.subspan(256,204800)))return false;
    if(!(flags&2)&&!zero(b.subspan(205056,88)))return false;
    out.fow_ready=(flags&1)!=0;out.knowledge_ready=(flags&2)!=0;out.published_at_ms=published;out.captured_at_ms=captured;
    out.session=value<std::uint64_t>(b,64);out.source_frame_sequence=seq;
    out.appearance=value<std::uint32_t>(b,200);
    std::memcpy(out.world_guid.data(),b.data()+72,16);std::memcpy(out.hero_guid.data(),b.data()+88,16);
    std::memcpy(out.fow.data(),b.data()+256,204800);std::memcpy(out.known_rows.data(),b.data()+205056,88);return true;
}
bool read_state(const Frame& frame,const std::array<std::uint8_t,32>& catalog,std::uint64_t now,StateSnapshot& output)noexcept {
    output={};if(!valid_frame(frame))return false;
    try {
        auto name=L"Local\\ResourceScanner.State.v1."+std::to_wstring(GetCurrentProcessId());
        StateView resource{};resource.mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name.c_str());if(!resource.mapping)return false;
        resource.view=static_cast<const std::uint8_t*>(MapViewOfFile(resource.mapping,FILE_MAP_READ,0,0,205152));
        if(!resource.view)return false;const auto* view=resource.view;
        const auto* generation=reinterpret_cast<volatile const std::uint64_t*>(view+24);
        const auto before=*generation;MemoryBarrier();std::vector<std::uint8_t> copy;
        if(before&&!(before&1)){copy.assign(view,view+205152);MemoryBarrier();if(*generation!=before)copy.clear();}
        return !copy.empty()&&decode_state(copy,frame,platform::instance_nonce(),catalog,now,output);
    }catch(...){return false;}
}
}
