#pragma once
#include <rs/game/tracking.hpp>
#include <algorithm>
#include <cmath>
#include <cstring>

namespace rs::game::tracking_detail {
inline constexpr std::uint64_t hover_ttl=250,request_ttl=500;
struct Context {
    std::uintptr_t app{},ui{},map_state{},map_node{},controller{},client{},world{},manager{};
    std::array<std::uint8_t,3> selected{},loaded{};
    std::uint64_t epoch{};
    bool operator==(const Context&)const=default;
};
struct Request {
    Frame scope{};
    Context context{};
    std::array<std::int64_t,3> xyz{};
    std::uint64_t accepted_at{},source_point_id{};
};
struct Cursor {float x{},y{};bool valid{};};
inline bool age(std::uint64_t now,std::uint64_t then,std::uint64_t ttl)noexcept{return then&&now>=then&&now-then<=ttl;}
inline bool rect_valid(const Rect&r)noexcept{return std::isfinite(r.left)&&std::isfinite(r.top)&&std::isfinite(r.right)&&std::isfinite(r.bottom)&&r.left<r.right&&r.top<r.bottom;}
inline bool in_rect(const Rect&r,float x,float y)noexcept{return x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom;}
inline bool contains(const TrackingHitArea&a,float x,float y)noexcept{
    if(!rect_valid(a.bounds)||!in_rect(a.bounds,x,y))return false;
    const float hw=(a.bounds.right-a.bounds.left)*.5f,hh=(a.bounds.bottom-a.bounds.top)*.5f;
    const float dx=std::abs(x-(a.bounds.left+hw)),dy=std::abs(y-(a.bounds.top+hh));
    if(a.shape==TrackingShape::circle){const float r=std::min(hw,hh);return dx*dx+dy*dy<=r*r;}
    if(a.shape!=TrackingShape::rounded_rectangle||!std::isfinite(a.rounding)||a.rounding<0)return false;
    const float r=std::min(a.rounding,std::min(hw,hh)),cx=std::max(0.f,dx-(hw-r)),cy=std::max(0.f,dy-(hh-r));
    return cx*cx+cy*cy<=r*r;
}
inline bool coordinates(float x,float y,float z,std::array<std::int64_t,3>&out)noexcept{
    const float values[]{x,y,z};
    for(unsigned i=0;i<3;++i){if(!std::isfinite(values[i])||std::abs(values[i])>1e6f)return false;
        out[i]=static_cast<std::int64_t>(static_cast<double>(values[i])*4294967296.0);}
    return true;
}
inline bool scope_valid(const Frame&f,std::uint64_t now,std::uint32_t pid,std::uint64_t birth)noexcept{
    return f.process_id==pid&&pid&&f.process_creation_time==birth&&birth&&f.sequence&&f.scope_start_sequence&&f.scope_start_sequence<=f.sequence&&
        age(now,f.sampled_at_ms,hover_ttl)&&f.source==Availability::compatible&&f.map_open&&f.projection_ready&&f.hud_bounds_ready&&f.world_ready&&
        f.application_address>=0x10000&&f.ui_address>=0x10000&&f.map_state_address>=0x10000&&rect_valid(f.map_content);
}
inline bool matches(const Frame&f,const Context&c)noexcept{return f.application_address==c.app&&f.ui_address==c.ui&&f.map_state_address==c.map_state;}
class Coordinator {
    TrackingHit hit_{};Request request_{};Context gesture_{};
    std::uint64_t hit_epoch_{},gesture_at_{};bool hit_valid_{},pending_{},gesture_valid_{};
public:
    void clear_hit()noexcept{hit_valid_=false;}
    void reset()noexcept{hit_valid_=pending_=gesture_valid_=false;}
    bool pending()const noexcept{return pending_;}
    bool publish(const TrackingHit&h,std::uint64_t now,std::uint32_t pid,std::uint64_t birth,std::uint64_t epoch)noexcept{
        clear_hit();std::array<std::int64_t,3> unused{};
        if(!epoch||h.scope.tracking_generation!=epoch||!h.native_window||h.source_flags!=1||!scope_valid(h.scope,now,pid,birth)||!coordinates(h.x,h.y,h.z,unused)||
            !h.area_count||h.area_count>h.areas.size())return false;
        for(unsigned i=0;i<h.area_count;++i)if(!rect_valid(h.areas[i].bounds)||!std::isfinite(h.areas[i].rounding)||h.areas[i].rounding<0||
            (h.areas[i].shape!=TrackingShape::circle&&h.areas[i].shape!=TrackingShape::rounded_rectangle))return false;
        if(pending_){
            const auto differs=[](auto&a,auto&b)noexcept{bool aa=false,bb=false;for(auto x:a)aa=aa||x;for(auto x:b)bb=bb||x;return aa&&bb&&a!=b;};
            if(request_.scope.scope_start_sequence!=h.scope.scope_start_sequence||differs(request_.scope.world_guid,h.scope.world_guid)||
                differs(request_.scope.hero_guid,h.scope.hero_guid))pending_=false;
        }
        hit_=h;hit_epoch_=epoch;hit_valid_=true;return true;
    }
    // Return true only for a native right-button status owned by this hit.
    bool button(std::uint32_t status,const Context&c,const Cursor&mouse,std::uint64_t now,std::uint32_t pid,std::uint64_t birth)noexcept{
        // GAME119BA50 packs independent flags above the kind byte. The native
        // WORLD-map consumer tests R13B, not the complete query DWORD.
        status&=0xFFu;
        if(gesture_valid_){
            if(!(gesture_==c)){gesture_valid_=false;}
            else {if(status==3||status==4||status==5)gesture_valid_=false;return true;}
        }
        if(status!=1||pending_||!hit_valid_||hit_epoch_!=c.epoch||!matches(hit_.scope,c)||!scope_valid(hit_.scope,now,pid,birth)||!mouse.valid||
            !std::isfinite(mouse.x)||!std::isfinite(mouse.y)||!in_rect(hit_.scope.map_content,mouse.x,mouse.y))return false;
        for(std::uint32_t i=0;i<hit_.scope.ui_blocker_count&&i<hit_.scope.ui_blockers.size();++i)
            if(rect_valid(hit_.scope.ui_blockers[i])&&in_rect(hit_.scope.ui_blockers[i],mouse.x,mouse.y))return false;
        bool target=false;for(unsigned i=0;i<hit_.area_count;++i)target=target||contains(hit_.areas[i],mouse.x,mouse.y);
        std::array<std::int64_t,3> xyz{};if(!target||!coordinates(hit_.x,hit_.y,hit_.z,xyz))return false;
        request_={hit_.scope,c,xyz,now,hit_.source_point_id};pending_=true;gesture_=c;gesture_at_=now;gesture_valid_=true;return true;
    }
    bool take(const Context&c,std::uint64_t now,Request&out)noexcept{
        if(!pending_)return false;pending_=false;
        if(!(request_.context==c)||!age(now,request_.accepted_at,request_ttl))return false;
        out=request_;return true;
    }
    const TrackingHit* hit()const noexcept{return hit_valid_?&hit_:nullptr;}
    const Request* queued()const noexcept{return pending_?&request_:nullptr;}
};
} // namespace rs::game::tracking_detail
