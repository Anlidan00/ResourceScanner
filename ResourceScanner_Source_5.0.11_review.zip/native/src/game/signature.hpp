#pragma once
#include <rs/game/frame.hpp>
#include <windows.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <vector>

namespace rs::game::compat {
struct Pattern {const std::uint8_t* bytes{};const std::uint8_t* mask{};std::size_t size{};};
inline bool matches(const std::uint8_t* data,Pattern p)noexcept {
    if(!data||!p.bytes||!p.mask||p.size<8||p.size>512)return false;
    for(std::size_t i=0;i<p.size;++i)if((data[i]&p.mask[i])!=(p.bytes[i]&p.mask[i]))return false;
    return true;
}
struct Region {std::uint32_t rva{},size{},flags{};std::vector<std::uint8_t> bytes;};
struct Function {std::uint32_t begin{},end{},unwind{};};
class Image {
    MemoryReader reader_{};std::uintptr_t base_{};std::uint32_t size_{};
    bool copy(std::uint32_t at,void* out,std::size_t n)const noexcept {
        if(at>size_||n>size_-at||base_+at<base_)return false;
        auto* p=static_cast<std::uint8_t*>(out);
        for(std::size_t i=0;i<n;i+=65536){const auto amount=std::min<std::size_t>(65536,n-i);
            if(!reader_.copy||!reader_.copy(reader_.user,base_+at+i,p+i,amount))return false;}
        return true;
    }
public:
    std::vector<Region> regions;std::vector<Function> functions;
    bool load(MemoryReader reader,std::uintptr_t base) {
        reader_=reader;base_=base;size_=0x100000;regions.clear();functions.clear();
        IMAGE_DOS_HEADER dos{};IMAGE_NT_HEADERS64 nt{};
        if(base<65536||!copy(0,&dos,sizeof(dos))||dos.e_magic!=IMAGE_DOS_SIGNATURE||dos.e_lfanew<64||
           dos.e_lfanew>0x100000-static_cast<int>(sizeof(nt))||!copy(dos.e_lfanew,&nt,sizeof(nt))||nt.Signature!=IMAGE_NT_SIGNATURE||
           nt.FileHeader.Machine!=IMAGE_FILE_MACHINE_AMD64||!nt.FileHeader.NumberOfSections||nt.FileHeader.NumberOfSections>96||
           nt.FileHeader.SizeOfOptionalHeader<sizeof(IMAGE_OPTIONAL_HEADER64)||nt.OptionalHeader.Magic!=IMAGE_NT_OPTIONAL_HDR64_MAGIC||
           nt.OptionalHeader.NumberOfRvaAndSizes<=IMAGE_DIRECTORY_ENTRY_EXCEPTION)return false;
        size_=nt.OptionalHeader.SizeOfImage;
        if(size_<4096||size_>0x40000000||nt.OptionalHeader.SizeOfHeaders>size_||base_+size_<base_)return false;
        const auto table=std::uint64_t(dos.e_lfanew)+4+sizeof(IMAGE_FILE_HEADER)+nt.FileHeader.SizeOfOptionalHeader;
        const auto table_size=std::size_t(nt.FileHeader.NumberOfSections)*sizeof(IMAGE_SECTION_HEADER);
        if(table>nt.OptionalHeader.SizeOfHeaders||table_size>nt.OptionalHeader.SizeOfHeaders-table)return false;
        std::vector<IMAGE_SECTION_HEADER> sections(nt.FileHeader.NumberOfSections);
        if(!copy(static_cast<std::uint32_t>(table),sections.data(),table_size))return false;
        std::uint64_t code_bytes{};
        for(auto&s:sections){const auto length=std::max(s.Misc.VirtualSize,s.SizeOfRawData);if(!length)continue;
            if(s.VirtualAddress<size_t(nt.OptionalHeader.SizeOfHeaders)||s.VirtualAddress>size_||length>size_-s.VirtualAddress)return false;
            for(auto&r:regions)if(s.VirtualAddress<std::uint64_t(r.rva)+r.size&&r.rva<std::uint64_t(s.VirtualAddress)+length)return false;
            Region r{s.VirtualAddress,length,s.Characteristics,{}};
            if(r.flags&IMAGE_SCN_MEM_EXECUTE){if((code_bytes+=length)>128*1024*1024)return false;r.bytes.resize(length);if(!copy(r.rva,r.bytes.data(),length))return false;}
            regions.push_back(std::move(r));
        }
        const auto& dir=nt.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
        if(!dir.VirtualAddress||!dir.Size||dir.Size%12||dir.Size>16*1024*1024||!contains(dir.VirtualAddress,dir.Size,IMAGE_SCN_MEM_READ,false))return false;
        std::vector<RUNTIME_FUNCTION> records(dir.Size/12);if(!copy(dir.VirtualAddress,records.data(),dir.Size))return false;
        for(auto&f:records){if(f.BeginAddress>=f.EndAddress||f.EndAddress>size_||(!functions.empty()&&functions.back().begin>=f.BeginAddress))return false;functions.push_back({f.BeginAddress,f.EndAddress,f.UnwindData});}
        return !regions.empty()&&!functions.empty();
    }
    bool contains(std::uint32_t at,std::size_t n,std::uint32_t flags,bool executable)const noexcept {
        for(auto&r:regions)if(at>=r.rva&&at-r.rva<=r.size&&n<=r.size-(at-r.rva)&&
            (r.flags&flags)==flags&&bool(r.flags&IMAGE_SCN_MEM_EXECUTE)==executable)return true;
        return false;
    }
    const std::uint8_t* bytes(std::uint32_t at,std::size_t n)const noexcept {
        for(auto&r:regions)if(!r.bytes.empty()&&at>=r.rva&&at-r.rva<=r.bytes.size()&&n<=r.bytes.size()-(at-r.rva))return r.bytes.data()+at-r.rva;
        return nullptr;
    }
    Function function(std::uint32_t at)const noexcept {
        auto i=std::upper_bound(functions.begin(),functions.end(),at,[](auto at,const Function&f){return at<f.begin;});
        if(i==functions.begin())return {};--i;return at<i->end?*i:Function{};
    }
    bool function_contains(std::uint32_t at,std::size_t n)const noexcept {
        const auto f=function(at);
        return n&&f.end&&n<=f.end-at&&contains(f.begin,f.end-f.begin,IMAGE_SCN_MEM_EXECUTE,true);
    }
    Function primary(std::uint32_t at)const noexcept {
        auto f=function(at);std::array<std::uint32_t,16> seen{};
        for(unsigned depth=0;f.end&&depth<seen.size();++depth){
            if(!f.unwind||(f.unwind&3)||!contains(f.unwind,4,IMAGE_SCN_MEM_READ,false))return {};
            std::array<std::uint8_t,4> head{};if(!copy(f.unwind,head.data(),head.size())||(head[0]&7)<1||(head[0]&7)>2)return {};
            if(!(head[0]&32))return f;if(head[0]&24)return {};
            seen[depth]=f.begin;const auto chain=std::uint64_t(f.unwind)+4+((unsigned(head[2])+1)&~1u)*2;
            if(chain>size_||!contains(static_cast<std::uint32_t>(chain),12,IMAGE_SCN_MEM_READ,false))return {};
            RUNTIME_FUNCTION next{};if(!copy(static_cast<std::uint32_t>(chain),&next,sizeof(next)))return {};
            auto parent=function(next.BeginAddress);
            if(parent.begin!=next.BeginAddress||parent.end!=next.EndAddress||parent.unwind!=next.UnwindData||
               std::find(seen.begin(),seen.begin()+depth+1,parent.begin)!=seen.begin()+depth+1)return {};
            f=parent;
        }
        return {};
    }
    bool primary_contains(std::uint32_t at,std::size_t n)const noexcept {
        const auto owner=primary(at);if(!n||!owner.end||n>UINT32_MAX-at)return false;
        const auto end=at+static_cast<std::uint32_t>(n);
        while(at<end){const auto part=function(at);if(!part.end||primary(at).begin!=owner.begin||
            !contains(part.begin,part.end-part.begin,IMAGE_SCN_MEM_EXECUTE,true))return false;
            at=std::min(part.end,end);}
        return true;
    }
    bool find(Pattern p,std::uint32_t& result,Function within={},bool* ambiguous=nullptr)const noexcept {
        result=0;if(ambiguous)*ambiguous=false;if(!p.mask||!p.bytes||p.size<8||p.size>512)return false;
        std::size_t anchor{},length{},fixed{};
        for(std::size_t i=0;i<p.size;){if(p.mask[i]!=255){++i;continue;}auto start=i;while(i<p.size&&p.mask[i]==255)++i;fixed+=i-start;if(i-start>length){anchor=start;length=i-start;}}
        if(length<4||fixed<12)return false;
        unsigned found{};
        for(auto&r:regions){if(r.bytes.empty()||r.bytes.size()<p.size)continue;auto begin=r.bytes.begin(),end=r.bytes.end();
            for(auto pos=begin;pos!=end;){pos=std::search(pos,end,p.bytes+anchor,p.bytes+anchor+length);if(pos==end)break;
                const auto offset=static_cast<std::size_t>(pos-begin);++pos;
                if(offset<anchor||offset-anchor>r.bytes.size()-p.size)continue;
                const auto at=r.rva+static_cast<std::uint32_t>(offset-anchor);
                if(within.end&&(at<within.begin||std::uint64_t(at)+p.size>within.end))continue;
                if(matches(r.bytes.data()+offset-anchor,p)){if(++found>1){if(ambiguous)*ambiguous=true;return false;}result=at;}
            }
        }
        return found==1;
    }
    bool unchanged(std::uint32_t at,std::size_t n)const noexcept {
        std::array<std::uint8_t,512> data{};const auto* snapshot=bytes(at,n);
        return snapshot&&n&&n<=data.size()&&copy(at,data.data(),n)&&std::memcmp(data.data(),snapshot,n)==0;
    }
    bool unchanged(std::uint32_t at,Pattern p)const noexcept {
        const auto* snapshot=bytes(at,p.size);
        return snapshot&&matches(snapshot,p)&&unchanged(at,p.size);
    }
    template<class T>bool live(std::uint32_t at,T& out)const noexcept{return copy(at,&out,sizeof(out));}
    bool relative(std::uint32_t at,unsigned displacement,unsigned end,std::uint32_t& target)const noexcept {
        auto*p=bytes(at+displacement,4);if(!p)return false;std::int32_t delta{};std::memcpy(&delta,p,4);
        const auto value=std::int64_t(at)+end+delta;if(value<0||value>=size_)return false;target=static_cast<std::uint32_t>(value);return true;
    }
};
struct ObserverBinding {std::uint32_t allocate{},commit{},root{},state_bytes{};std::uint64_t state_key{};};
}
