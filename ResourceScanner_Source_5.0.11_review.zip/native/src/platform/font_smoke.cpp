#include <rs/platform/font.hpp>
#include <imgui.h>
#include <nlohmann/json.hpp>
#include <fstream>
#include <filesystem>
#include <cmath>
#include <cstdio>
int main(int argc,char** argv){
    if(argc!=2)return 2;auto* context=ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;
    const auto root=std::filesystem::path(argv[1]);if(!rs::platform::initialize_fonts(io.Fonts,root))return 3;
    unsigned char* pixels{};int width{},height{};io.Fonts->GetTexDataAsRGBA32(&pixels,&width,&height);
    if(!pixels||width<=0||height<=0)return 4;
    std::ifstream input(root/L"manifest.json");auto definitions=nlohmann::json::parse(input);unsigned count{};
    for(const auto& entry:definitions.at("fonts")){
        auto role=entry.at("role").get<std::string>();if(!rs::platform::font_available(role))return 5;
        auto* font=rs::platform::font(role);auto* baked=font->GetFontBaked(16.f);
        for(const auto& range:entry.at("ranges"))for(unsigned cp=range.at(0).get<unsigned>();cp<=range.at(1).get<unsigned>();++cp){auto* glyph=baked->FindGlyphNoFallback(static_cast<ImWchar>(cp));
            if(!glyph||!std::isfinite(glyph->AdvanceX)||glyph->AdvanceX<0||!std::isfinite(glyph->X0)||!std::isfinite(glyph->Y0)||
               !std::isfinite(glyph->X1)||!std::isfinite(glyph->Y1)){std::printf("missing %s U+%X\n",role.c_str(),cp);return 6;}
            ++count;}
    }
    if(rs::platform::font("cjk-jp")==rs::platform::font("cjk-sc")||rs::platform::font("cjk-sc")==rs::platform::font("cjk-tc"))return 7;
    std::printf("PASS actual official ImGui/STB atlas %u glyphs,6 independent profiles,%dx%d RGBA\n",count,width,height);
    rs::platform::forget_fonts();ImGui::DestroyContext(context);return 0;
}
