#pragma once
// Immutable typed slots preserve the EXACT PFN and resolver origin returned by
// each layer lookup. Saturation returns the unmodified API; never guess a handle.
enum class DispatchCommand { Gipa,Gdpa,CreateInstance,DestroyInstance,CreateDevice,CreateWin32SurfaceKHR,GetDeviceQueue,GetDeviceQueue2,CreateSwapchainKHR,DestroySwapchainKHR,DestroyDevice,QueuePresentKHR,EnumeratePhysicalDevices,EnumeratePhysicalDeviceGroups,EnumeratePhysicalDeviceGroupsKHR,DestroySurfaceKHR,Count };
constexpr std::size_t dispatch_slots=32;
std::array<std::array<Dispatch,dispatch_slots>,static_cast<std::size_t>(DispatchCommand::Count)> dispatches{};
Dispatch dispatch_at(DispatchCommand command,std::size_t index){std::lock_guard lock(mutex);return dispatches[static_cast<std::size_t>(command)][index];}
template<std::size_t I> VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL route_Gipa(VkInstance owner,const char* name){return invoke_gipa(dispatch_at(DispatchCommand::Gipa,I),owner,name);}
template<std::size_t... I>auto table_Gipa(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_Gipa<I>)...};}
const auto routes_Gipa=table_Gipa(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL route_Gdpa(VkDevice owner,const char* name){return invoke_gdpa(dispatch_at(DispatchCommand::Gdpa,I),owner,name);}
template<std::size_t... I>auto table_Gdpa(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_Gdpa<I>)...};}
const auto routes_Gdpa=table_Gdpa(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR VkResult VKAPI_CALL route_CreateInstance(const VkInstanceCreateInfo* info,const VkAllocationCallbacks* allocation,VkInstance* out){return invoke_create_instance(dispatch_at(DispatchCommand::CreateInstance,I),info,allocation,out);}
template<std::size_t... I>auto table_CreateInstance(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_CreateInstance<I>)...};}
const auto routes_CreateInstance=table_CreateInstance(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR void VKAPI_CALL route_DestroyInstance(VkInstance owner,const VkAllocationCallbacks* allocation){return invoke_destroy_instance(dispatch_at(DispatchCommand::DestroyInstance,I),owner,allocation);}
template<std::size_t... I>auto table_DestroyInstance(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_DestroyInstance<I>)...};}
const auto routes_DestroyInstance=table_DestroyInstance(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR VkResult VKAPI_CALL route_CreateDevice(VkPhysicalDevice gpu,const VkDeviceCreateInfo* info,const VkAllocationCallbacks* allocation,VkDevice* out){return invoke_create_device(dispatch_at(DispatchCommand::CreateDevice,I),gpu,info,allocation,out);}
template<std::size_t... I>auto table_CreateDevice(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_CreateDevice<I>)...};}
const auto routes_CreateDevice=table_CreateDevice(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR VkResult VKAPI_CALL route_CreateWin32SurfaceKHR(VkInstance owner,const VkWin32SurfaceCreateInfoKHR* info,const VkAllocationCallbacks* allocation,VkSurfaceKHR* out){return invoke_create_surface(dispatch_at(DispatchCommand::CreateWin32SurfaceKHR,I),owner,info,allocation,out);}
template<std::size_t... I>auto table_CreateWin32SurfaceKHR(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_CreateWin32SurfaceKHR<I>)...};}
const auto routes_CreateWin32SurfaceKHR=table_CreateWin32SurfaceKHR(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR void VKAPI_CALL route_GetDeviceQueue(VkDevice owner,std::uint32_t family,std::uint32_t index,VkQueue* out){return invoke_get_queue(dispatch_at(DispatchCommand::GetDeviceQueue,I),owner,family,index,out);}
template<std::size_t... I>auto table_GetDeviceQueue(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_GetDeviceQueue<I>)...};}
const auto routes_GetDeviceQueue=table_GetDeviceQueue(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR void VKAPI_CALL route_GetDeviceQueue2(VkDevice owner,const VkDeviceQueueInfo2* info,VkQueue* out){return invoke_get_queue2(dispatch_at(DispatchCommand::GetDeviceQueue2,I),owner,info,out);}
template<std::size_t... I>auto table_GetDeviceQueue2(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_GetDeviceQueue2<I>)...};}
const auto routes_GetDeviceQueue2=table_GetDeviceQueue2(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR VkResult VKAPI_CALL route_CreateSwapchainKHR(VkDevice owner,const VkSwapchainCreateInfoKHR* info,const VkAllocationCallbacks* allocation,VkSwapchainKHR* out){return invoke_create_swapchain(dispatch_at(DispatchCommand::CreateSwapchainKHR,I),owner,info,allocation,out);}
template<std::size_t... I>auto table_CreateSwapchainKHR(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_CreateSwapchainKHR<I>)...};}
const auto routes_CreateSwapchainKHR=table_CreateSwapchainKHR(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR void VKAPI_CALL route_DestroySwapchainKHR(VkDevice owner,VkSwapchainKHR handle,const VkAllocationCallbacks* allocation){return invoke_destroy_swapchain(dispatch_at(DispatchCommand::DestroySwapchainKHR,I),owner,handle,allocation);}
template<std::size_t... I>auto table_DestroySwapchainKHR(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_DestroySwapchainKHR<I>)...};}
const auto routes_DestroySwapchainKHR=table_DestroySwapchainKHR(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR void VKAPI_CALL route_DestroyDevice(VkDevice owner,const VkAllocationCallbacks* allocation){return invoke_destroy_device(dispatch_at(DispatchCommand::DestroyDevice,I),owner,allocation);}
template<std::size_t... I>auto table_DestroyDevice(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_DestroyDevice<I>)...};}
const auto routes_DestroyDevice=table_DestroyDevice(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR VkResult VKAPI_CALL route_QueuePresentKHR(VkQueue queue,const VkPresentInfoKHR* info){return invoke_present(dispatch_at(DispatchCommand::QueuePresentKHR,I),queue,info);}
template<std::size_t... I>auto table_QueuePresentKHR(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_QueuePresentKHR<I>)...};}
const auto routes_QueuePresentKHR=table_QueuePresentKHR(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR VkResult VKAPI_CALL route_EnumeratePhysicalDevices(VkInstance owner,std::uint32_t* count,VkPhysicalDevice* devices){return invoke_enumerate_physical(dispatch_at(DispatchCommand::EnumeratePhysicalDevices,I),owner,count,devices);}
template<std::size_t... I>auto table_EnumeratePhysicalDevices(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_EnumeratePhysicalDevices<I>)...};}
const auto routes_EnumeratePhysicalDevices=table_EnumeratePhysicalDevices(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR VkResult VKAPI_CALL route_EnumeratePhysicalDeviceGroups(VkInstance owner,std::uint32_t* count,VkPhysicalDeviceGroupProperties* groups){return invoke_enumerate_groups(dispatch_at(DispatchCommand::EnumeratePhysicalDeviceGroups,I),owner,count,groups);}
template<std::size_t... I>auto table_EnumeratePhysicalDeviceGroups(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_EnumeratePhysicalDeviceGroups<I>)...};}
const auto routes_EnumeratePhysicalDeviceGroups=table_EnumeratePhysicalDeviceGroups(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR VkResult VKAPI_CALL route_EnumeratePhysicalDeviceGroupsKHR(VkInstance owner,std::uint32_t* count,VkPhysicalDeviceGroupProperties* groups){return invoke_enumerate_groups(dispatch_at(DispatchCommand::EnumeratePhysicalDeviceGroupsKHR,I),owner,count,groups);}
template<std::size_t... I>auto table_EnumeratePhysicalDeviceGroupsKHR(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_EnumeratePhysicalDeviceGroupsKHR<I>)...};}
const auto routes_EnumeratePhysicalDeviceGroupsKHR=table_EnumeratePhysicalDeviceGroupsKHR(std::make_index_sequence<dispatch_slots>{});
template<std::size_t I> VKAPI_ATTR void VKAPI_CALL route_DestroySurfaceKHR(VkInstance owner,VkSurfaceKHR surface,const VkAllocationCallbacks* allocation){return invoke_destroy_surface(dispatch_at(DispatchCommand::DestroySurfaceKHR,I),owner,surface,allocation);}
template<std::size_t... I>auto table_DestroySurfaceKHR(std::index_sequence<I...>){return std::array<PFN_vkVoidFunction,sizeof...(I)>{reinterpret_cast<PFN_vkVoidFunction>(route_DestroySurfaceKHR<I>)...};}
const auto routes_DestroySurfaceKHR=table_DestroySurfaceKHR(std::make_index_sequence<dispatch_slots>{});
bool same_origin(const DispatchOrigin& a,const DispatchOrigin& b){return a.instance_proc==b.instance_proc&&a.device_proc==b.device_proc&&a.instance==b.instance&&a.device==b.device;}
PFN_vkVoidFunction replacement(const char* name,PFN_vkVoidFunction original,const DispatchOrigin& origin){
    if(!name||!original||original_depth)return original;
    DispatchCommand command=DispatchCommand::Count;const std::array<PFN_vkVoidFunction,dispatch_slots>* table=nullptr;
    if(std::strcmp(name,"vkGetInstanceProcAddr")==0){command=DispatchCommand::Gipa;table=&routes_Gipa;}
    if(std::strcmp(name,"vkGetDeviceProcAddr")==0){command=DispatchCommand::Gdpa;table=&routes_Gdpa;}
    if(std::strcmp(name,"vkCreateInstance")==0){command=DispatchCommand::CreateInstance;table=&routes_CreateInstance;}
    if(std::strcmp(name,"vkDestroyInstance")==0){command=DispatchCommand::DestroyInstance;table=&routes_DestroyInstance;}
    if(std::strcmp(name,"vkCreateDevice")==0){command=DispatchCommand::CreateDevice;table=&routes_CreateDevice;}
    if(std::strcmp(name,"vkCreateWin32SurfaceKHR")==0){command=DispatchCommand::CreateWin32SurfaceKHR;table=&routes_CreateWin32SurfaceKHR;}
    if(std::strcmp(name,"vkGetDeviceQueue")==0){command=DispatchCommand::GetDeviceQueue;table=&routes_GetDeviceQueue;}
    if(std::strcmp(name,"vkGetDeviceQueue2")==0){command=DispatchCommand::GetDeviceQueue2;table=&routes_GetDeviceQueue2;}
    if(std::strcmp(name,"vkCreateSwapchainKHR")==0){command=DispatchCommand::CreateSwapchainKHR;table=&routes_CreateSwapchainKHR;}
    if(std::strcmp(name,"vkDestroySwapchainKHR")==0){command=DispatchCommand::DestroySwapchainKHR;table=&routes_DestroySwapchainKHR;}
    if(std::strcmp(name,"vkDestroyDevice")==0){command=DispatchCommand::DestroyDevice;table=&routes_DestroyDevice;}
    if(std::strcmp(name,"vkQueuePresentKHR")==0){command=DispatchCommand::QueuePresentKHR;table=&routes_QueuePresentKHR;}
    if(std::strcmp(name,"vkEnumeratePhysicalDevices")==0){command=DispatchCommand::EnumeratePhysicalDevices;table=&routes_EnumeratePhysicalDevices;}
    if(std::strcmp(name,"vkEnumeratePhysicalDeviceGroups")==0){command=DispatchCommand::EnumeratePhysicalDeviceGroups;table=&routes_EnumeratePhysicalDeviceGroups;}
    if(std::strcmp(name,"vkEnumeratePhysicalDeviceGroupsKHR")==0){command=DispatchCommand::EnumeratePhysicalDeviceGroupsKHR;table=&routes_EnumeratePhysicalDeviceGroupsKHR;}
    if(std::strcmp(name,"vkDestroySurfaceKHR")==0){command=DispatchCommand::DestroySurfaceKHR;table=&routes_DestroySurfaceKHR;}
    if(!table)return original;for(auto existing:*table)if(existing==original)return original;
    auto& slots=dispatches[static_cast<std::size_t>(command)];
    for(std::size_t i=0;i<slots.size();++i)if(slots[i].function==original&&same_origin(slots[i].origin,origin))return (*table)[i];
    for(std::size_t i=0;i<slots.size();++i)if(!slots[i].function){slots[i]={original,origin};return (*table)[i];}
    static bool reported=false;if(!reported){reported=true;log("vulkan-stage","Typed dispatch capacity reached; real API retained without observation");}return original;
}
