#include <windows.h>
#include <string>
#include "proxy_exports.hpp"
namespace {
HMODULE self{},system_module{};INIT_ONCE once=INIT_ONCE_STATIC_INIT;
BOOL CALLBACK initialize(PINIT_ONCE,void*,void**) {
    try {
    wchar_t root[32768]{};auto n=GetSystemDirectoryW(root,32768);
    if(!n||n>=32768)return FALSE;
    std::wstring path(root,n);path+=L"\\dbghelp.dll";
    system_module=LoadLibraryExW(path.c_str(),nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);return system_module!=nullptr;
    }catch(...){return FALSE;}
}
extern "C" ULONG_PTR missing_export() noexcept {return 0;}
DWORD WINAPI initialize_core(void*) {
    try {
    wchar_t name[32768]{};auto n=GetModuleFileNameW(self,name,32768);if(!n||n>=32768)return 0;
    std::wstring path(name,n);auto slash=path.find_last_of(L"\\/");if(slash==std::wstring::npos)return 0;
    path.resize(slash+1);path+=L"ResourceScanner\\ResourceScannerCore.dll";
    auto module=LoadLibraryExW(path.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);
    if(module){auto start=reinterpret_cast<BOOL(*)()>(GetProcAddress(module,"ResourceScannerStart"));if(start)start();}
    return 0;
    }catch(...){return ERROR_NOT_ENOUGH_MEMORY;}
}
}
extern "C" FARPROC rs_resolve_proxy_export(unsigned index) noexcept {
    if(index>=rs_proxy_export_count||!InitOnceExecuteOnce(&once,initialize,nullptr,nullptr))
        return reinterpret_cast<FARPROC>(missing_export);
    const auto& entry=rs_proxy_exports[index];
    auto result=GetProcAddress(system_module,entry.name?entry.name:MAKEINTRESOURCEA(entry.ordinal));
    return result?result:reinterpret_cast<FARPROC>(missing_export);
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID) {
    if(reason==DLL_PROCESS_ATTACH){self=module;DisableThreadLibraryCalls(module);
        // Worker cannot run loader operations until this attach notification
        // completes. Never wait for it while holding the loader lock.
        if(auto handle=CreateThread(nullptr,0,initialize_core,nullptr,0,nullptr))CloseHandle(handle);}
    return TRUE;
}
