#pragma once
#include <windows.h>
#include <rs/platform/render.hpp>
namespace rs::platform::detail {
void set_module(HMODULE) noexcept;
RenderClient client() noexcept;
bool stopping() noexcept;
bool install_vulkan_hooks() noexcept;
void remove_vulkan_hooks() noexcept;
void publish(const game::Frame&) noexcept;
void close_publication() noexcept;
std::uint64_t process_birth() noexcept;
}
