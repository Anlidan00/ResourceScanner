// Real Vulkan remains usable when the optional Scanner Core is absent.
#include <windows.h>
#define VK_NO_PROTOTYPES
#include <vulkan/vulkan.h>
#include <filesystem>
#include <cstdio>
int wmain(int argc,wchar_t** argv){
    if(argc!=2)return 2;
    try{
        const auto source=std::filesystem::absolute(argv[1]);const auto directory=source.parent_path()/L"missing_core_fixture";
        std::filesystem::create_directories(directory);const auto target=directory/L"vulkan-1.dll";
        std::filesystem::copy_file(source,target,std::filesystem::copy_options::overwrite_existing);
        if(std::filesystem::exists(directory/L"ResourceScanner/ResourceScannerCore.dll"))return 3;
        auto module=LoadLibraryExW(target.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);if(!module)return 4;
        auto gipa=reinterpret_cast<PFN_vkGetInstanceProcAddr>(GetProcAddress(module,"vkGetInstanceProcAddr"));if(!gipa)return 5;
        if(gipa(nullptr,"vkResourceScannerUnknownFunction"))return 6;
        auto create=reinterpret_cast<PFN_vkCreateInstance>(gipa(nullptr,"vkCreateInstance"));if(!create)return 7;
        VkInstanceCreateInfo info{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};VkInstance instance{};
        if(create(&info,nullptr,&instance)!=VK_SUCCESS||!instance)return 8;
        auto destroy=reinterpret_cast<PFN_vkDestroyInstance>(gipa(instance,"vkDestroyInstance"));if(!destroy)return 9;
        destroy(instance,nullptr);FreeLibrary(module);
        std::puts("PASS missing Core: real Vulkan instance creation/destruction retained; unsupported lookup NULL; no Scanner dependency gates engine");return 0;
    }catch(...){return 10;}
}
