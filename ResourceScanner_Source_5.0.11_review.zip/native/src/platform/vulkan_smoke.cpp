// Standalone hidden-window GPU fixture. It never opens or controls a game.
#include <windows.h>
#define VK_NO_PROTOTYPES
#include <vulkan/vulkan.h>
#include <rs/platform/render.hpp>
#include <imgui.h>
#include <filesystem>
#include <vector>
#include <array>
#include <cstdio>
#include <stdexcept>
#include <cstring>
#include <fstream>
#include <nlohmann/json.hpp>

namespace {
PFN_vkGetInstanceProcAddr gipa{};PFN_vkGetDeviceProcAddr gdpa{};VkInstance instance{};VkDevice device{};
template<class T>T global(const char* n){return reinterpret_cast<T>(gipa(nullptr,n));}
template<class T>T inst(const char* n){auto p=reinterpret_cast<T>(gipa(instance,n));if(!p)throw std::runtime_error(n);return p;}
template<class T>T dev(const char* n){auto p=reinterpret_cast<T>(gdpa(device,n));if(!p)throw std::runtime_error(n);return p;}
void check(VkResult value,const char* phase){if(value!=VK_SUCCESS&&value!=VK_SUBOPTIMAL_KHR){std::printf("%s VkResult=%d\n",phase,int(value));throw std::runtime_error(phase);}}
using MakeTexture=std::uint64_t(*)(std::uint32_t,std::uint32_t,const void*,std::size_t,std::size_t);
using DropTexture=void(*)(std::uint64_t);
using GetFont=ImFont*(*)(const char*);
struct Observe {unsigned calls{},textures{},generations{},font_calls{},insert_presses{};std::uint64_t generation=~0ULL,texture{};MakeTexture make{};DropTexture drop{};GetFont get_font{};std::vector<std::pair<std::string,std::string>> samples;};
LRESULT CALLBACK own_window_proc(HWND hwnd,UINT message,WPARAM w,LPARAM l){if(message==WM_APP+61)return 0x12345678;if(message==WM_KEYDOWN&&w==VK_F2)return 0x24681357;return DefWindowProcW(hwnd,message,w,l);}
void draw(void* user,const rs::platform::FrameContext& frame)noexcept {
    auto& s=*static_cast<Observe*>(user);++s.calls;
    auto* previous=ImGui::GetCurrentContext();ImGui::SetCurrentContext(frame.imgui);
    if(ImGui::IsKeyPressed(ImGuiKey_Insert,false))++s.insert_presses;
    if(s.calls==10){ImGui::GetIO().WantCaptureKeyboard=true;ImGui::GetIO().WantCaptureMouse=true;ImGui::SetCurrentContext(previous);return;}
    if(frame.texture_generation!=s.generation){s.generation=frame.texture_generation;s.texture=0;++s.generations;}
    if(!s.texture){constexpr std::array<std::uint32_t,4> pixels{0xFF0000FF,0xFF00FF00,0xFFFF0000,0xFFFFFFFF};s.texture=s.make(2,2,pixels.data(),sizeof(pixels),8);if(s.texture)++s.textures;}
    ImGui::SetNextWindowPos({40,40},ImGuiCond_Always);ImGui::SetNextWindowSize({280,180},ImGuiCond_Always);
    ImGui::Begin("ResourceScanner GPU fixture",nullptr,ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoInputs);
    ImGui::TextUnformatted("Own Vulkan/texture callback");
    if(!s.samples.empty()){auto& sample=s.samples[s.calls%s.samples.size()];auto* font=s.get_font(sample.first.c_str());if(font){ImGui::PushFont(font,16.f);ImGui::TextUnformatted(sample.second.c_str());ImGui::PopFont();++s.font_calls;}}
    if(s.texture)ImGui::Image(static_cast<ImTextureID>(s.texture),{96,96});ImGui::End();
    if(s.calls==4&&s.texture){s.drop(s.texture);s.texture=0;}
    ImGui::SetCurrentContext(previous);
}
struct Image {VkImage image{};VkImageView view{};VkFramebuffer framebuffer{};VkCommandBuffer command{};VkFence fence{};VkSemaphore acquired{},done{};};
}
int wmain(int argc,wchar_t** argv){
    if(argc!=2)return 2;
    SetErrorMode(SEM_FAILCRITICALERRORS|SEM_NOGPFAULTERRORBOX);
    try {
        // Match an executable that imports Vulkan before our asynchronous
        // loader worker starts. Do not insert an engine-initialization delay.
        wchar_t option[2]{};const bool proxy_mode=GetEnvironmentVariableW(L"RS_GPU_TEST_VULKAN_PROXY",option,2)!=0;
        const bool precreated=GetEnvironmentVariableW(L"RS_GPU_TEST_PRECREATED",option,2)!=0;
        const auto core_path=std::filesystem::absolute(argv[1]);
        const auto proxy_path=core_path.parent_path().parent_path()/L"vulkan-1.dll";
        auto loader=LoadLibraryExW(proxy_mode?proxy_path.c_str():L"vulkan-1.dll",nullptr,proxy_mode?(LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32):LOAD_LIBRARY_SEARCH_SYSTEM32);if(!loader)throw std::runtime_error("Vulkan loader unavailable");
        gipa=reinterpret_cast<PFN_vkGetInstanceProcAddr>(GetProcAddress(loader,"vkGetInstanceProcAddr"));if(!gipa)throw std::runtime_error("vkGetInstanceProcAddr");
        // Cache the creation PFN BEFORE the host loads/starts Core. With the
        // proxy this FIRST call must synchronously prepare Core on our behalf.
        auto cached_create=global<PFN_vkCreateInstance>("vkCreateInstance");
        if(proxy_mode&&!GetModuleHandleW(core_path.c_str()))throw std::runtime_error("First Vulkan API did not load Core");
        BOOL(*stop)(DWORD){};Observe observation{};
        std::ifstream font_file(std::filesystem::absolute(argv[1]).parent_path()/L"fonts/manifest.json");auto font_manifest=nlohmann::json::parse(font_file);
        for(auto& entry:font_manifest.at("fonts")){auto role=entry.at("role").get<std::string>();unsigned selected=65;
            const unsigned threshold=role=="western"?0x400u:role=="thai"?0xe000u:0x3400u;
            for(auto& range:entry.at("ranges")){auto cp=std::max(threshold,range.at(0).get<unsigned>());if(cp<=range.at(1).get<unsigned>()){selected=cp;break;}}
            std::string display;if(selected<0x80)display+=static_cast<char>(selected);else if(selected<0x800){display+=static_cast<char>(0xc0|(selected>>6));display+=static_cast<char>(0x80|(selected&63));}
            else{display+=static_cast<char>(0xe0|(selected>>12));display+=static_cast<char>(0x80|((selected>>6)&63));display+=static_cast<char>(0x80|(selected&63));}observation.samples.emplace_back(role,display);}
        auto initialize_core=[&](){
            auto core=LoadLibraryExW(core_path.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);if(!core)throw std::runtime_error("Load own core");
            auto start=reinterpret_cast<BOOL(*)()>(GetProcAddress(core,"ResourceScannerStart"));stop=reinterpret_cast<BOOL(*)(DWORD)>(GetProcAddress(core,"ResourceScannerStop"));
            auto set=reinterpret_cast<BOOL(*)(const rs::platform::RenderClient*)>(GetProcAddress(core,"ResourceScannerSetRenderClient"));
            if(!start||!stop||!set||!start())throw std::runtime_error("Own exports/start");
            observation.make=reinterpret_cast<MakeTexture>(GetProcAddress(core,"ResourceScannerCreateTextureRGBA"));observation.drop=reinterpret_cast<DropTexture>(GetProcAddress(core,"ResourceScannerDeferDestroyTexture"));
            observation.get_font=reinterpret_cast<GetFont>(GetProcAddress(core,"ResourceScannerFont"));if(!observation.make||!observation.drop||!observation.get_font)throw std::runtime_error("Texture/font exports");
            rs::platform::RenderClient client{};client.user=&observation;client.render=draw;if(!set(&client))throw std::runtime_error("Callback registration");};
        if(!precreated)initialize_core();
        if(!precreated&&!proxy_mode)cached_create=global<PFN_vkCreateInstance>("vkCreateInstance");
        wchar_t immediate[2]{};if(!GetEnvironmentVariableW(L"RS_GPU_TEST_NO_DELAY",immediate,2))Sleep(150);
        gipa=reinterpret_cast<PFN_vkGetInstanceProcAddr>(GetProcAddress(loader,"vkGetInstanceProcAddr"));if(!gipa)throw std::runtime_error("vkGetInstanceProcAddr");
        VkApplicationInfo application{VK_STRUCTURE_TYPE_APPLICATION_INFO};application.pApplicationName="ResourceScanner GPU fixture";application.apiVersion=VK_API_VERSION_1_0;
        const char* extensions[]{VK_KHR_SURFACE_EXTENSION_NAME,VK_KHR_WIN32_SURFACE_EXTENSION_NAME};
        VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};ici.pApplicationInfo=&application;ici.enabledExtensionCount=2;ici.ppEnabledExtensionNames=extensions;
        VkInstance auxiliary{},temporary{};
        if(GetEnvironmentVariableW(L"RS_GPU_TEST_DUMMY_INSTANCE",option,2)){
            check(cached_create(&ici,nullptr,&temporary),"Create first dummy instance");}
        if(GetEnvironmentVariableW(L"RS_GPU_TEST_TWO_INSTANCES",option,2))check(cached_create(&ici,nullptr,&auxiliary),"Create concurrently alive auxiliary instance");
        check(cached_create(&ici,nullptr,&instance),"Create instance");
        if(temporary){auto destroy=reinterpret_cast<PFN_vkDestroyInstance>(gipa(temporary,"vkDestroyInstance"));if(!destroy)throw std::runtime_error("Dummy instance destroy lookup");destroy(temporary,nullptr);temporary={};}
        if(gipa(instance,"vkResourceScannerUnsupportedFunction")!=nullptr)throw std::runtime_error("Unsupported GIPA name must remain NULL");
        WNDCLASSW wc{};wc.lpfnWndProc=own_window_proc;wc.hInstance=GetModuleHandleW(nullptr);wc.lpszClassName=L"ResourceScannerOwnGpuFixture";RegisterClassW(&wc);
        HWND window=CreateWindowExW(0,wc.lpszClassName,L"ResourceScanner fixture",WS_OVERLAPPEDWINDOW,0,0,800,600,nullptr,nullptr,wc.hInstance,nullptr);if(!window)throw std::runtime_error("Own hidden window");
        VkWin32SurfaceCreateInfoKHR surface_info{VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR};surface_info.hinstance=wc.hInstance;surface_info.hwnd=window;VkSurfaceKHR surface{};
        const bool device_first=GetEnvironmentVariableW(L"RS_GPU_TEST_DEVICE_BEFORE_SURFACE",option,2)!=0;
        auto make_surface=[&](){check(inst<PFN_vkCreateWin32SurfaceKHR>("vkCreateWin32SurfaceKHR")(instance,&surface_info,nullptr,&surface),"Own surface");};
        if(!device_first)make_surface();
        std::uint32_t count{};auto enumerate=inst<PFN_vkEnumeratePhysicalDevices>("vkEnumeratePhysicalDevices");check(enumerate(instance,&count,nullptr),"GPU count");if(!count)throw std::runtime_error("No Vulkan GPU");
        std::vector<VkPhysicalDevice> devices(count);check(enumerate(instance,&count,devices.data()),"GPU list");VkPhysicalDevice physical{};std::uint32_t family=~0u;
        for(auto gpu:devices){auto families=inst<PFN_vkGetPhysicalDeviceQueueFamilyProperties>("vkGetPhysicalDeviceQueueFamilyProperties");std::uint32_t n{};families(gpu,&n,nullptr);std::vector<VkQueueFamilyProperties> list(n);families(gpu,&n,list.data());
            for(std::uint32_t i=0;i<n;++i){VkBool32 supported=VK_TRUE;if(surface)check(inst<PFN_vkGetPhysicalDeviceSurfaceSupportKHR>("vkGetPhysicalDeviceSurfaceSupportKHR")(gpu,i,surface,&supported),"Queue present support");if((list[i].queueFlags&VK_QUEUE_GRAPHICS_BIT)&&supported){physical=gpu;family=i;break;}}if(physical)break;}
        if(!physical)throw std::runtime_error("No graphics/present queue");
        float priority=1;VkDeviceQueueCreateInfo q{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};q.queueFamilyIndex=family;q.queueCount=1;q.pQueuePriorities=&priority;
        const char* device_extensions[]{VK_KHR_SWAPCHAIN_EXTENSION_NAME};VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};dci.queueCreateInfoCount=1;dci.pQueueCreateInfos=&q;dci.enabledExtensionCount=1;dci.ppEnabledExtensionNames=device_extensions;
        check(inst<PFN_vkCreateDevice>("vkCreateDevice")(physical,&dci,nullptr,&device),"Create device");gdpa=inst<PFN_vkGetDeviceProcAddr>("vkGetDeviceProcAddr");
        if(device_first){make_surface();VkBool32 supported{};check(inst<PFN_vkGetPhysicalDeviceSurfaceSupportKHR>("vkGetPhysicalDeviceSurfaceSupportKHR")(physical,family,surface,&supported),"Late surface present support");if(!supported)throw std::runtime_error("Selected graphics family cannot present fixture surface");}
        if(!precreated&&reinterpret_cast<FARPROC>(gdpa)==GetProcAddress(loader,"vkGetDeviceProcAddr"))throw std::runtime_error("GIPA did not return our GDPA dispatch wrapper");
        if(gdpa(device,"vkResourceScannerUnsupportedFunction")!=nullptr)throw std::runtime_error("Unsupported GDPA name must remain NULL");
        wchar_t late_value[2]{};const bool late_queue=GetEnvironmentVariableW(L"RS_GPU_TEST_LATE_QUEUE",late_value,2)!=0;
        VkQueue queue{};if(!late_queue)dev<PFN_vkGetDeviceQueue>("vkGetDeviceQueue")(device,family,0,&queue);
        auto idle=dev<PFN_vkDeviceWaitIdle>("vkDeviceWaitIdle");
        for(unsigned cycle=0;cycle<2;++cycle){
            if(cycle&&auxiliary){reinterpret_cast<PFN_vkDestroyInstance>(gipa(auxiliary,"vkDestroyInstance"))(auxiliary,nullptr);auxiliary={};}
            if(cycle)SetWindowPos(window,nullptr,0,0,1024,768,SWP_NOACTIVATE|SWP_NOZORDER|SWP_NOMOVE);
            VkSurfaceCapabilitiesKHR caps{};check(inst<PFN_vkGetPhysicalDeviceSurfaceCapabilitiesKHR>("vkGetPhysicalDeviceSurfaceCapabilitiesKHR")(physical,surface,&caps),"Surface caps");
            std::uint32_t nf{};auto formats=inst<PFN_vkGetPhysicalDeviceSurfaceFormatsKHR>("vkGetPhysicalDeviceSurfaceFormatsKHR");check(formats(physical,surface,&nf,nullptr),"Format count");std::vector<VkSurfaceFormatKHR> choices(nf);check(formats(physical,surface,&nf,choices.data()),"Formats");auto format=choices.front();
            VkSwapchainCreateInfoKHR sci{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};sci.surface=surface;sci.minImageCount=std::max(2u,caps.minImageCount);if(caps.maxImageCount)sci.minImageCount=std::min(sci.minImageCount,caps.maxImageCount);
            sci.imageFormat=format.format;sci.imageColorSpace=format.colorSpace;sci.imageExtent=caps.currentExtent;if(sci.imageExtent.width==~0u)sci.imageExtent={800,600};sci.imageArrayLayers=1;sci.imageUsage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
            sci.imageSharingMode=VK_SHARING_MODE_EXCLUSIVE;sci.preTransform=caps.currentTransform;sci.compositeAlpha=VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;sci.presentMode=VK_PRESENT_MODE_FIFO_KHR;sci.clipped=VK_TRUE;
            VkSwapchainKHR swap{};check(dev<PFN_vkCreateSwapchainKHR>("vkCreateSwapchainKHR")(device,&sci,nullptr,&swap),"Create swapchain");
            if(!queue)dev<PFN_vkGetDeviceQueue>("vkGetDeviceQueue")(device,family,0,&queue);
            if(precreated&&cycle==0)initialize_core();
            if(SendMessageW(window,WM_APP+61,0,0)!=0x12345678)throw std::runtime_error("Original window procedure forwarding");
            std::uint32_t ni{};auto get_images=dev<PFN_vkGetSwapchainImagesKHR>("vkGetSwapchainImagesKHR");check(get_images(device,swap,&ni,nullptr),"Image count");std::vector<VkImage> handles(ni);check(get_images(device,swap,&ni,handles.data()),"Images");std::vector<Image> images(ni);
            VkAttachmentDescription attachment{};attachment.format=format.format;attachment.samples=VK_SAMPLE_COUNT_1_BIT;attachment.loadOp=VK_ATTACHMENT_LOAD_OP_CLEAR;attachment.storeOp=VK_ATTACHMENT_STORE_OP_STORE;attachment.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED;attachment.finalLayout=VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
            VkAttachmentReference reference{0,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};VkSubpassDescription sub{};sub.pipelineBindPoint=VK_PIPELINE_BIND_POINT_GRAPHICS;sub.colorAttachmentCount=1;sub.pColorAttachments=&reference;
            VkRenderPassCreateInfo rp{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};rp.attachmentCount=1;rp.pAttachments=&attachment;rp.subpassCount=1;rp.pSubpasses=&sub;VkRenderPass pass{};check(dev<PFN_vkCreateRenderPass>("vkCreateRenderPass")(device,&rp,nullptr,&pass),"Own renderpass");
            VkCommandPoolCreateInfo pci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};pci.queueFamilyIndex=family;pci.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;VkCommandPool pool{};check(dev<PFN_vkCreateCommandPool>("vkCreateCommandPool")(device,&pci,nullptr,&pool),"Own command pool");
            for(std::uint32_t i=0;i<ni;++i){auto& f=images[i];f.image=handles[i];VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};vi.image=f.image;vi.viewType=VK_IMAGE_VIEW_TYPE_2D;vi.format=format.format;vi.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};check(dev<PFN_vkCreateImageView>("vkCreateImageView")(device,&vi,nullptr,&f.view),"Own view");
                VkFramebufferCreateInfo fb{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};fb.renderPass=pass;fb.attachmentCount=1;fb.pAttachments=&f.view;fb.width=sci.imageExtent.width;fb.height=sci.imageExtent.height;fb.layers=1;check(dev<PFN_vkCreateFramebuffer>("vkCreateFramebuffer")(device,&fb,nullptr,&f.framebuffer),"Own framebuffer");
                VkCommandBufferAllocateInfo alloc{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};alloc.commandPool=pool;alloc.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;alloc.commandBufferCount=1;check(dev<PFN_vkAllocateCommandBuffers>("vkAllocateCommandBuffers")(device,&alloc,&f.command),"Own command buffer");
                VkFenceCreateInfo fence{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};fence.flags=VK_FENCE_CREATE_SIGNALED_BIT;check(dev<PFN_vkCreateFence>("vkCreateFence")(device,&fence,nullptr,&f.fence),"Own fence");VkSemaphoreCreateInfo sem{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};check(dev<PFN_vkCreateSemaphore>("vkCreateSemaphore")(device,&sem,nullptr,&f.acquired),"Own acquire semaphore");check(dev<PFN_vkCreateSemaphore>("vkCreateSemaphore")(device,&sem,nullptr,&f.done),"Own draw semaphore");}
            VkSemaphore acquire{};VkSemaphoreCreateInfo sem{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};check(dev<PFN_vkCreateSemaphore>("vkCreateSemaphore")(device,&sem,nullptr,&acquire),"Acquire semaphore");
            for(unsigned iteration=0;iteration<12;++iteration){MSG message{};while(PeekMessageW(&message,window,0,0,PM_REMOVE)){TranslateMessage(&message);DispatchMessageW(&message);}
                if(cycle==0&&(iteration==1||iteration==5))SendMessageW(window,WM_KEYDOWN,VK_INSERT,1);
                std::uint32_t index{};check(dev<PFN_vkAcquireNextImageKHR>("vkAcquireNextImageKHR")(device,swap,2000000000ULL,acquire,VK_NULL_HANDLE,&index),"Acquire");auto& f=images[index];
                check(dev<PFN_vkWaitForFences>("vkWaitForFences")(device,1,&f.fence,VK_TRUE,2000000000ULL),"Own fence wait");check(dev<PFN_vkResetFences>("vkResetFences")(device,1,&f.fence),"Own fence reset");check(dev<PFN_vkResetCommandBuffer>("vkResetCommandBuffer")(f.command,0),"Own cmd reset");
                VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};check(dev<PFN_vkBeginCommandBuffer>("vkBeginCommandBuffer")(f.command,&begin),"Own cmd begin");VkClearValue clear{};clear.color={{.08f,.10f,.12f,1.f}};
                VkRenderPassBeginInfo pb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};pb.renderPass=pass;pb.framebuffer=f.framebuffer;pb.renderArea.extent=sci.imageExtent;pb.clearValueCount=1;pb.pClearValues=&clear;
                dev<PFN_vkCmdBeginRenderPass>("vkCmdBeginRenderPass")(f.command,&pb,VK_SUBPASS_CONTENTS_INLINE);dev<PFN_vkCmdEndRenderPass>("vkCmdEndRenderPass")(f.command);check(dev<PFN_vkEndCommandBuffer>("vkEndCommandBuffer")(f.command),"Own cmd end");
                VkPipelineStageFlags stage=VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};submit.waitSemaphoreCount=1;submit.pWaitSemaphores=&acquire;submit.pWaitDstStageMask=&stage;submit.commandBufferCount=1;submit.pCommandBuffers=&f.command;submit.signalSemaphoreCount=1;submit.pSignalSemaphores=&f.done;
                check(dev<PFN_vkQueueSubmit>("vkQueueSubmit")(queue,1,&submit,f.fence),"Own submit");VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};pi.waitSemaphoreCount=1;pi.pWaitSemaphores=&f.done;pi.swapchainCount=1;pi.pSwapchains=&swap;pi.pImageIndices=&index;
                check(dev<PFN_vkQueuePresentKHR>("vkQueuePresentKHR")(queue,&pi),"Own present");check(idle(device),"Own idle");
                if(cycle==0&&(iteration==1||iteration==5))SendMessageW(window,WM_KEYUP,VK_INSERT,1);
                if(cycle==0&&iteration==9&&SendMessageW(window,WM_KEYDOWN,VK_F2,1)!=0x24681357)throw std::runtime_error("Hidden UI stale capture swallowed unrelated input");}
            check(idle(device),"Before resize");
            for(auto& f:images){dev<PFN_vkDestroyFence>("vkDestroyFence")(device,f.fence,nullptr);dev<PFN_vkDestroySemaphore>("vkDestroySemaphore")(device,f.acquired,nullptr);dev<PFN_vkDestroySemaphore>("vkDestroySemaphore")(device,f.done,nullptr);dev<PFN_vkDestroyFramebuffer>("vkDestroyFramebuffer")(device,f.framebuffer,nullptr);dev<PFN_vkDestroyImageView>("vkDestroyImageView")(device,f.view,nullptr);}
            dev<PFN_vkDestroySemaphore>("vkDestroySemaphore")(device,acquire,nullptr);dev<PFN_vkDestroyCommandPool>("vkDestroyCommandPool")(device,pool,nullptr);dev<PFN_vkDestroyRenderPass>("vkDestroyRenderPass")(device,pass,nullptr);dev<PFN_vkDestroySwapchainKHR>("vkDestroySwapchainKHR")(device,swap,nullptr);
        }
        check(idle(device),"Final idle");if(!stop(5000))throw std::runtime_error("Own core stop");
        if(reinterpret_cast<WNDPROC>(GetWindowLongPtrW(window,GWLP_WNDPROC))!=own_window_proc)throw std::runtime_error("Window procedure restoration");
        dev<PFN_vkDestroyDevice>("vkDestroyDevice")(device,nullptr);inst<PFN_vkDestroySurfaceKHR>("vkDestroySurfaceKHR")(instance,surface,nullptr);inst<PFN_vkDestroyInstance>("vkDestroyInstance")(instance,nullptr);DestroyWindow(window);
        if(precreated){if(observation.calls)return 3;std::puts("PASS negative: Vulkan objects cached/created BEFORE asynchronous Core startup produce zero overlay callbacks without first-call barrier");return 0;}
        if(observation.calls!=24||observation.textures<3||observation.generations!=2||observation.font_calls!=23||observation.insert_presses!=2){
            std::printf("observed callbacks=%u fonts=%u insert=%u\n",observation.calls,observation.font_calls,observation.insert_presses);throw std::runtime_error("Overlay/input route not exercised");}
        std::printf("PASS hidden OWN Vulkan host: %u callbacks,%u uploads,%u swapchain generations,%u six-role font draws,%u Insert presses,hidden input forwarding,deferred destroy/resize/stop,GIPA-to-GDPA-wrapper,late_queue=%u,first_call_proxy=%u\n",observation.calls,observation.textures,observation.generations,observation.font_calls,observation.insert_presses,unsigned(late_queue),unsigned(proxy_mode));return 0;
    }catch(const std::exception& e){std::printf("FAIL %s\n",e.what());return 1;}
}
