#include "internal.hpp"
#include <rs/platform/render.hpp>
#include <rs/platform/texture.hpp>
#include <rs/game/ipc.hpp>
#include <rs/platform/helper.hpp>
#include <imgui.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <exception>
int main(){
    using namespace rs;
    platform::RenderClient invalid{};invalid.version=2;if(platform::set_render_client(invalid))return 1;
    unsigned calls{};platform::RenderClient client{};client.user=&calls;
    client.render=[](void* user,const platform::FrameContext& frame)noexcept{
        ++*static_cast<unsigned*>(user);ImGui::Begin("Independent callback");ImGui::TextUnformatted("ResourceScanner");ImGui::End();
        if(frame.framebuffer_width!=800)std::terminate();};
    if(!platform::set_render_client(client))return 2;
    auto* context=ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize={800,600};io.DeltaTime=1.f/60;
    io.BackendFlags|=ImGuiBackendFlags_RendererHasTextures;
    unsigned char* pixels{};int width{},height{};io.Fonts->GetTexDataAsRGBA32(&pixels,&width,&height);
    ImGui::NewFrame();platform::FrameContext frame{};frame.imgui=context;frame.framebuffer_width=800;frame.framebuffer_height=600;
    auto current=platform::detail::client();current.render(current.user,frame);ImGui::Render();
    if(calls!=1||!ImGui::GetDrawData())return 3;
    if(platform::create_texture_rgba(1,1,pixels,4)!=0)return 4;
    game::Frame f{};f.sequence=42;f.sampled_at_ms=GetTickCount64();f.native_language_id=9;
    platform::detail::publish(f);
    auto name=L"Local\\ResourceScanner.Frame.v1."+std::to_wstring(GetCurrentProcessId());
    auto mapping=OpenFileMappingW(FILE_MAP_READ,FALSE,name.c_str());if(!mapping)return 5;
    auto* view=static_cast<const game::ipc::Snapshot*>(MapViewOfFile(mapping,FILE_MAP_READ,0,0,256));
    if(!view||std::memcmp(view->header.magic,game::ipc::magic,8)||view->header.generation%2||view->payload.sequence!=42||view->payload.native_language_id!=9)return 6;
    UnmapViewOfFile(view);CloseHandle(mapping);platform::detail::close_publication();
    if(!platform::start()||!platform::start()||!platform::stop(2000)||!platform::stop(2000))return 7;
    if(!platform::start()||!platform::stop(2000))return 8;
    platform::HelperProcess helper;platform::HelperOptions options{L"rs_helper_exit_fixture.exe",L"rs_helper_exit_fixture.exe",GetCurrentProcessId(),platform::detail::process_birth()};
    // These candidate files DO exist in this fixture's CWD. A relative-root
    // implementation would actually start the inert child and fail the test.
    if(helper.start(L"",options)||helper.start(L".",options)||helper.start(L"relative-folder",options))return 9;
    ImGui::DestroyContext(context);std::puts("PASS own callback/IPC/invalid texture/lifecycle");return 0;
}
