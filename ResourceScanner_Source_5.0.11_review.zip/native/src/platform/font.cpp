#include <rs/platform/font.hpp>
#include <rs/platform/paths.hpp>
#include <windows.h>
#include <bcrypt.h>
#include <imgui.h>
#include <nlohmann/json.hpp>
#include <fstream>
#include <map>
#include <vector>
#include <string>
#include <array>
#include <cstring>
namespace rs::platform {
namespace {
std::map<std::string,ImFont*,std::less<>> profiles;
std::map<std::string,std::vector<ImWchar>,std::less<>> ranges;
std::vector<std::uint8_t> read_file(const std::filesystem::path& path,std::size_t maximum){
    std::ifstream in(path,std::ios::binary|std::ios::ate);if(!in)return {};auto n=in.tellg();
    if(n<=0||static_cast<std::uint64_t>(n)>maximum)return {};std::vector<std::uint8_t> bytes(static_cast<std::size_t>(n));
    in.seekg(0);if(!in.read(reinterpret_cast<char*>(bytes.data()),n))return {};return bytes;
}
std::string sha256(const std::vector<std::uint8_t>& input){
    BCRYPT_ALG_HANDLE algorithm{};BCRYPT_HASH_HANDLE hash{};std::array<std::uint8_t,32> digest{};
    if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)return {};
    DWORD size{},returned{};BCryptGetProperty(algorithm,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&size),4,&returned,0);
    std::vector<std::uint8_t> object(size);bool ok=BCryptCreateHash(algorithm,&hash,object.data(),size,nullptr,0,0)>=0;
    if(ok)ok=BCryptHashData(hash,const_cast<PUCHAR>(input.data()),static_cast<ULONG>(input.size()),0)>=0&&BCryptFinishHash(hash,digest.data(),32,0)>=0;
    if(hash)BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(algorithm,0);if(!ok)return {};
    constexpr char digits[]="0123456789abcdef";std::string text;for(auto b:digest){text+=digits[b>>4];text+=digits[b&15];}return text;
}
ImFont* add(ImFontAtlas* atlas,const std::vector<std::uint8_t>& bytes,const std::vector<ImWchar>& glyph_ranges,bool merge,const char* name){
    if(bytes.empty())return nullptr;void* copy=ImGui::MemAlloc(bytes.size());if(!copy)return nullptr;std::memcpy(copy,bytes.data(),bytes.size());
    ImFontConfig config{};config.MergeMode=merge;config.SizePixels=16.f;config.FontDataOwnedByAtlas=true;
    // Exclude script glyphs from an installed Western base so matching regional
    // Noto faces, and Thai context-composites, own their glyphs on each profile.
    static constexpr ImWchar excluded[]{0x0E00,0x0E7F,0x1100,0x11FF,0x2E80,0x9FFF,0xAC00,0xD7FF,0xE000,0xF8FF,0xF900,0xFFFF,0};
    if(!merge)config.GlyphExcludeRanges=excluded;
    std::strncpy(config.Name,name,sizeof(config.Name)-1);
    return atlas->AddFontFromMemoryTTF(copy,static_cast<int>(bytes.size()),16.f,&config,glyph_ranges.data());
}
}
ImFont* font(std::string_view role)noexcept{auto it=profiles.find(role);if(it!=profiles.end())return it->second;
    auto western=profiles.find("western");return western==profiles.end()?nullptr:western->second;}
bool font_available(std::string_view role)noexcept{return profiles.find(role)!=profiles.end();}
void forget_fonts()noexcept{profiles.clear();ranges.clear();}
bool initialize_fonts(ImFontAtlas* atlas,const std::filesystem::path& root)noexcept {
    forget_fonts();if(!atlas)return false;
    try {
        auto manifest_bytes=read_file(root/L"manifest.json",1024*1024);if(manifest_bytes.empty())return false;
        auto manifest=nlohmann::json::parse(manifest_bytes.begin(),manifest_bytes.end());
        const auto& definitions=manifest.at("fonts");if(!definitions.is_array()||definitions.size()!=6)return false;
        std::map<std::string,std::vector<std::uint8_t>,std::less<>> assets;
        for(const auto& definition:definitions){auto role=definition.at("role").get<std::string>();auto file=definition.at("file").get<std::string>();
            if(role!="western"&&role!="cjk-jp"&&role!="cjk-kr"&&role!="cjk-sc"&&role!="cjk-tc"&&role!="thai")return false;
            if(assets.contains(role)||file.empty()||std::filesystem::path(file).filename()!=std::filesystem::path(file))return false;
            auto bytes=read_file(root/file,4*1024*1024);if(bytes.size()!=definition.at("bytes").get<std::size_t>()||sha256(bytes)!=definition.at("sha256").get<std::string>())return false;
            auto& target=ranges[role];for(const auto& pair:definition.at("ranges")){
                auto first=pair.at(0).get<unsigned>(),last=pair.at(1).get<unsigned>();if(!first||last<first||last>0xFFFF||(!target.empty()&&first<=target.back()))return false;
                target.push_back(static_cast<ImWchar>(first));target.push_back(static_cast<ImWchar>(last));}
            target.push_back(0);assets.emplace(role,std::move(bytes));
        }
        std::vector<std::uint8_t> western;wchar_t windows[32768]{};auto n=GetWindowsDirectoryW(windows,32768);
        if(n&&n<32768)western=read_file(std::filesystem::path(windows)/L"Fonts/segoeui.ttf",8*1024*1024);
        if(western.empty())western=assets.at("western");
        for(const auto* role:{"western","cjk-jp","cjk-kr","cjk-sc","cjk-tc","thai"}){
            auto* destination=add(atlas,western,ranges.at("western"),false,role);if(!destination)return false;
            if(std::string_view(role)!="western"&&!add(atlas,assets.at(role),ranges.at(role),true,role))return false;
            profiles.emplace(role,destination);
        }
        return true;
    }catch(...){forget_fonts();return false;}
}
}
