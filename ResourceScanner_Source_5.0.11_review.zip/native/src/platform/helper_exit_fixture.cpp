// Inert child used only to detect an unintended CWD fallback in a regression.
int main(){return 0;}
