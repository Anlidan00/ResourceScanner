#include "internal.hpp"
#include <rs/game/ipc.hpp>
#include <cstring>
#include <string>
#include <mutex>
namespace rs::platform {
namespace {std::uint64_t nonce() noexcept {static const std::uint64_t value=[](){LARGE_INTEGER q{};QueryPerformanceCounter(&q);auto result=std::uint64_t(q.QuadPart)^detail::process_birth();return result?result:std::uint64_t{1};}();return value;}}
std::uint64_t instance_nonce()noexcept{return nonce();}
namespace detail {
namespace { HANDLE mapping{};game::ipc::Snapshot* view{};std::mutex mutex;std::uint64_t generation{}; }
std::uint64_t process_birth() noexcept {
    FILETIME c{},e{},k{},u{};if(!GetProcessTimes(GetCurrentProcess(),&c,&e,&k,&u))return 0;
    return std::uint64_t(c.dwLowDateTime)|(std::uint64_t(c.dwHighDateTime)<<32);
}
void publish(const game::Frame& frame) noexcept {
    try { std::lock_guard lock(mutex);
        if(!view) {
            auto name=L"Local\\ResourceScanner.Frame.v1."+std::to_wstring(GetCurrentProcessId());
            mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,sizeof(game::ipc::Snapshot),name.c_str());
            if(!mapping)return;
            // Never adopt another publisher's same-name mapping.
            if(GetLastError()==ERROR_ALREADY_EXISTS){CloseHandle(mapping);mapping=nullptr;return;}
            view=static_cast<game::ipc::Snapshot*>(MapViewOfFile(mapping,FILE_MAP_WRITE,0,0,sizeof(*view)));
            if(!view){CloseHandle(mapping);mapping=nullptr;return;}
            std::memset(view,0,sizeof(*view));std::memcpy(view->header.magic,game::ipc::magic,8);
            view->header.version=1;view->header.header_bytes=64;view->header.payload_bytes=192;
            view->header.total_bytes=256;view->header.process_id=GetCurrentProcessId();
            view->header.process_creation_time=process_birth();
            view->header.instance_nonce=nonce();
        }
        InterlockedExchange64(reinterpret_cast<volatile LONG64*>(&view->header.generation),++generation);
        game::ipc::Payload p{};p.sequence=frame.sequence;p.sampled_at_ms=frame.sampled_at_ms;
        p.process_id=GetCurrentProcessId();p.process_creation_time=process_birth();p.availability=static_cast<unsigned>(frame.source);
        p.native_language_id=frame.native_language_id;p.flags=(frame.map_open?1u:0u)|(frame.projection_ready?2u:0u)|
            (frame.hud_bounds_ready?4u:0u)|(frame.world_ready?8u:0u);
        p.world_center_x=frame.projection.world_center.x;p.world_center_z=frame.projection.world_center.y;
        p.screen_center_x=frame.projection.screen_center.x;p.screen_center_y=frame.projection.screen_center.y;
        p.pixels_per_world_unit=frame.projection.pixels_per_world_unit;
        const auto& s=frame.projection.screen_bounds;const auto& c=frame.map_content;
        p.screen_left=s.left;p.screen_top=s.top;p.screen_right=s.right;p.screen_bottom=s.bottom;
        p.content_left=c.left;p.content_top=c.top;p.content_right=c.right;p.content_bottom=c.bottom;
        p.application_address=frame.application_address;p.ui_address=frame.ui_address;p.map_state_address=frame.map_state_address;
        p.scope_start_sequence=frame.scope_start_sequence;
        std::memcpy(p.world_guid,frame.world_guid.data(),16);std::memcpy(p.hero_guid,frame.hero_guid.data(),16);
        std::memcpy(&view->payload,&p,sizeof(p));MemoryBarrier();
        InterlockedExchange64(reinterpret_cast<volatile LONG64*>(&view->header.generation),++generation);
    } catch(...) {}
}
void close_publication() noexcept {std::lock_guard lock(mutex);if(view)UnmapViewOfFile(view);if(mapping)CloseHandle(mapping);view=nullptr;mapping=nullptr;generation=0;}
}
}
