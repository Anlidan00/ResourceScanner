#pragma once
// Synthetic layers own deliberately opaque, non-dereferenceable handles.
namespace layer_fixture {
using namespace rs::platform;
inline VkInstance ia=reinterpret_cast<VkInstance>(0x10101010ULL),ib=reinterpret_cast<VkInstance>(0x20202020ULL),dummy=reinterpret_cast<VkInstance>(0x30303030ULL);
inline VkPhysicalDevice pa=reinterpret_cast<VkPhysicalDevice>(0x11111111ULL),pb=reinterpret_cast<VkPhysicalDevice>(0x22222222ULL);
inline VkDevice da=reinterpret_cast<VkDevice>(0x41414141ULL),db=reinterpret_cast<VkDevice>(0x42424242ULL),inner=reinterpret_cast<VkDevice>(0x43434343ULL);
inline VkQueue qa=reinterpret_cast<VkQueue>(0x51515151ULL),qb=reinterpret_cast<VkQueue>(0x52525252ULL);
inline VkSurfaceKHR sa=reinterpret_cast<VkSurfaceKHR>(0x61616161ULL),sb=reinterpret_cast<VkSurfaceKHR>(0x62626262ULL);
inline unsigned wrong{},calls_a{},calls_b{},inner_calls{};
inline VkResult VKAPI_CALL create_dummy(const VkInstanceCreateInfo*,const VkAllocationCallbacks*,VkInstance* o){*o=dummy;return VK_SUCCESS;}
inline VkResult VKAPI_CALL create_a(const VkInstanceCreateInfo*,const VkAllocationCallbacks*,VkInstance* o){*o=ia;return VK_SUCCESS;}
inline VkResult VKAPI_CALL create_b(const VkInstanceCreateInfo*,const VkAllocationCallbacks*,VkInstance* o){*o=ib;return VK_SUCCESS;}
inline void VKAPI_CALL destroy_i(VkInstance,const VkAllocationCallbacks*){}
inline VkResult VKAPI_CALL system_create(VkPhysicalDevice,const VkDeviceCreateInfo*,const VkAllocationCallbacks*,VkDevice* o){++inner_calls;*o=inner;return VK_SUCCESS;}
inline VkResult VKAPI_CALL device_a(VkPhysicalDevice p,const VkDeviceCreateInfo* i,const VkAllocationCallbacks* a,VkDevice* o){if(p!=pa)++wrong;VkDevice nested{};hook_create_device(p,i,a,&nested);if(nested!=inner)++wrong;*o=da;++calls_a;return VK_SUCCESS;}
inline VkResult VKAPI_CALL device_b(VkPhysicalDevice p,const VkDeviceCreateInfo*,const VkAllocationCallbacks*,VkDevice* o){if(p!=pb)++wrong;*o=db;++calls_b;return VK_SUCCESS;}
inline VkResult VKAPI_CALL enum_a(VkInstance i,std::uint32_t* n,VkPhysicalDevice* p){if(i!=ia)++wrong;*n=1;if(p)*p=pa;return VK_SUCCESS;}
inline VkResult VKAPI_CALL enum_b(VkInstance i,std::uint32_t* n,VkPhysicalDevice* p){if(i!=ib)++wrong;*n=1;if(p)*p=pb;return VK_SUCCESS;}
inline void VKAPI_CALL props_a(VkPhysicalDevice p,std::uint32_t* n,VkQueueFamilyProperties* out){if(p!=pa)++wrong;*n=1;if(out)out[0].queueFlags=VK_QUEUE_GRAPHICS_BIT;}
inline void VKAPI_CALL props_b(VkPhysicalDevice p,std::uint32_t* n,VkQueueFamilyProperties* out){if(p!=pb)++wrong;*n=1;if(out)out[0].queueFlags=VK_QUEUE_GRAPHICS_BIT;}
inline void VKAPI_CALL queue_a(VkDevice d,std::uint32_t,std::uint32_t,VkQueue* q){if(d!=da)++wrong;*q=qa;++calls_a;}
inline void VKAPI_CALL queue_b(VkDevice d,std::uint32_t,std::uint32_t,VkQueue* q){if(d!=db)++wrong;*q=qb;++calls_b;}
inline VkResult VKAPI_CALL idle_a(VkDevice d){if(d!=da)++wrong;++calls_a;return VK_SUCCESS;}
inline VkResult VKAPI_CALL idle_b(VkDevice d){if(d!=db)++wrong;++calls_b;return VK_SUCCESS;}
inline VkResult VKAPI_CALL surface_a(VkInstance i,const VkWin32SurfaceCreateInfoKHR*,const VkAllocationCallbacks*,VkSurfaceKHR* s){if(i!=ia)++wrong;*s=sa;return VK_SUCCESS;}
inline VkResult VKAPI_CALL surface_b(VkInstance i,const VkWin32SurfaceCreateInfoKHR*,const VkAllocationCallbacks*,VkSurfaceKHR* s){if(i!=ib)++wrong;*s=sb;return VK_SUCCESS;}
inline PFN_vkVoidFunction VKAPI_CALL gdpa_a(VkDevice d,const char* n){if(d!=da)++wrong;if(!std::strcmp(n,"vkGetDeviceQueue"))return reinterpret_cast<PFN_vkVoidFunction>(queue_a);if(!std::strcmp(n,"vkDeviceWaitIdle"))return reinterpret_cast<PFN_vkVoidFunction>(idle_a);return nullptr;}
inline PFN_vkVoidFunction VKAPI_CALL gdpa_b(VkDevice d,const char* n){if(d!=db)++wrong;if(!std::strcmp(n,"vkGetDeviceQueue"))return reinterpret_cast<PFN_vkVoidFunction>(queue_b);if(!std::strcmp(n,"vkDeviceWaitIdle"))return reinterpret_cast<PFN_vkVoidFunction>(idle_b);return nullptr;}
inline PFN_vkVoidFunction VKAPI_CALL system_gipa(VkInstance,const char*){++wrong;return nullptr;}
inline PFN_vkVoidFunction VKAPI_CALL system_gdpa(VkDevice,const char*){++wrong;return nullptr;}
inline PFN_vkVoidFunction VKAPI_CALL gipa_a(VkInstance i,const char* n){
    if(i!=ia)++wrong;
    if(!std::strcmp(n,"vkGetDeviceProcAddr"))return reinterpret_cast<PFN_vkVoidFunction>(gdpa_a);
    if(!std::strcmp(n,"vkCreateDevice"))return reinterpret_cast<PFN_vkVoidFunction>(device_a);
    if(!std::strcmp(n,"vkEnumeratePhysicalDevices"))return reinterpret_cast<PFN_vkVoidFunction>(enum_a);
    if(!std::strcmp(n,"vkGetPhysicalDeviceQueueFamilyProperties"))return reinterpret_cast<PFN_vkVoidFunction>(props_a);
    if(!std::strcmp(n,"vkCreateWin32SurfaceKHR"))return reinterpret_cast<PFN_vkVoidFunction>(surface_a);
    return nullptr;
}
inline PFN_vkVoidFunction VKAPI_CALL gipa_b(VkInstance i,const char* n){
    if(i!=ib)++wrong;
    if(!std::strcmp(n,"vkGetDeviceProcAddr"))return reinterpret_cast<PFN_vkVoidFunction>(gdpa_b);
    if(!std::strcmp(n,"vkCreateDevice"))return reinterpret_cast<PFN_vkVoidFunction>(device_b);
    if(!std::strcmp(n,"vkEnumeratePhysicalDevices"))return reinterpret_cast<PFN_vkVoidFunction>(enum_b);
    if(!std::strcmp(n,"vkGetPhysicalDeviceQueueFamilyProperties"))return reinterpret_cast<PFN_vkVoidFunction>(props_b);
    if(!std::strcmp(n,"vkCreateWin32SurfaceKHR"))return reinterpret_cast<PFN_vkVoidFunction>(surface_b);
    return nullptr;
}
inline int run(){
    gipa=system_gipa;gdpa=system_gdpa;create_device=system_create;
    const DispatchOrigin oa{gipa_a},ob{gipa_b};VkInstance out{};
    invoke_create_instance({reinterpret_cast<PFN_vkVoidFunction>(create_dummy),oa},nullptr,nullptr,&out);
    if(!owner_instance(dummy))return 10;invoke_destroy_instance({reinterpret_cast<PFN_vkVoidFunction>(destroy_i),oa},dummy,nullptr);
    if(owner_instance(dummy)||instance==dummy)return 11;
    invoke_create_instance({reinterpret_cast<PFN_vkVoidFunction>(create_a),oa},nullptr,nullptr,&out);
    invoke_create_instance({reinterpret_cast<PFN_vkVoidFunction>(create_b),ob},nullptr,nullptr,&out);
    Dispatch ga{reinterpret_cast<PFN_vkVoidFunction>(gipa_a),oa},gb{reinterpret_cast<PFN_vkVoidFunction>(gipa_b),ob};
    auto ea=reinterpret_cast<PFN_vkEnumeratePhysicalDevices>(invoke_gipa(ga,ia,"vkEnumeratePhysicalDevices"));auto eb=reinterpret_cast<PFN_vkEnumeratePhysicalDevices>(invoke_gipa(gb,ib,"vkEnumeratePhysicalDevices"));
    std::uint32_t count=1;VkPhysicalDevice gpu{};ea(ia,&count,&gpu);eb(ib,&count,&gpu);
    auto ca=reinterpret_cast<PFN_vkCreateDevice>(invoke_gipa(ga,ia,"vkCreateDevice"));auto cb=reinterpret_cast<PFN_vkCreateDevice>(invoke_gipa(gb,ib,"vkCreateDevice"));
    VkDevice d{};ca(pa,nullptr,nullptr,&d);cb(pb,nullptr,nullptr,&d);
    if(!owner_device(da)||!owner_device(db)||owner_device(inner)||inner_calls!=1)return 12;
    auto ra=reinterpret_cast<PFN_vkGetDeviceProcAddr>(invoke_gipa(ga,ia,"vkGetDeviceProcAddr"));auto rb=reinterpret_cast<PFN_vkGetDeviceProcAddr>(invoke_gipa(gb,ib,"vkGetDeviceProcAddr"));
    if(ra==rb||ra(da,"vkUnknown")||rb(db,"vkUnknown"))return 13;
    auto qfa=reinterpret_cast<PFN_vkGetDeviceQueue>(ra(da,"vkGetDeviceQueue"));auto qfb=reinterpret_cast<PFN_vkGetDeviceQueue>(rb(db,"vkGetDeviceQueue"));VkQueue q{};
    qfb(db,0,0,&q);if(q!=qb)return 14;qfa(da,0,0,&q);if(q!=qa)return 15;
    if(device_function(owner_device(da)->origin,"vkDeviceWaitIdle")!=reinterpret_cast<PFN_vkVoidFunction>(idle_a)||device_function(owner_device(db)->origin,"vkDeviceWaitIdle")!=reinterpret_cast<PFN_vkVoidFunction>(idle_b))return 16;
    VkWin32SurfaceCreateInfoKHR info{VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR};VkSurfaceKHR s{};
    reinterpret_cast<PFN_vkCreateWin32SurfaceKHR>(invoke_gipa(ga,ia,"vkCreateWin32SurfaceKHR"))(ia,&info,nullptr,&s);
    reinterpret_cast<PFN_vkCreateWin32SurfaceKHR>(invoke_gipa(gb,ib,"vkCreateWin32SurfaceKHR"))(ib,&info,nullptr,&s);
    if(adopt_swapchain_owner(da,sb)||!adopt_swapchain_owner(da,sa)||active_origin.device_proc!=gdpa_a||instance!=ia)return 17;
    invoke_destroy_instance({reinterpret_cast<PFN_vkVoidFunction>(destroy_i),oa},ia,nullptr);
    if(owner_instance(ia)||owner_device(da)||owner_physical(pa)||owner_surface(sa)||!owner_device(db))return 18;
    if(!adopt_swapchain_owner(db,sb)||active_origin.device_proc!=gdpa_b||instance!=ib||graphics_queue!=qb)return 19;
    invoke_destroy_instance({reinterpret_cast<PFN_vkVoidFunction>(destroy_i),ob},ib,nullptr);
    if(wrong||!calls_a||!calls_b||device||instance)return 20;
    std::puts("PASS two distinct layer resolvers/opaque owners, immutable cached PFNs, nested inner-handle suppression, physical-instance binding, destroyed dummy and per-context retirement");return 0;
}
}
