#include <rs/platform/helper.hpp>
#include <windows.h>
#include <filesystem>
#include <string>
namespace rs::platform {
namespace {
bool relative_safe(const std::wstring& value) {
    const std::filesystem::path p(value);
    if(p.empty()||p.is_absolute()||p.has_root_name()||p.has_root_directory())return false;
    for(const auto& part:p)if(part==L"..")return false;
    return value.find(L'"')==std::wstring::npos;
}
std::wstring quote(const std::wstring& s) {
    // Paths validated above contain no quotes; preserve trailing backslashes.
    std::wstring result=L"\"";unsigned slashes=0;
    for(wchar_t c:s) {if(c==L'\\'){++slashes;continue;}
        result.append(slashes,L'\\');slashes=0;result+=c;}
    result.append(slashes*2,L'\\');return result+L"\"";
}
}
HelperProcess::~HelperProcess(){close_handles();}
void HelperProcess::close_handles() noexcept {
    if(thread_)CloseHandle(thread_);if(process_)CloseHandle(process_);
    process_=thread_=nullptr;process_id_=0;
}
std::uint32_t HelperProcess::process_id()const noexcept{return process_id_;}
bool HelperProcess::wait_exit(std::uint32_t timeout)const noexcept{return !process_||WaitForSingleObject(process_,timeout)==WAIT_OBJECT_0;}
bool HelperProcess::start(const std::wstring& root,const HelperOptions& options) noexcept {
    try {
        const std::filesystem::path supplied_root(root);
        if(supplied_root.empty()||!supplied_root.is_absolute())return false;
        if(process_&&wait_exit(0))close_handles();
        if(process_||!relative_safe(options.relative_executable)||!relative_safe(options.relative_script)
           || !options.parent_process_id || !options.parent_creation_time)return false;
        auto base=std::filesystem::weakly_canonical(root);
        auto exe=std::filesystem::weakly_canonical(base/options.relative_executable);
        auto script=std::filesystem::weakly_canonical(base/options.relative_script);
        auto within=[&](const std::filesystem::path& target){auto relative=target.lexically_relative(base);
            return !relative.empty()&&!relative.is_absolute()&&*relative.begin()!=L"..";};
        if(!within(exe)||!within(script))return false;
        if(!std::filesystem::is_regular_file(exe)||!std::filesystem::is_regular_file(script))return false;
        std::wstring command=quote(exe.wstring())+L" -B "+quote(script.wstring())+
            L" --parent-pid "+std::to_wstring(options.parent_process_id)+
            L" --parent-birth "+std::to_wstring(options.parent_creation_time)+L" --root "+quote(base.wstring());
        if(!options.stop_event.empty()){
            if(options.stop_event.find(L'"')!=std::wstring::npos)return false;
            command+=L" --stop-event "+quote(options.stop_event);
        }
        STARTUPINFOW si{};si.cb=sizeof(si);PROCESS_INFORMATION pi{};
        if(!CreateProcessW(exe.c_str(),command.data(),nullptr,nullptr,FALSE,CREATE_NO_WINDOW,
                           nullptr,base.c_str(),&si,&pi))return false;
        process_=pi.hProcess;thread_=pi.hThread;process_id_=pi.dwProcessId;return true;
    }catch(...){return false;}
}
}
