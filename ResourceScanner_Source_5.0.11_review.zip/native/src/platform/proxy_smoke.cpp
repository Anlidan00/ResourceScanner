#include <windows.h>
#include <string>
#include <filesystem>
#include <cstdio>
int wmain(int argc,wchar_t** argv){
    if(argc!=2)return 2;
    auto path=std::filesystem::absolute(argv[1]);auto proxy=LoadLibraryExW(path.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);
    if(!proxy)return 3;
    using GetOptions=DWORD(WINAPI*)();using SetOptions=DWORD(WINAPI*)(DWORD);
    auto get=reinterpret_cast<GetOptions>(GetProcAddress(proxy,"SymGetOptions"));auto set=reinterpret_cast<SetOptions>(GetProcAddress(proxy,"SymSetOptions"));
    if(!get||!set||!GetProcAddress(proxy,"MiniDumpWriteDump"))return 4;
    auto initial=get();auto returned=set(initial|0x00000004);if(returned!=get())return 5;set(initial);
    auto core_path=path.parent_path()/L"ResourceScanner/ResourceScannerCore.dll";HMODULE core{};
    for(unsigned i=0;i<100&&!core;++i){core=GetModuleHandleW(core_path.c_str());if(!core)Sleep(20);}
    if(!core){std::printf("core not found error%lu\n",GetLastError());return 6;}
    auto stop=reinterpret_cast<BOOL(*)(DWORD)>(GetProcAddress(core,"ResourceScannerStop"));if(!stop||!stop(3000))return 7;
    std::puts("PASS canonical installed layout/OS export forwarding/core startup-stop");return 0;
}
