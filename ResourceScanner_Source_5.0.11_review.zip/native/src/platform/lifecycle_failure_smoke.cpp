#include <windows.h>
static HANDLE WINAPI fail_CreateThread(LPSECURITY_ATTRIBUTES,SIZE_T,LPTHREAD_START_ROUTINE,LPVOID,DWORD,LPDWORD){return nullptr;}
#define CreateThread fail_CreateThread
#include "lifecycle.cpp"
#undef CreateThread
#include <cstdio>
namespace {unsigned installations{},removals{};}
namespace rs::platform::detail {
bool install_vulkan_hooks()noexcept{++installations;return true;}
void remove_vulkan_hooks()noexcept{++removals;}
}
int main(){
    if(rs::platform::start()||!rs::platform::detail::stopping()||installations!=1||removals!=1)return 1;
    if(!rs::platform::stop(0)||removals!=1)return 2;
    std::puts("PASS actual start CreateThread failure disables synchronous hooks and returns stopped; subsequent Stop is idempotent");
    return 0;
}
