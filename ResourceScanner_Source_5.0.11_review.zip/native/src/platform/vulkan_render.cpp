#include "internal.hpp"
#include <rs/platform/texture.hpp>
#include <rs/platform/paths.hpp>
#include <rs/platform/visibility_key.hpp>
#include <rs/platform/font.hpp>
#include <imgui.h>
#include <imgui_internal.h>
#include <backends/imgui_impl_win32.h>
#include <backends/imgui_impl_vulkan.h>
#include <MinHook.h>
#include <array>
#include <vector>
#include <mutex>
#include <algorithm>
#include <cstring>
#include <limits>
#include <cstdio>
#include <utility>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);

namespace rs::platform {
namespace {
PFN_vkGetInstanceProcAddr gipa{};
PFN_vkGetDeviceProcAddr gdpa{};
PFN_vkCreateInstance create_instance{};
PFN_vkDestroyInstance destroy_instance{};
PFN_vkEnumeratePhysicalDevices enumerate_physical{};
PFN_vkCreateDevice create_device{};
PFN_vkCreateWin32SurfaceKHR create_surface{};
PFN_vkDestroySurfaceKHR destroy_surface{};
PFN_vkCreateSwapchainKHR create_swapchain{};
PFN_vkDestroySwapchainKHR destroy_swapchain{};
PFN_vkDestroyDevice destroy_device{};
PFN_vkGetDeviceQueue get_queue{};
PFN_vkGetDeviceQueue2 get_queue2{};
PFN_vkQueuePresentKHR present{};
std::recursive_mutex mutex;
std::vector<void*> hook_targets;
VkInstance instance{};VkPhysicalDevice physical{};VkDevice device{};
VkQueue graphics_queue{};std::uint32_t graphics_family=~0u;
VkSurfaceKHR surface{};HWND window{},backend_window{};WNDPROC previous_wndproc{};
struct WindowBinding {HWND window{};WNDPROC previous{};bool chained{};};
// Retain predecessor identities for callbacks already inside an older window's
// subclass chain. A different window must never inherit the new predecessor.
std::array<WindowBinding,32> window_bindings{};
ImGuiContext* context{};bool win32_ready{},vulkan_ready{},input_frame_active{};
std::array<bool,256> text_keys{},raw_text_keys{};
DWORD render_thread{};VkCommandBuffer active_command{};
std::uint64_t previous_tick{},frame_sequence{};
std::uint64_t texture_generation{};
game::Frame previous_game{};std::uint64_t scope_start{};bool hooks_enabled{};
// Bootstrap may precede Start. Only explicit teardown suspends observations;
// cached GIPA/GDPA PFNs still forward their real calls while suspended.
bool observation_enabled{true};
enum Stage { Gipa,Gdpa,Instance,Device,Surface,Queue,SwapchainCall,Present,StageCount };
std::array<bool,StageCount> seen{};
void stage(Stage value,const char* message)noexcept{if(!seen[value]){seen[value]=true;log("vulkan-stage",message);}}

struct DeviceApi {
    PFN_vkGetSwapchainImagesKHR get_images{};
    PFN_vkCreateImageView create_view{};PFN_vkDestroyImageView destroy_view{};
    PFN_vkCreateRenderPass create_pass{};PFN_vkDestroyRenderPass destroy_pass{};
    PFN_vkCreateFramebuffer create_fb{};PFN_vkDestroyFramebuffer destroy_fb{};
    PFN_vkCreateCommandPool create_pool{};PFN_vkDestroyCommandPool destroy_pool{};
    PFN_vkAllocateCommandBuffers allocate_commands{};
    PFN_vkResetCommandBuffer reset_command{};PFN_vkBeginCommandBuffer begin_command{};PFN_vkEndCommandBuffer end_command{};
    PFN_vkCmdBeginRenderPass begin_pass{};PFN_vkCmdEndRenderPass end_pass{};
    PFN_vkCreateSemaphore create_semaphore{};PFN_vkDestroySemaphore destroy_semaphore{};
    PFN_vkCreateFence create_fence{};PFN_vkDestroyFence destroy_fence{};
    PFN_vkWaitForFences wait_fences{};PFN_vkResetFences reset_fences{};
    PFN_vkQueueSubmit submit{};PFN_vkDeviceWaitIdle idle{};
    PFN_vkCreateBuffer create_buffer{};PFN_vkDestroyBuffer destroy_buffer{};
    PFN_vkGetBufferMemoryRequirements buffer_requirements{};
    PFN_vkAllocateMemory allocate_memory{};PFN_vkFreeMemory free_memory{};
    PFN_vkBindBufferMemory bind_buffer{};PFN_vkMapMemory map_memory{};PFN_vkUnmapMemory unmap_memory{};
    PFN_vkCreateImage create_image{};PFN_vkDestroyImage destroy_image{};
    PFN_vkGetImageMemoryRequirements image_requirements{};PFN_vkBindImageMemory bind_image{};
    PFN_vkCreateSampler create_sampler{};PFN_vkDestroySampler destroy_sampler{};
    PFN_vkCmdPipelineBarrier barrier{};PFN_vkCmdCopyBufferToImage copy_image{};
} api;
VkPhysicalDeviceMemoryProperties memory_properties{};
struct Staging {VkBuffer buffer{};VkDeviceMemory memory{};};
struct ImageFrame {VkImageView view{};VkFramebuffer framebuffer{};VkCommandBuffer command{};
    VkFence fence{};VkSemaphore complete{};std::vector<Staging> staging;};
struct Swapchain {VkSwapchainKHR handle{};VkFormat format{};VkExtent2D size{};
    VkRenderPass pass{};VkCommandPool pool{};std::vector<ImageFrame> frames;bool disabled{};} swap;
// Only copy fields consumed by our initializer. pNext/queue-family arrays are
// caller-owned and must never survive vkCreateSwapchainKHR's return.
struct PendingSwapchain {VkSwapchainKHR handle{};VkSwapchainCreateInfoKHR info{};bool deferred_logged{};} pending;
struct Texture {TextureId id{};VkImage image{};VkDeviceMemory memory{};VkImageView view{};
    VkSampler sampler{};VkDescriptorSet descriptor{};bool retired{};};
std::vector<Texture> textures;

struct DispatchOrigin {PFN_vkGetInstanceProcAddr instance_proc{};PFN_vkGetDeviceProcAddr device_proc{};VkInstance instance{};VkDevice device{};};
struct Dispatch {PFN_vkVoidFunction function{};DispatchOrigin origin{};};
thread_local unsigned original_depth{};
struct OriginalScope {OriginalScope(){++original_depth;}~OriginalScope(){--original_depth;}};
template<class F,class... A>auto original_call(PFN_vkVoidFunction function,A... args){OriginalScope scope;return reinterpret_cast<F>(function)(args...);}
struct InstanceOwner {VkInstance handle{};DispatchOrigin origin{};};
struct DeviceOwner {VkDevice handle{};VkPhysicalDevice physical{};DispatchOrigin origin{};VkQueue queue{};std::uint32_t family=~0u;};
struct SurfaceOwner {VkSurfaceKHR handle{};VkInstance instance{};HWND window{};};
struct PhysicalOwner {VkPhysicalDevice handle{};VkInstance instance{};};
std::array<InstanceOwner,32> instance_owners{};std::array<DeviceOwner,32> device_owners{};std::array<SurfaceOwner,32> surface_owners{};
std::array<PhysicalOwner,128> physical_owners{};
DispatchOrigin active_origin{};
DeviceOwner* owner_device(VkDevice value){if(value)for(auto& r:device_owners)if(r.handle==value)return &r;return nullptr;}
InstanceOwner* owner_instance(VkInstance value){if(value)for(auto& r:instance_owners)if(r.handle==value)return &r;return nullptr;}
SurfaceOwner* owner_surface(VkSurfaceKHR value){if(value)for(auto& r:surface_owners)if(r.handle==value)return &r;return nullptr;}
PhysicalOwner* owner_physical(VkPhysicalDevice value){if(value)for(auto& r:physical_owners)if(r.handle==value)return &r;return nullptr;}
DispatchOrigin default_origin(){return {gipa,gdpa,instance,device};}
PFN_vkVoidFunction instance_function(const DispatchOrigin& origin,const char* name){
    if(!origin.instance_proc||!origin.instance)return nullptr;
    return original_call<PFN_vkGetInstanceProcAddr>(reinterpret_cast<PFN_vkVoidFunction>(origin.instance_proc),origin.instance,name);
}
PFN_vkVoidFunction device_function(const DispatchOrigin& origin,const char* name){
    auto resolver=origin.device_proc;
    if(!resolver)resolver=reinterpret_cast<PFN_vkGetDeviceProcAddr>(instance_function(origin,"vkGetDeviceProcAddr"));
    if(!resolver||!origin.device)return nullptr;
    return original_call<PFN_vkGetDeviceProcAddr>(reinterpret_cast<PFN_vkVoidFunction>(resolver),origin.device,name);
}

template<class T>bool load(T& destination,const char* name){destination=reinterpret_cast<T>(device_function(active_origin,name));return destination!=nullptr;}
bool load_device_api(){
#define RS_VK(field,name) if(!load(api.field,"vk" #name))return false
    RS_VK(get_images,GetSwapchainImagesKHR);RS_VK(create_view,CreateImageView);RS_VK(destroy_view,DestroyImageView);
    RS_VK(create_pass,CreateRenderPass);RS_VK(destroy_pass,DestroyRenderPass);RS_VK(create_fb,CreateFramebuffer);
    RS_VK(destroy_fb,DestroyFramebuffer);RS_VK(create_pool,CreateCommandPool);RS_VK(destroy_pool,DestroyCommandPool);
    RS_VK(allocate_commands,AllocateCommandBuffers);RS_VK(reset_command,ResetCommandBuffer);RS_VK(begin_command,BeginCommandBuffer);
    RS_VK(end_command,EndCommandBuffer);RS_VK(begin_pass,CmdBeginRenderPass);RS_VK(end_pass,CmdEndRenderPass);
    RS_VK(create_semaphore,CreateSemaphore);RS_VK(destroy_semaphore,DestroySemaphore);RS_VK(create_fence,CreateFence);
    RS_VK(destroy_fence,DestroyFence);RS_VK(wait_fences,WaitForFences);RS_VK(reset_fences,ResetFences);
    RS_VK(submit,QueueSubmit);RS_VK(idle,DeviceWaitIdle);RS_VK(create_buffer,CreateBuffer);RS_VK(destroy_buffer,DestroyBuffer);
    RS_VK(buffer_requirements,GetBufferMemoryRequirements);RS_VK(allocate_memory,AllocateMemory);RS_VK(free_memory,FreeMemory);
    RS_VK(bind_buffer,BindBufferMemory);RS_VK(map_memory,MapMemory);RS_VK(unmap_memory,UnmapMemory);
    RS_VK(create_image,CreateImage);RS_VK(destroy_image,DestroyImage);RS_VK(image_requirements,GetImageMemoryRequirements);
    RS_VK(bind_image,BindImageMemory);RS_VK(create_sampler,CreateSampler);RS_VK(destroy_sampler,DestroySampler);
    RS_VK(barrier,CmdPipelineBarrier);RS_VK(copy_image,CmdCopyBufferToImage);
#undef RS_VK
    return true;
}
bool text_input_active()noexcept {
    // WantCaptureKeyboard also includes mere window/navigation focus; only an
    // actively edited InputText owns game shortcuts. Do not use mouse hover.
    return input_frame_active&&context&&context->ActiveId!=0&&context->ActiveId==context->InputTextState.ID;
}
bool keyboard_passthrough(WPARAM key)noexcept {return key==VK_ESCAPE||key==visibility_key();}
bool capture_text_key(std::array<bool,256>& owned,WPARAM key,bool down,bool typing)noexcept {
    if(key>=255||keyboard_passthrough(key))return false;
    // Let releases of keys pressed before editing reach the game. Conversely,
    // finish swallowing a text-owned press even if editing ended before keyup.
    const bool consume=down?(typing||owned[key]):owned[key];
    owned[key]=down&&consume;return consume;
}
bool raw_text_key(LPARAM lparam,bool typing)noexcept {
    RAWINPUT raw{};UINT size=sizeof(raw);
    const auto copied=GetRawInputData(reinterpret_cast<HRAWINPUT>(lparam),RID_INPUT,&raw,&size,sizeof(RAWINPUTHEADER));
    constexpr auto keyboard_bytes=sizeof(RAWINPUTHEADER)+sizeof(RAWKEYBOARD);
    if(copied==UINT(-1)||copied<keyboard_bytes||copied>sizeof(raw)||raw.header.dwSize<keyboard_bytes||
       raw.header.dwSize>copied||raw.header.dwType!=RIM_TYPEKEYBOARD)return false;
    return capture_text_key(raw_text_keys,raw.data.keyboard.VKey,(raw.data.keyboard.Flags&RI_KEY_BREAK)==0,typing);
}
LRESULT CALLBACK window_proc(HWND hwnd,UINT message,WPARAM wparam,LPARAM lparam) {
    std::lock_guard lock(mutex);
    if(context&&win32_ready&&hwnd==backend_window){
        auto* saved=ImGui::GetCurrentContext();ImGui::SetCurrentContext(context);
        ImGui_ImplWin32_WndProcHandler(hwnd,message,wparam,lparam);
        const auto& io=ImGui::GetIO();
        const bool mouse=message>=WM_MOUSEFIRST&&message<=WM_MOUSELAST;
        const bool key=message>=WM_KEYFIRST&&message<=WM_KEYLAST;
        const bool typing=text_input_active()&&GetForegroundWindow()==hwnd;
        bool consume=input_frame_active&&mouse&&io.WantCaptureMouse;
        const bool key_transition=message==WM_KEYDOWN||message==WM_KEYUP||message==WM_SYSKEYDOWN||message==WM_SYSKEYUP;
        if(key)consume=key_transition?capture_text_key(text_keys,wparam,message==WM_KEYDOWN||message==WM_SYSKEYDOWN,typing):
            typing&&!(message==WM_CHAR&&wparam==VK_ESCAPE);
        // The game also receives keyboard events through WM_INPUT, bypassing
        // WM_KEYDOWN capture. Inspect only bounded OS keyboard packets; mouse
        // and HID packets, unknown layouts and read failures pass unchanged.
        const bool raw_pending=std::any_of(raw_text_keys.begin(),raw_text_keys.end(),[](bool owned){return owned;});
        const bool raw_consume=message==WM_INPUT&&(typing||raw_pending)&&raw_text_key(lparam,typing);
        if(message==WM_KILLFOCUS){text_keys.fill(false);raw_text_keys.fill(false);}
        ImGui::SetCurrentContext(saved);
        // Foreground raw input requires the system cleanup even when the
        // game's own window procedure must not see the keyboard packet.
        if(raw_consume)return DefWindowProcW(hwnd,message,wparam,lparam);
        if(consume)return 1;
    }
    WNDPROC previous{};for(const auto& binding:window_bindings)if(binding.window==hwnd){previous=binding.previous;break;}
    return previous?CallWindowProcW(previous,hwnd,message,wparam,lparam):DefWindowProcW(hwnd,message,wparam,lparam);
}
// Called with our renderer mutex and context selected. Never undo a later
// third-party subclass; its retained predecessor may still call window_proc.
void shutdown_win32(){
    input_frame_active=false;text_keys.fill(false);raw_text_keys.fill(false);
    if(backend_window&&reinterpret_cast<WNDPROC>(GetWindowLongPtrW(backend_window,GWLP_WNDPROC))==window_proc)
        if(SetWindowLongPtrW(backend_window,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(previous_wndproc)))
            for(auto& binding:window_bindings)if(binding.window==backend_window)binding.chained=false;
    if(win32_ready)ImGui_ImplWin32_Shutdown();win32_ready=false;backend_window=nullptr;previous_wndproc=nullptr;
}
bool initialize_win32(HWND target){
    if(win32_ready&&backend_window==target)return true;
    shutdown_win32();if(!target)return false;
    WindowBinding* binding{};for(auto& entry:window_bindings)if(entry.window==target){binding=&entry;break;}
    if(!binding)for(auto& entry:window_bindings)if(!entry.window){binding=&entry;break;}
    if(!binding||!ImGui_ImplWin32_Init(target))return false;
    const auto current=reinterpret_cast<WNDPROC>(GetWindowLongPtrW(target,GWLP_WNDPROC));
    if(current==window_proc){if(!binding->previous){ImGui_ImplWin32_Shutdown();return false;}}
    else {
        if(binding->chained){ImGui_ImplWin32_Shutdown();return false;}
        const auto previous=reinterpret_cast<WNDPROC>(SetWindowLongPtrW(target,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(window_proc)));
        if(!previous){ImGui_ImplWin32_Shutdown();return false;}
        *binding={target,previous,true};
    }
    backend_window=target;previous_wndproc=binding->previous;win32_ready=true;return true;
}
PFN_vkVoidFunction backend_loader(const char* name,void*) {
    auto fn=device_function(active_origin,name);return fn?fn:instance_function(active_origin,name);
}
void destroy_texture(Texture& t){
    if(t.descriptor&&vulkan_ready)ImGui_ImplVulkan_RemoveTexture(t.descriptor);
    if(t.sampler)api.destroy_sampler(device,t.sampler,nullptr);
    if(t.view)api.destroy_view(device,t.view,nullptr);
    if(t.image)api.destroy_image(device,t.image,nullptr);
    if(t.memory)api.free_memory(device,t.memory,nullptr);t={};
}
void free_staging(ImageFrame& f){for(auto& s:f.staging){api.destroy_buffer(device,s.buffer,nullptr);api.free_memory(device,s.memory,nullptr);}f.staging.clear();}
void cleanup_swap(){
    if(!device)return;
    input_frame_active=false;
    ++texture_generation;
    if(api.idle)api.idle(device);
    auto* saved=ImGui::GetCurrentContext();if(context)ImGui::SetCurrentContext(context);
    for(auto& t:textures)destroy_texture(t);textures.clear();
    if(vulkan_ready){ImGui_ImplVulkan_Shutdown();vulkan_ready=false;}
    for(auto& f:swap.frames){free_staging(f);if(f.complete)api.destroy_semaphore(device,f.complete,nullptr);
        if(f.fence)api.destroy_fence(device,f.fence,nullptr);if(f.framebuffer)api.destroy_fb(device,f.framebuffer,nullptr);
        if(f.view)api.destroy_view(device,f.view,nullptr);}
    if(swap.pool)api.destroy_pool(device,swap.pool,nullptr);if(swap.pass)api.destroy_pass(device,swap.pass,nullptr);
    swap={};ImGui::SetCurrentContext(saved);
}
bool initialize_swap(VkSwapchainKHR handle,const VkSwapchainCreateInfoKHR& info) {
    if(!observation_enabled||!device||!instance||!physical||!graphics_queue||graphics_family==~0u||!window ||
        !(info.imageUsage&VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT)||info.imageArrayLayers!=1)return false;
    if(!load_device_api())return false;
    auto memory=reinterpret_cast<PFN_vkGetPhysicalDeviceMemoryProperties>(instance_function(active_origin,"vkGetPhysicalDeviceMemoryProperties"));
    if(!memory)return false;memory(physical,&memory_properties);
    swap.handle=handle;swap.format=info.imageFormat;swap.size=info.imageExtent;
    std::uint32_t count{};
    if(api.get_images(device,handle,&count,nullptr)!=VK_SUCCESS||count<2||count>16)return false;
    std::vector<VkImage> images(count);if(api.get_images(device,handle,&count,images.data())!=VK_SUCCESS)return false;
    swap.frames.resize(count);
    VkAttachmentDescription attachment{};attachment.format=info.imageFormat;attachment.samples=VK_SAMPLE_COUNT_1_BIT;
    attachment.loadOp=VK_ATTACHMENT_LOAD_OP_LOAD;attachment.storeOp=VK_ATTACHMENT_STORE_OP_STORE;
    attachment.stencilLoadOp=VK_ATTACHMENT_LOAD_OP_DONT_CARE;attachment.stencilStoreOp=VK_ATTACHMENT_STORE_OP_DONT_CARE;
    attachment.initialLayout=VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;attachment.finalLayout=VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
    VkAttachmentReference reference{0,VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};VkSubpassDescription sub{};
    sub.pipelineBindPoint=VK_PIPELINE_BIND_POINT_GRAPHICS;sub.colorAttachmentCount=1;sub.pColorAttachments=&reference;
    VkSubpassDependency dependency{};dependency.srcSubpass=VK_SUBPASS_EXTERNAL;dependency.dstSubpass=0;
    dependency.srcStageMask=VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;dependency.dstStageMask=dependency.srcStageMask;
    dependency.srcAccessMask=VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;dependency.dstAccessMask=VK_ACCESS_COLOR_ATTACHMENT_READ_BIT|VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    VkRenderPassCreateInfo pass{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};pass.attachmentCount=1;pass.pAttachments=&attachment;
    pass.subpassCount=1;pass.pSubpasses=&sub;pass.dependencyCount=1;pass.pDependencies=&dependency;
    if(api.create_pass(device,&pass,nullptr,&swap.pass)!=VK_SUCCESS)return false;
    VkCommandPoolCreateInfo pool{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};pool.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;pool.queueFamilyIndex=graphics_family;
    if(api.create_pool(device,&pool,nullptr,&swap.pool)!=VK_SUCCESS)return false;
    for(std::size_t i=0;i<images.size();++i){auto& f=swap.frames[i];
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};vi.image=images[i];vi.viewType=VK_IMAGE_VIEW_TYPE_2D;
        vi.format=info.imageFormat;vi.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
        if(api.create_view(device,&vi,nullptr,&f.view)!=VK_SUCCESS)return false;
        VkFramebufferCreateInfo fb{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};fb.renderPass=swap.pass;fb.attachmentCount=1;fb.pAttachments=&f.view;
        fb.width=info.imageExtent.width;fb.height=info.imageExtent.height;fb.layers=1;
        if(api.create_fb(device,&fb,nullptr,&f.framebuffer)!=VK_SUCCESS)return false;
        VkCommandBufferAllocateInfo alloc{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};alloc.commandPool=swap.pool;alloc.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;alloc.commandBufferCount=1;
        if(api.allocate_commands(device,&alloc,&f.command)!=VK_SUCCESS)return false;
        VkFenceCreateInfo fence{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};fence.flags=VK_FENCE_CREATE_SIGNALED_BIT;
        VkSemaphoreCreateInfo semaphore{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        if(api.create_fence(device,&fence,nullptr,&f.fence)!=VK_SUCCESS||api.create_semaphore(device,&semaphore,nullptr,&f.complete)!=VK_SUCCESS)return false;
    }
    if(!context){context=ImGui::CreateContext();ImGui::SetCurrentContext(context);ImGui::GetIO().IniFilename=nullptr;
        ImGui::GetIO().LogFilename=nullptr;ImGui::GetIO().ConfigFlags|=ImGuiConfigFlags_NoMouseCursorChange;ImGui::StyleColorsDark();
        if(!initialize_fonts(ImGui::GetIO().Fonts,data_directory()/L"fonts")){
            forget_fonts();ImGui::GetIO().Fonts->Clear();ImGui::GetIO().Fonts->AddFontDefault();
            log("fonts","Font source unavailable; only default English face is admitted");}}
    ImGui::SetCurrentContext(context);
    if(!initialize_win32(window))return false;
    if(!ImGui_ImplVulkan_LoadFunctions(VK_API_VERSION_1_0,backend_loader))return false;
    ImGui_ImplVulkan_InitInfo init{};init.ApiVersion=VK_API_VERSION_1_0;init.Instance=instance;init.PhysicalDevice=physical;init.Device=device;
    init.QueueFamily=graphics_family;init.Queue=graphics_queue;init.MinImageCount=std::max(2u,info.minImageCount);init.ImageCount=count;
    init.DescriptorPoolSize=4096;init.PipelineInfoMain.RenderPass=swap.pass;init.PipelineInfoMain.MSAASamples=VK_SAMPLE_COUNT_1_BIT;
    vulkan_ready=ImGui_ImplVulkan_Init(&init);return vulkan_ready;
}

unsigned missing_prerequisites()noexcept{
    return (!instance?1u:0u)|(!physical?2u:0u)|(!device?4u:0u)|(!surface?8u:0u)|
        (!window?16u:0u)|(!graphics_queue?32u:0u)|(graphics_family==~0u?64u:0u);
}
void try_pending_swap(){
    if(!observation_enabled||!pending.handle||vulkan_ready)return;
    const auto missing=missing_prerequisites();
    if(missing){if(!pending.deferred_logged){char message[128]{};
        std::snprintf(message,sizeof(message),"Swapchain initialization deferred; missing_mask=%u",missing);
        log("vulkan-stage",message);pending.deferred_logged=true;}return;}
    const auto handle=pending.handle;const auto info=pending.info;pending={};
    cleanup_swap();
    if(!initialize_swap(handle,info)){cleanup_swap();log("renderer","Swapchain not supported; overlay skipped");}
    else log("renderer","Official Win32/Vulkan backends initialized");
}

PFN_vkVoidFunction replacement(const char*,PFN_vkVoidFunction,const DispatchOrigin&);
VkResult invoke_create_instance(const Dispatch& dispatch,const VkInstanceCreateInfo* info,const VkAllocationCallbacks* allocation,VkInstance* out){
    const bool observe=original_depth==0;auto result=original_call<PFN_vkCreateInstance>(dispatch.function,info,allocation,out);if(!observe)return result;
    std::lock_guard lock(mutex);if(!observation_enabled)return result;stage(Instance,result==VK_SUCCESS?"vkCreateInstance succeeded":"vkCreateInstance failed");
    if(result==VK_SUCCESS){for(auto& r:instance_owners)if(!r.handle){auto origin=dispatch.origin;origin.instance=*out;origin.device={};origin.device_proc={};r={*out,origin};if(!device)instance=*out;break;}}
    return result;
}
void invoke_destroy_instance(const Dispatch& dispatch,VkInstance owner,const VkAllocationCallbacks* allocation){
    const bool observe=original_depth==0;
    if(observe){std::lock_guard lock(mutex);if(active_origin.instance==owner){pending={};cleanup_swap();device={};physical={};graphics_queue={};graphics_family=~0u;active_origin={};api={};}}
    original_call<PFN_vkDestroyInstance>(dispatch.function,owner,allocation);
    if(observe){std::lock_guard lock(mutex);for(auto& r:instance_owners)if(r.handle==owner)r={};for(auto& r:device_owners)if(r.origin.instance==owner)r={};
        for(auto& r:physical_owners)if(r.instance==owner)r={};
        for(auto& r:surface_owners)if(r.instance==owner)r={};if(instance==owner){instance={};surface={};window={};}log("vulkan-stage","vkDestroyInstance retired its owned context");}
}
void remember_physical(VkInstance owner,VkPhysicalDevice gpu){
    if(!owner_instance(owner))return;if(auto* found=owner_physical(gpu)){if(found->instance!=owner)*found={};return;}
    for(auto& r:physical_owners)if(!r.handle){r={gpu,owner};return;}
}
VkResult invoke_enumerate_physical(const Dispatch& dispatch,VkInstance owner,std::uint32_t* count,VkPhysicalDevice* devices){
    const bool observe=original_depth==0;auto result=original_call<PFN_vkEnumeratePhysicalDevices>(dispatch.function,owner,count,devices);
    if(observe&&(result==VK_SUCCESS||result==VK_INCOMPLETE)&&devices&&count&&*count<=128){std::lock_guard lock(mutex);if(observation_enabled)for(std::uint32_t i=0;i<*count;++i)remember_physical(owner,devices[i]);}return result;
}
VkResult invoke_enumerate_groups(const Dispatch& dispatch,VkInstance owner,std::uint32_t* count,VkPhysicalDeviceGroupProperties* groups){
    const bool observe=original_depth==0;auto result=original_call<PFN_vkEnumeratePhysicalDeviceGroups>(dispatch.function,owner,count,groups);
    if(observe&&(result==VK_SUCCESS||result==VK_INCOMPLETE)&&groups&&count&&*count<=32){std::lock_guard lock(mutex);if(observation_enabled)for(std::uint32_t i=0;i<*count;++i)if(groups[i].physicalDeviceCount<=VK_MAX_DEVICE_GROUP_SIZE)
        for(std::uint32_t j=0;j<groups[i].physicalDeviceCount;++j)remember_physical(owner,groups[i].physicalDevices[j]);}return result;
}
VkResult invoke_create_device(const Dispatch& dispatch,VkPhysicalDevice gpu,const VkDeviceCreateInfo* info,const VkAllocationCallbacks* allocation,VkDevice* out){
    const bool observe=original_depth==0;auto result=original_call<PFN_vkCreateDevice>(dispatch.function,gpu,info,allocation,out);if(!observe)return result;
    std::lock_guard lock(mutex);if(!observation_enabled)return result;stage(Device,result==VK_SUCCESS?"vkCreateDevice succeeded":"vkCreateDevice failed");
    if(result==VK_SUCCESS){auto origin=dispatch.origin;origin.device=*out;
        auto* physical_owner=owner_physical(gpu);
        if(physical_owner&&(!origin.instance||origin.instance==physical_owner->instance)){origin.instance=physical_owner->instance;
            if(owner_instance(origin.instance))for(auto& r:device_owners)if(!r.handle){r={*out,gpu,origin};break;}}}
    // No eager physical-memory query here. It previously used a destroyed
    // first-created instance. All later queries use this device's live origin.
    return result;
}
void invoke_destroy_surface(const Dispatch& dispatch,VkInstance owner,VkSurfaceKHR target,const VkAllocationCallbacks* allocation){
    const bool observe=original_depth==0;if(observe){std::lock_guard lock(mutex);if(surface==target){pending={};cleanup_swap();surface={};window={};}}
    original_call<PFN_vkDestroySurfaceKHR>(dispatch.function,owner,target,allocation);
    if(observe){std::lock_guard lock(mutex);if(auto* r=owner_surface(target))if(r->instance==owner)*r={};}
}
VkResult invoke_create_surface(const Dispatch& dispatch,VkInstance owner,const VkWin32SurfaceCreateInfoKHR* info,const VkAllocationCallbacks* allocation,VkSurfaceKHR* out){
    const bool observe=original_depth==0;auto result=original_call<PFN_vkCreateWin32SurfaceKHR>(dispatch.function,owner,info,allocation,out);if(!observe)return result;
    std::lock_guard lock(mutex);if(!observation_enabled)return result;stage(Surface,result==VK_SUCCESS?"vkCreateWin32SurfaceKHR succeeded":"vkCreateWin32SurfaceKHR failed");
    if(result==VK_SUCCESS&&owner_instance(owner)){for(auto& r:surface_owners)if(!r.handle){r={*out,owner,info->hwnd};break;}if(!surface){surface=*out;window=info->hwnd;}}
    return result;
}
bool family_graphics(const DeviceOwner& owner,std::uint32_t family){
    try{if(!owner_instance(owner.origin.instance))return false;
        auto get=reinterpret_cast<PFN_vkGetPhysicalDeviceQueueFamilyProperties>(instance_function(owner.origin,"vkGetPhysicalDeviceQueueFamilyProperties"));
        if(!get||!owner.physical)return false;std::uint32_t count{};get(owner.physical,&count,nullptr);if(!count||count>256||family>=count)return false;
        std::vector<VkQueueFamilyProperties> properties(count);get(owner.physical,&count,properties.data());return (properties[family].queueFlags&VK_QUEUE_GRAPHICS_BIT)!=0;
    }catch(...){return false;}
}
void invoke_get_queue(const Dispatch& dispatch,VkDevice owner,std::uint32_t family,std::uint32_t index,VkQueue* out){
    const bool observe=original_depth==0;original_call<PFN_vkGetDeviceQueue>(dispatch.function,owner,family,index,out);if(!observe)return;
    std::lock_guard lock(mutex);if(!observation_enabled)return;auto* record=owner_device(owner);if(record&&index==0&&!record->queue&&family_graphics(*record,family)){
        record->queue=*out;record->family=family;if(device==owner){graphics_queue=*out;graphics_family=family;}stage(Queue,"vkGetDeviceQueue captured graphics queue");}
}
void invoke_get_queue2(const Dispatch& dispatch,VkDevice owner,const VkDeviceQueueInfo2* info,VkQueue* out){
    const bool observe=original_depth==0;original_call<PFN_vkGetDeviceQueue2>(dispatch.function,owner,info,out);if(!observe)return;
    std::lock_guard lock(mutex);if(!observation_enabled)return;auto* record=owner_device(owner);if(record&&info->queueIndex==0&&!record->queue&&family_graphics(*record,info->queueFamilyIndex)){
        record->queue=*out;record->family=info->queueFamilyIndex;if(device==owner){graphics_queue=*out;graphics_family=info->queueFamilyIndex;}stage(Queue,"vkGetDeviceQueue2 captured graphics queue");}
}
bool adopt_swapchain_owner(VkDevice owner,VkSurfaceKHR target){
    if(!observation_enabled)return false;
    auto* d=owner_device(owner);auto* s=owner_surface(target);
    if(!d||!s||!owner_instance(s->instance)||d->origin.instance!=s->instance||(vulkan_ready&&device!=owner))return false;
    device=owner;physical=d->physical;instance=s->instance;surface=target;window=s->window;
    graphics_queue=d->queue;graphics_family=d->family;active_origin=d->origin;return true;
}
VkResult invoke_create_swapchain(const Dispatch& dispatch,VkDevice owner,const VkSwapchainCreateInfoKHR* info,const VkAllocationCallbacks* allocation,VkSwapchainKHR* out){
    const bool observe=original_depth==0;auto result=original_call<PFN_vkCreateSwapchainKHR>(dispatch.function,owner,info,allocation,out);if(!observe)return result;
    try{if(result==VK_SUCCESS){std::lock_guard lock(mutex);const bool owned=adopt_swapchain_owner(owner,info->surface);
        if(!seen[SwapchainCall]){char message[160]{};std::snprintf(message,sizeof(message),"vkCreateSwapchainKHR succeeded; owned_context=%u missing_mask=%u",unsigned(owned),missing_prerequisites());stage(SwapchainCall,message);}
        if(owned){cleanup_swap();pending={};pending.handle=*out;pending.info.sType=VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;pending.info.surface=info->surface;
            pending.info.minImageCount=info->minImageCount;pending.info.imageFormat=info->imageFormat;pending.info.imageExtent=info->imageExtent;
            pending.info.imageArrayLayers=info->imageArrayLayers;pending.info.imageUsage=info->imageUsage;try_pending_swap();}}
    }catch(...){std::lock_guard lock(mutex);pending={};cleanup_swap();log("renderer","Swapchain overlay allocation failed; original swapchain retained");}return result;
}
void invoke_destroy_swapchain(const Dispatch& dispatch,VkDevice owner,VkSwapchainKHR handle,const VkAllocationCallbacks* allocation){
    const bool observe=original_depth==0;if(observe){std::lock_guard lock(mutex);if(owner==device){if(handle==pending.handle)pending={};if(handle==swap.handle)cleanup_swap();}}
    original_call<PFN_vkDestroySwapchainKHR>(dispatch.function,owner,handle,allocation);
}
void invoke_destroy_device(const Dispatch& dispatch,VkDevice owner,const VkAllocationCallbacks* allocation){
    const bool observe=original_depth==0;if(observe){std::lock_guard lock(mutex);if(owner==device){pending={};cleanup_swap();}}
    original_call<PFN_vkDestroyDevice>(dispatch.function,owner,allocation);
    if(observe){std::lock_guard lock(mutex);if(auto* record=owner_device(owner))*record={};if(owner==device){device={};physical={};graphics_queue={};graphics_family=~0u;active_origin={};api={};}}
}
VKAPI_ATTR VkResult VKAPI_CALL hook_create_instance(const VkInstanceCreateInfo* i,const VkAllocationCallbacks* a,VkInstance* o){return invoke_create_instance({reinterpret_cast<PFN_vkVoidFunction>(create_instance),default_origin()},i,a,o);}
VKAPI_ATTR void VKAPI_CALL hook_destroy_instance(VkInstance o,const VkAllocationCallbacks* a){invoke_destroy_instance({reinterpret_cast<PFN_vkVoidFunction>(destroy_instance),default_origin()},o,a);}
VKAPI_ATTR VkResult VKAPI_CALL hook_enumerate_physical(VkInstance o,std::uint32_t* n,VkPhysicalDevice* d){return invoke_enumerate_physical({reinterpret_cast<PFN_vkVoidFunction>(enumerate_physical),default_origin()},o,n,d);}
VKAPI_ATTR VkResult VKAPI_CALL hook_create_device(VkPhysicalDevice p,const VkDeviceCreateInfo* i,const VkAllocationCallbacks* a,VkDevice* o){return invoke_create_device({reinterpret_cast<PFN_vkVoidFunction>(create_device),default_origin()},p,i,a,o);}
VKAPI_ATTR VkResult VKAPI_CALL hook_create_surface(VkInstance o,const VkWin32SurfaceCreateInfoKHR* i,const VkAllocationCallbacks* a,VkSurfaceKHR* s){return invoke_create_surface({reinterpret_cast<PFN_vkVoidFunction>(create_surface),default_origin()},o,i,a,s);}
VKAPI_ATTR void VKAPI_CALL hook_destroy_surface(VkInstance o,VkSurfaceKHR s,const VkAllocationCallbacks* a){invoke_destroy_surface({reinterpret_cast<PFN_vkVoidFunction>(destroy_surface),default_origin()},o,s,a);}
VKAPI_ATTR void VKAPI_CALL hook_get_queue(VkDevice o,std::uint32_t f,std::uint32_t i,VkQueue* q){invoke_get_queue({reinterpret_cast<PFN_vkVoidFunction>(get_queue),default_origin()},o,f,i,q);}
VKAPI_ATTR void VKAPI_CALL hook_get_queue2(VkDevice o,const VkDeviceQueueInfo2* i,VkQueue* q){invoke_get_queue2({reinterpret_cast<PFN_vkVoidFunction>(get_queue2),default_origin()},o,i,q);}
VKAPI_ATTR VkResult VKAPI_CALL hook_create_swapchain(VkDevice o,const VkSwapchainCreateInfoKHR* i,const VkAllocationCallbacks* a,VkSwapchainKHR* s){return invoke_create_swapchain({reinterpret_cast<PFN_vkVoidFunction>(create_swapchain),default_origin()},o,i,a,s);}
VKAPI_ATTR void VKAPI_CALL hook_destroy_swapchain(VkDevice o,VkSwapchainKHR h,const VkAllocationCallbacks* a){invoke_destroy_swapchain({reinterpret_cast<PFN_vkVoidFunction>(destroy_swapchain),default_origin()},o,h,a);}
VKAPI_ATTR void VKAPI_CALL hook_destroy_device(VkDevice o,const VkAllocationCallbacks* a){invoke_destroy_device({reinterpret_cast<PFN_vkVoidFunction>(destroy_device),default_origin()},o,a);}
VkResult present_overlay(VkQueue queue,const VkPresentInfoKHR* info,PFN_vkQueuePresentKHR original_present){
    std::lock_guard lock(mutex);
    if(!seen[Present]){char message[128]{};std::snprintf(message,sizeof(message),"vkQueuePresentKHR intercepted; queue_match=%u missing_mask=%u",unsigned(queue==graphics_queue),missing_prerequisites());stage(Present,message);}
    if(!detail::stopping()&&queue==graphics_queue&&info&&info->swapchainCount==1&&pending.handle==info->pSwapchains[0])try_pending_swap();
    if(!observation_enabled||detail::stopping()||!vulkan_ready||swap.disabled||queue!=graphics_queue||!info||info->swapchainCount!=1||
       info->pSwapchains[0]!=swap.handle||info->pImageIndices[0]>=swap.frames.size()||info->waitSemaphoreCount>64)return original_call<PFN_vkQueuePresentKHR>(reinterpret_cast<PFN_vkVoidFunction>(original_present),queue,info);
    auto& f=swap.frames[info->pImageIndices[0]];
    if(api.wait_fences(device,1,&f.fence,VK_TRUE,500000000)!=VK_SUCCESS)return original_call<PFN_vkQueuePresentKHR>(reinterpret_cast<PFN_vkVoidFunction>(original_present),queue,info);
    free_staging(f);
    auto* saved=ImGui::GetCurrentContext();ImGui::SetCurrentContext(context);
    if(std::any_of(textures.begin(),textures.end(),[](auto& t){return t.retired;})){
        api.idle(device);for(auto& t:textures)if(t.retired)destroy_texture(t);
        std::erase_if(textures,[](auto& t){return !t.id;});
    }
    if(api.reset_command(f.command,0)!=VK_SUCCESS){ImGui::SetCurrentContext(saved);return original_call<PFN_vkQueuePresentKHR>(reinterpret_cast<PFN_vkVoidFunction>(original_present),queue,info);}
    VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};begin.flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    if(api.begin_command(f.command,&begin)!=VK_SUCCESS){ImGui::SetCurrentContext(saved);return original_call<PFN_vkQueuePresentKHR>(reinterpret_cast<PFN_vkVoidFunction>(original_present),queue,info);}
    active_command=f.command;render_thread=GetCurrentThreadId();
    ImGui_ImplVulkan_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();
    const auto now=GetTickCount64();FrameContext frame{};frame.imgui=context;frame.native_window=window;
    frame.framebuffer_width=swap.size.width;frame.framebuffer_height=swap.size.height;
    frame.texture_generation=texture_generation;
    frame.delta_seconds=previous_tick?static_cast<float>(now-previous_tick)/1000.f:1.f/60.f;previous_tick=now;
    frame.dpi_scale=GetDpiForWindow(window)/96.f;
    auto client=detail::client();if(client.sample_game)frame.game=client.sample_game(client.sampler_user,now);
    frame.game.sequence=++frame_sequence;if(!frame.game.sampled_at_ms)frame.game.sampled_at_ms=now;
    if(frame.game.map_open!=previous_game.map_open||frame.game.world_ready!=previous_game.world_ready||
       frame.game.application_address!=previous_game.application_address||frame.game.ui_address!=previous_game.ui_address||
       frame.game.map_state_address!=previous_game.map_state_address||!scope_start)scope_start=frame.game.sequence;
    frame.game.scope_start_sequence=scope_start;previous_game=frame.game;
    frame.game.process_id=GetCurrentProcessId();frame.game.process_creation_time=detail::process_birth();
    detail::publish(frame.game);if(client.render)client.render(client.user,frame);
    ImGui::Render();input_frame_active=ImGui::GetDrawData()&&ImGui::GetDrawData()->CmdListsCount>0;
    active_command={};render_thread=0;
    VkRenderPassBeginInfo rp{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};rp.renderPass=swap.pass;rp.framebuffer=f.framebuffer;rp.renderArea.extent=swap.size;
    api.begin_pass(f.command,&rp,VK_SUBPASS_CONTENTS_INLINE);ImGui_ImplVulkan_RenderDrawData(ImGui::GetDrawData(),f.command);api.end_pass(f.command);
    auto ended=api.end_command(f.command);ImGui::SetCurrentContext(saved);
    if(ended!=VK_SUCCESS)return original_call<PFN_vkQueuePresentKHR>(reinterpret_cast<PFN_vkVoidFunction>(original_present),queue,info);
    std::vector<VkPipelineStageFlags> stages(info->waitSemaphoreCount,VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
    VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};submit.waitSemaphoreCount=info->waitSemaphoreCount;submit.pWaitSemaphores=info->pWaitSemaphores;
    submit.pWaitDstStageMask=stages.data();submit.commandBufferCount=1;submit.pCommandBuffers=&f.command;
    submit.signalSemaphoreCount=1;submit.pSignalSemaphores=&f.complete;
    if(api.reset_fences(device,1,&f.fence)!=VK_SUCCESS)return original_call<PFN_vkQueuePresentKHR>(reinterpret_cast<PFN_vkVoidFunction>(original_present),queue,info);
    if(api.submit(queue,1,&submit,f.fence)!=VK_SUCCESS){
        // The reset fence has no successful submission to signal it. Retain
        // resources for normal retirement, but never wait on this orphan again.
        swap.disabled=true;input_frame_active=false;
        log("renderer","Overlay submission failed; overlay disabled until swapchain recreation");
        return original_call<PFN_vkQueuePresentKHR>(reinterpret_cast<PFN_vkVoidFunction>(original_present),queue,info);
    }
    auto modified=*info;modified.waitSemaphoreCount=1;modified.pWaitSemaphores=&f.complete;return original_call<PFN_vkQueuePresentKHR>(reinterpret_cast<PFN_vkVoidFunction>(original_present),queue,&modified);
}
VkResult invoke_present(const Dispatch& dispatch,VkQueue queue,const VkPresentInfoKHR* info){
    if(original_depth)return original_call<PFN_vkQueuePresentKHR>(dispatch.function,queue,info);
    try{return present_overlay(queue,info,reinterpret_cast<PFN_vkQueuePresentKHR>(dispatch.function));}
    catch(...){active_command={};render_thread=0;log("renderer","Overlay frame skipped after local allocation failure");return original_call<PFN_vkQueuePresentKHR>(dispatch.function,queue,info);}
}
VKAPI_ATTR VkResult VKAPI_CALL hook_present(VkQueue queue,const VkPresentInfoKHR* info){return invoke_present({reinterpret_cast<PFN_vkVoidFunction>(present),default_origin()},queue,info);}
PFN_vkVoidFunction invoke_gipa(const Dispatch& dispatch,VkInstance owner,const char* name){
    const bool observe=original_depth==0;auto result=original_call<PFN_vkGetInstanceProcAddr>(dispatch.function,owner,name);if(!observe)return result;
    std::lock_guard lock(mutex);if(!observation_enabled)return result;stage(Gipa,"GIPA dispatch intercepted");
    DispatchOrigin origin{reinterpret_cast<PFN_vkGetInstanceProcAddr>(dispatch.function),nullptr,owner,{}};
    return replacement(name,result,origin);
}
PFN_vkVoidFunction invoke_gdpa(const Dispatch& dispatch,VkDevice owner,const char* name){
    const bool observe=original_depth==0;auto result=original_call<PFN_vkGetDeviceProcAddr>(dispatch.function,owner,name);if(!observe)return result;
    std::lock_guard lock(mutex);if(!observation_enabled)return result;stage(Gdpa,"GDPA dispatch intercepted");auto origin=dispatch.origin;
    origin.device_proc=reinterpret_cast<PFN_vkGetDeviceProcAddr>(dispatch.function);origin.device=owner;
    if(auto* record=owner_device(owner)){if(!origin.instance)origin.instance=record->origin.instance;
        if(!origin.instance_proc)origin.instance_proc=record->origin.instance_proc;
        if(origin.instance==record->origin.instance){record->origin=origin;if(device==owner)active_origin=origin;}}
    return replacement(name,result,origin);
}
VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL hook_gipa(VkInstance owner,const char* name){return invoke_gipa({reinterpret_cast<PFN_vkVoidFunction>(gipa),default_origin()},owner,name);}
VKAPI_ATTR PFN_vkVoidFunction VKAPI_CALL hook_gdpa(VkDevice owner,const char* name){return invoke_gdpa({reinterpret_cast<PFN_vkVoidFunction>(gdpa),default_origin()},owner,name);}
#include "vulkan_dispatch.hpp"
template<class T>bool hook(HMODULE module,const char* name,void* detour,T& original,bool required=true){
    auto target=reinterpret_cast<void*>(GetProcAddress(module,name));if(!target)return !required;
    auto result=MH_CreateHook(target,detour,reinterpret_cast<void**>(&original));if(result!=MH_OK)return false;
    hook_targets.push_back(target);return true;
}
bool memory_type(std::uint32_t bits,VkMemoryPropertyFlags flags,std::uint32_t& out){
    for(std::uint32_t i=0;i<memory_properties.memoryTypeCount;++i)if((bits&(1u<<i))&&
        (memory_properties.memoryTypes[i].propertyFlags&flags)==flags){out=i;return true;}return false;
}
}

namespace detail {
bool install_vulkan_hooks()noexcept {
    try {
    std::lock_guard lock(mutex);if(hooks_enabled)return true;
    if(!hook_targets.empty()){bool ok=true;for(auto target:hook_targets)if(MH_QueueEnableHook(target)!=MH_OK){ok=false;break;}
        if(ok)ok=MH_ApplyQueued()==MH_OK;
        if(!ok){for(auto target:hook_targets)MH_DisableHook(target);return false;}
        observation_enabled=true;hooks_enabled=true;return true;}
    // The local first-call proxy and the real loader intentionally share a
    // basename. Never hook a guessed module from GetModuleHandle(basename).
    wchar_t system[32768]{};const auto length=GetSystemDirectoryW(system,32768);
    if(!length||length>=32768)return false;
    std::wstring loader_path(system,length);loader_path+=L"\\vulkan-1.dll";
    auto module=GetModuleHandleW(loader_path.c_str());if(!module)return false;
    wchar_t actual[32768]{};const auto actual_length=GetModuleFileNameW(module,actual,32768);
    if(!actual_length||actual_length>=32768||_wcsicmp(actual,loader_path.c_str())!=0)return false;
    hook_targets.reserve(14);
    auto initialized=MH_Initialize();if(initialized!=MH_OK&&initialized!=MH_ERROR_ALREADY_INITIALIZED)return false;
    bool ok=hook(module,"vkGetInstanceProcAddr",reinterpret_cast<void*>(hook_gipa),gipa)&&
        hook(module,"vkGetDeviceProcAddr",reinterpret_cast<void*>(hook_gdpa),gdpa)&&
        hook(module,"vkCreateInstance",reinterpret_cast<void*>(hook_create_instance),create_instance)&&
        hook(module,"vkDestroyInstance",reinterpret_cast<void*>(hook_destroy_instance),destroy_instance)&&
        hook(module,"vkEnumeratePhysicalDevices",reinterpret_cast<void*>(hook_enumerate_physical),enumerate_physical)&&
        hook(module,"vkCreateDevice",reinterpret_cast<void*>(hook_create_device),create_device)&&
        hook(module,"vkCreateWin32SurfaceKHR",reinterpret_cast<void*>(hook_create_surface),create_surface)&&
        hook(module,"vkDestroySurfaceKHR",reinterpret_cast<void*>(hook_destroy_surface),destroy_surface)&&
        hook(module,"vkCreateSwapchainKHR",reinterpret_cast<void*>(hook_create_swapchain),create_swapchain)&&
        hook(module,"vkDestroySwapchainKHR",reinterpret_cast<void*>(hook_destroy_swapchain),destroy_swapchain)&&
        hook(module,"vkDestroyDevice",reinterpret_cast<void*>(hook_destroy_device),destroy_device)&&
        hook(module,"vkGetDeviceQueue",reinterpret_cast<void*>(hook_get_queue),get_queue)&&
        hook(module,"vkGetDeviceQueue2",reinterpret_cast<void*>(hook_get_queue2),get_queue2,false)&&
        hook(module,"vkQueuePresentKHR",reinterpret_cast<void*>(hook_present),present);
    if(ok)for(auto target:hook_targets)if(MH_QueueEnableHook(target)!=MH_OK){ok=false;break;}
    const bool activation_attempted=ok;
    if(ok)ok=MH_ApplyQueued()==MH_OK;
    if(!ok){observation_enabled=false;for(auto target:hook_targets){MH_DisableHook(target);if(!activation_attempted)MH_RemoveHook(target);}
        // ApplyQueued may have published some detours before reporting an
        // error. Their original-call trampolines must remain valid for callers
        // that entered them; our pinned core can retry this complete hook set.
        if(!activation_attempted)hook_targets.clear();return false;}
    observation_enabled=true;hooks_enabled=true;log("hooks","Vulkan API hooks installed from independently licensed MinHook");return true;
    }catch(...){log("hooks","Hook state allocation failed; overlay installation deferred");return false;}
}
void remove_vulkan_hooks()noexcept {
    std::lock_guard lock(mutex);observation_enabled=false;for(auto target:hook_targets)MH_DisableHook(target);
    hooks_enabled=false;
    text_keys.fill(false);raw_text_keys.fill(false);
    pending={};
    cleanup_swap();if(context){ImGui::SetCurrentContext(context);shutdown_win32();
        forget_fonts();ImGui::DestroyContext(context);context=nullptr;}
    // Keep disabled trampolines allocated: a concurrent caller may have already
    // entered one. The core is pinned for process lifetime; no dangling code.
}
}

TextureId create_texture_rgba(std::uint32_t width,std::uint32_t height,const void* pixels,std::size_t bytes,std::size_t pitch)noexcept {
    try {
        if(!active_command||render_thread!=GetCurrentThreadId()||!vulkan_ready||!pixels||!width||!height||width>8192||height>8192)return 0;
        if(!pitch)pitch=std::size_t(width)*4;
        if(pitch<std::size_t(width)*4||pitch>std::numeric_limits<std::size_t>::max()/height||bytes<pitch*height)return 0;
        auto frame=std::find_if(swap.frames.begin(),swap.frames.end(),[](auto& f){return f.command==active_command;});
        if(frame==swap.frames.end())return 0;
        // Reserve before creating/recording GPU objects: allocation failure must
        // leave no untracked descriptor or in-flight upload behind.
        textures.reserve(textures.size()+1);frame->staging.reserve(frame->staging.size()+1);
        const VkDeviceSize size=VkDeviceSize(width)*height*4;
        Texture t{};Staging staging{};
        auto fail=[&](){if(staging.buffer)api.destroy_buffer(device,staging.buffer,nullptr);if(staging.memory)api.free_memory(device,staging.memory,nullptr);destroy_texture(t);return TextureId{};};
        VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};bi.size=size;bi.usage=VK_BUFFER_USAGE_TRANSFER_SRC_BIT;bi.sharingMode=VK_SHARING_MODE_EXCLUSIVE;
        if(api.create_buffer(device,&bi,nullptr,&staging.buffer)!=VK_SUCCESS)return fail();
        VkMemoryRequirements req{};api.buffer_requirements(device,staging.buffer,&req);std::uint32_t type{};
        if(!memory_type(req.memoryTypeBits,VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,type))return fail();
        VkMemoryAllocateInfo allocation{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};allocation.allocationSize=req.size;allocation.memoryTypeIndex=type;
        if(api.allocate_memory(device,&allocation,nullptr,&staging.memory)!=VK_SUCCESS||api.bind_buffer(device,staging.buffer,staging.memory,0)!=VK_SUCCESS)return fail();
        void* mapped{};if(api.map_memory(device,staging.memory,0,size,0,&mapped)!=VK_SUCCESS)return fail();
        for(std::uint32_t y=0;y<height;++y)std::memcpy(static_cast<char*>(mapped)+std::size_t(y)*width*4,static_cast<const char*>(pixels)+std::size_t(y)*pitch,std::size_t(width)*4);
        api.unmap_memory(device,staging.memory);
        VkImageCreateInfo im{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};im.imageType=VK_IMAGE_TYPE_2D;im.format=VK_FORMAT_R8G8B8A8_UNORM;im.extent={width,height,1};
        im.mipLevels=1;im.arrayLayers=1;im.samples=VK_SAMPLE_COUNT_1_BIT;im.tiling=VK_IMAGE_TILING_OPTIMAL;im.usage=VK_IMAGE_USAGE_TRANSFER_DST_BIT|VK_IMAGE_USAGE_SAMPLED_BIT;
        if(api.create_image(device,&im,nullptr,&t.image)!=VK_SUCCESS)return fail();
        api.image_requirements(device,t.image,&req);if(!memory_type(req.memoryTypeBits,VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,type))return fail();
        allocation.allocationSize=req.size;allocation.memoryTypeIndex=type;
        if(api.allocate_memory(device,&allocation,nullptr,&t.memory)!=VK_SUCCESS||api.bind_image(device,t.image,t.memory,0)!=VK_SUCCESS)return fail();
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};vi.image=t.image;vi.viewType=VK_IMAGE_VIEW_TYPE_2D;vi.format=im.format;vi.subresourceRange={VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
        if(api.create_view(device,&vi,nullptr,&t.view)!=VK_SUCCESS)return fail();
        VkSamplerCreateInfo si{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};si.magFilter=VK_FILTER_LINEAR;si.minFilter=VK_FILTER_LINEAR;si.mipmapMode=VK_SAMPLER_MIPMAP_MODE_NEAREST;
        si.addressModeU=si.addressModeV=si.addressModeW=VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;si.maxLod=0;
        if(api.create_sampler(device,&si,nullptr,&t.sampler)!=VK_SUCCESS)return fail();
        t.descriptor=ImGui_ImplVulkan_AddTexture(t.sampler,t.view,VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);if(!t.descriptor)return fail();
        VkImageMemoryBarrier barrier{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};barrier.oldLayout=VK_IMAGE_LAYOUT_UNDEFINED;barrier.newLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        barrier.dstAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;barrier.srcQueueFamilyIndex=barrier.dstQueueFamilyIndex=VK_QUEUE_FAMILY_IGNORED;barrier.image=t.image;barrier.subresourceRange=vi.subresourceRange;
        api.barrier(active_command,VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,0,nullptr,1,&barrier);
        VkBufferImageCopy copy{};copy.imageSubresource={VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};copy.imageExtent={width,height,1};
        api.copy_image(active_command,staging.buffer,t.image,VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,1,&copy);
        barrier.oldLayout=VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;barrier.newLayout=VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;barrier.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;barrier.dstAccessMask=VK_ACCESS_SHADER_READ_BIT;
        api.barrier(active_command,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,0,0,nullptr,0,nullptr,1,&barrier);
        t.id=static_cast<TextureId>(reinterpret_cast<std::uintptr_t>(t.descriptor));textures.push_back(t);
        frame->staging.push_back(staging);return t.id;
    }catch(...){return 0;}
}
void defer_destroy_texture(TextureId id)noexcept {
    if(render_thread!=GetCurrentThreadId())return;for(auto& texture:textures)if(texture.id==id)texture.retired=true;
}
}
