// First-API barrier for Vulkan startup.
#include <windows.h>
#include <string>
#include "proxy_exports.hpp"
namespace {
HMODULE self{},system_module{};INIT_ONCE once=INIT_ONCE_STATIC_INIT;
extern "C" ULONG_PTR unavailable_pointer()noexcept{return 0;}
extern "C" LONG unavailable_result()noexcept{return -3;} // VK_ERROR_INITIALIZATION_FAILED
BOOL CALLBACK initialize(PINIT_ONCE,void*,void**)noexcept{
    try{
        wchar_t system[32768]{};auto count=GetSystemDirectoryW(system,32768);if(!count||count>=32768)return FALSE;
        std::wstring path(system,count);path+=L"\\vulkan-1.dll";
        system_module=LoadLibraryExW(path.c_str(),nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32);if(!system_module||system_module==self)return FALSE;
        // Missing/unsupported Scanner never gates the engine's real Vulkan.
        wchar_t name[32768]{};count=GetModuleFileNameW(self,name,32768);
        if(count&&count<32768){path.assign(name,count);auto slash=path.find_last_of(L"\\/");
            if(slash!=std::wstring::npos){path.resize(slash+1);path+=L"ResourceScanner\\ResourceScannerCore.dll";
                auto core=LoadLibraryExW(path.c_str(),nullptr,LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR|LOAD_LIBRARY_SEARCH_SYSTEM32);
                if(core){auto start=reinterpret_cast<BOOL(*)()>(GetProcAddress(core,"ResourceScannerStart"));
                    auto prepare=reinterpret_cast<BOOL(*)()>(GetProcAddress(core,"ResourceScannerPrepareVulkan"));
                    if(start&&prepare&&start())prepare();}}}
        return TRUE;
    }catch(...){return system_module!=nullptr;}
}
}
extern "C" FARPROC rs_resolve_proxy_export(unsigned index)noexcept{
    if(index>=rs_proxy_export_count)return reinterpret_cast<FARPROC>(unavailable_pointer);
    const auto& entry=rs_proxy_exports[index];
    if(InitOnceExecuteOnce(&once,initialize,nullptr,nullptr)){
        auto address=GetProcAddress(system_module,entry.name?entry.name:MAKEINTRESOURCEA(entry.ordinal));
        if(address)return address;
    }
    // A failed creation must not masquerade as VK_SUCCESS. Pointer-returning
    // unsupported lookups remain null. Void commands safely do no work.
    return entry.fallback_kind?reinterpret_cast<FARPROC>(unavailable_result):reinterpret_cast<FARPROC>(unavailable_pointer);
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID){
    if(reason==DLL_PROCESS_ATTACH){self=module;DisableThreadLibraryCalls(module);}return TRUE;
}
