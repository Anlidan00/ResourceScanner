#include "internal.hpp"
#include <rs/platform/render.hpp>
#include <rs/platform/paths.hpp>
#ifdef RS_HAVE_UI
#include <rs/ui.hpp>
#endif
#include <rs/game/adapter.hpp>
#include <rs/platform/texture.hpp>
#include <rs/platform/font.hpp>

extern "C" __declspec(dllexport) BOOL ResourceScannerSetRenderClient(const rs::platform::RenderClient* client) noexcept {
    return client&&rs::platform::set_render_client(*client)?TRUE:FALSE;
}
extern "C" __declspec(dllexport) std::uint64_t ResourceScannerCreateTextureRGBA(std::uint32_t w,std::uint32_t h,const void* bytes,std::size_t count,std::size_t pitch) noexcept {
    return rs::platform::create_texture_rgba(w,h,bytes,count,pitch);
}
extern "C" __declspec(dllexport) void ResourceScannerDeferDestroyTexture(std::uint64_t value) noexcept {
    rs::platform::defer_destroy_texture(value);
}
extern "C" __declspec(dllexport) ImFont* ResourceScannerFont(const char* role) noexcept {
    return role&&rs::platform::font_available(role)?rs::platform::font(role):nullptr;
}

extern "C" __declspec(dllexport) BOOL ResourceScannerStart() noexcept {
    // Hooks and window callbacks can outlive the initiating loader. Pin only our
    // own module, never a game object; explicit Stop detaches active work.
    HMODULE self{};if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,
        reinterpret_cast<LPCWSTR>(&ResourceScannerStart),&self))return FALSE;
    rs::platform::RenderClient client{};
#ifdef RS_HAVE_UI
    client.render=rs::ui::render;
#endif
    client.sample_game=rs::game::sample;
    if(!rs::platform::set_render_client(client))return FALSE;
    return rs::platform::start()?TRUE:FALSE;
}
extern "C" __declspec(dllexport) BOOL ResourceScannerPrepareVulkan() noexcept {
    // Only the first-API proxy calls this, outside DllMain and BEFORE returning
    // any real Vulkan API pointer to the engine's startup cache.
    const bool ready=rs::platform::detail::install_vulkan_hooks();
    rs::platform::log("bootstrap",ready?"Synchronous Vulkan first-call barrier ready":"Vulkan barrier unavailable; real API forwarding retained");
    return ready?TRUE:FALSE;
}
extern "C" __declspec(dllexport) BOOL ResourceScannerStop(DWORD timeout_ms) noexcept {
    if(!rs::platform::stop(timeout_ms))return FALSE;
#ifdef RS_HAVE_UI
    if(!rs::ui::finish_loading(timeout_ms))return FALSE;
#endif
    return TRUE;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID) {
    if(reason==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(module);rs::platform::detail::set_module(module);}
    // No allocation, hook teardown, waits, or external calls under loader lock.
    return TRUE;
}
