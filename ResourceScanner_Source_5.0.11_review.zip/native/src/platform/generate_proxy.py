"""Generate our argument-preserving forwarders from the OS export interface.

Only PE export names/ordinals are read; no system or game code is copied.
"""
from pathlib import Path
import argparse, ctypes, hashlib, json, struct,xml.etree.ElementTree as ET
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--library',choices=['dbghelp','vulkan-1'],default='dbghelp');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    b=ctypes.create_unicode_buffer(32768);assert ctypes.windll.kernel32.GetSystemDirectoryW(b,32768)
    source=Path(b.value)/(a.library+'.dll');raw=source.read_bytes();nt=struct.unpack_from('<I',raw,60)[0]
    assert raw[:2]==b'MZ' and raw[nt:nt+4]==b'PE\0\0'
    sections=struct.unpack_from('<H',raw,nt+6)[0];optional=nt+24;optbytes=struct.unpack_from('<H',raw,nt+20)[0]
    assert struct.unpack_from('<H',raw,optional)[0]==0x20b
    def off(rva):
        for i in range(sections):
            pos=optional+optbytes+i*40;vsize,va,size,ptr=struct.unpack_from('<IIII',raw,pos+8)
            if va<=rva<va+max(vsize,size):return ptr+rva-va
        raise ValueError('Export RVA not backed by a section')
    er,es=struct.unpack_from('<II',raw,optional+112);ep=off(er)
    base,nfunc,nnames,functions,names,ordinals=struct.unpack_from('<IIIIII',raw,ep+16)
    byordinal={}
    for i in range(nnames):
        rva=struct.unpack_from('<I',raw,off(names)+4*i)[0];pos=off(rva);end=raw.index(0,pos)
        name=raw[pos:end].decode('ascii');ordinal=base+struct.unpack_from('<H',raw,off(ordinals)+2*i)[0]
        byordinal.setdefault(ordinal,[]).append(name)
    entries=[]
    for i in range(nfunc):
        if struct.unpack_from('<I',raw,off(functions)+4*i)[0]:entries.append((base+i,byordinal.get(base+i,[])))
    assert any(('MiniDumpWriteDump'if a.library=='dbghelp'else'vkGetInstanceProcAddr')in names for _,names in entries)
    types={}
    if a.library=='vulkan-1':
        registry=Path(__file__).resolve().parents[2]/'third_party/vulkan_headers/registry/vk.xml'
        commands=ET.parse(registry).getroot().find('commands')
        for command in commands:
            proto=command.find('proto')
            if proto is not None:types[proto.findtext('name')]=proto.findtext('type')
        for command in commands:
            if command.get('alias'):types[command.get('name')]=types[command.get('alias')]
    definition=['LIBRARY '+a.library,'EXPORTS'];header=['#pragma once','#include <cstddef>','struct RsProxyExport { const char* name; unsigned short ordinal; unsigned char fallback_kind; };','inline constexpr RsProxyExport rs_proxy_exports[] = {']
    assembly=['option casemap:none','EXTERN rs_resolve_proxy_export:PROC','.code']
    for index,(ordinal,names)in enumerate(entries):
        label=f'rs_forward_{index}'
        if names:
            for j,name in enumerate(names):definition.append(f'    {name}={label}'+(f' @{ordinal}'if j==0 else''))
        else:definition.append(f'    {label} @{ordinal} NONAME')
        kind=1 if types.get(names[0]if names else'')=='VkResult'else 0
        if a.library=='vulkan-1'and names:assert names[0]in types,('Unknown Vulkan export return type',names)
        header.append('    {'+(json.dumps(names[0])if names else'nullptr')+f', {ordinal}, {kind}'+'},')
        assembly += [f'{label} PROC FRAME','    sub rsp, 0B8h','    .allocstack 0B8h','    .endprolog','    mov [rsp+20h], rcx','    mov [rsp+28h], rdx','    mov [rsp+30h], r8','    mov [rsp+38h], r9']
        for j in range(6):assembly.append(f'    movdqu [rsp+{0x40+j*16:02X}h], xmm{j}')
        assembly += [f'    mov ecx, {index}','    call rs_resolve_proxy_export','    mov [rsp+0A0h], rax']
        for j in range(6):assembly.append(f'    movdqu xmm{j}, [rsp+{0x40+j*16:02X}h]')
        assembly += ['    mov rcx, [rsp+20h]','    mov rdx, [rsp+28h]','    mov r8, [rsp+30h]','    mov r9, [rsp+38h]','    mov rax, [rsp+0A0h]','    add rsp, 0B8h','    jmp rax',f'{label} ENDP']
    header+=['};','inline constexpr unsigned rs_proxy_export_count=sizeof(rs_proxy_exports)/sizeof(rs_proxy_exports[0]);'];assembly+=['END']
    for name,text in [('proxy.def','\n'.join(definition)),('proxy_exports.hpp','\n'.join(header)),('proxy.asm','\n'.join(assembly))]:(a.out/name).write_text(text+'\n',encoding='utf8')
    (a.out/'EXPORT_INTERFACE.json').write_text(json.dumps(dict(source=str(source),source_sha256=hashlib.sha256(raw).hexdigest(),
        input_scope='PE export names and ordinals only; no code bytes included',exports=entries),indent=2),encoding='utf8')
if __name__=='__main__':main()
