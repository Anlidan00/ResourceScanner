#include "internal.hpp"
#include <rs/platform/paths.hpp>
#include <atomic>
#include <mutex>
#include <rs/game/adapter.hpp>
#include <rs/platform/helper.hpp>
namespace rs::platform {
namespace { std::mutex mutex;RenderClient current{};HANDLE thread{};std::atomic<bool> stopping_flag{true};HelperProcess helper; }
namespace detail {
RenderClient client()noexcept{std::lock_guard lock(mutex);return current;}
bool stopping()noexcept{return stopping_flag.load(std::memory_order_acquire);}
}
bool set_render_client(const RenderClient& value)noexcept{
    if(value.structure_bytes!=sizeof(RenderClient)||value.version!=1)return false;
    std::lock_guard lock(mutex);current=value;return true;
}
namespace {
DWORD WINAPI worker(void*) {
    HANDLE event{};DWORD status{};
    try {
    log("startup","Independent source core 5.0.11 started");
    // Engine creation can immediately follow process attach. Observe Vulkan
    // before source observers or the helper perform their slower startup work.
    while(!detail::stopping()&&!detail::install_vulkan_hooks())Sleep(1);
    if(!detail::stopping()){
    game::start_adapter();
    game::Frame initial{};initial.sequence=1;initial.sampled_at_ms=GetTickCount64();detail::publish(initial);
    auto event_name=L"Local\\ResourceScanner.Stop.v1."+std::to_wstring(GetCurrentProcessId())+L"."+std::to_wstring(instance_nonce());
    event=CreateEventW(nullptr,TRUE,FALSE,event_name.c_str());
    if(event){ResetEvent(event);if(!helper.start(data_directory().wstring(),
        {L"python/pythonw.exe",L"runtime/main.py",GetCurrentProcessId(),detail::process_birth(),event_name}))
            log("helper","Helper executable/script unavailable or launch failed");}
    else log("helper","Cooperative stop event unavailable; helper not started");
    while(!detail::stopping())Sleep(25);
    }
    }catch(...){status=ERROR_NOT_ENOUGH_MEMORY;log("startup","Core worker could not allocate its local state; overlay stopped");}
    // Every exit, including an immediate Stop or allocation failure, retires
    // the synchronous bootstrap hooks and publication before completing.
    stopping_flag.store(true,std::memory_order_release);
    if(event)SetEvent(event);
    const bool helper_stopped=helper.wait_exit(1500);if(helper_stopped)helper.close_handles();
    game::stop_adapter();detail::remove_vulkan_hooks();detail::close_publication();log("shutdown",helper_stopped?"Core stopped":"Core stopped; helper exit still pending");
    if(event)CloseHandle(event);
    return status?status:helper_stopped?0:ERROR_TIMEOUT;
}
}
bool start()noexcept{
    std::lock_guard lock(mutex);
    // A failed/completed worker is not a successful Start. Stop owns reaping
    // its handle; Start must not close a handle another Stop may be waiting on.
    if(thread)return WaitForSingleObject(thread,0)==WAIT_TIMEOUT;
    if(!helper.wait_exit(0))return false;
    stopping_flag=false;
    // Start is called by our loader worker, outside DllMain. If Vulkan is
    // already imported, finish interception before returning to that worker.
    detail::install_vulkan_hooks();
    thread=CreateThread(nullptr,0,worker,nullptr,0,nullptr);
    if(!thread){stopping_flag=true;detail::remove_vulkan_hooks();return false;}return true;
}
void request_stop()noexcept{stopping_flag.store(true,std::memory_order_release);}
bool stop(std::uint32_t timeout)noexcept{
    request_stop();HANDLE handle{};{std::lock_guard lock(mutex);handle=thread;}
    if(!handle)return true;if(WaitForSingleObject(handle,timeout)!=WAIT_OBJECT_0)return false;
    DWORD status{};GetExitCodeThread(handle,&status);
    std::lock_guard lock(mutex);if(thread==handle){CloseHandle(thread);thread=nullptr;}return status==0;
}
}
