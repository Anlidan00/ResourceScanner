// Actual own Vulkan bootstrap, with only MinHook activation boundaries faked.
#define MH_Initialize fault_MH_Initialize
#define MH_CreateHook fault_MH_CreateHook
#define MH_EnableHook fault_MH_EnableHook
#define MH_DisableHook fault_MH_DisableHook
#define MH_RemoveHook fault_MH_RemoveHook
#define MH_QueueEnableHook fault_MH_QueueEnableHook
#define MH_ApplyQueued fault_MH_ApplyQueued
#include "vulkan_render.cpp"
#include "vulkan_layer_smoke.hpp"
#include <cstdio>
namespace {unsigned created{},removed{},disabled{},applied{};bool fail_apply=true,fail_queue=false;}
static void VKAPI_CALL fake_queue2(VkDevice,const VkDeviceQueueInfo2*,VkQueue* out){*out=reinterpret_cast<VkQueue>(std::uintptr_t(0x12345678));}
extern "C" MH_STATUS WINAPI fault_MH_Initialize(){return MH_OK;}
extern "C" MH_STATUS WINAPI fault_MH_CreateHook(LPVOID target,LPVOID,LPVOID* original){++created;if(original)*original=target;return MH_OK;}
extern "C" MH_STATUS WINAPI fault_MH_EnableHook(LPVOID){return MH_OK;}
extern "C" MH_STATUS WINAPI fault_MH_DisableHook(LPVOID){++disabled;return MH_OK;}
extern "C" MH_STATUS WINAPI fault_MH_RemoveHook(LPVOID){++removed;return MH_OK;}
extern "C" MH_STATUS WINAPI fault_MH_QueueEnableHook(LPVOID){return fail_queue?MH_ERROR_MEMORY_ALLOC:MH_OK;}
extern "C" MH_STATUS WINAPI fault_MH_ApplyQueued(){++applied;return fail_apply?MH_ERROR_MEMORY_ALLOC:MH_OK;}
int main(){
    using namespace rs::platform;
    if(auto result=layer_fixture::run())return result+100;
    const auto original=reinterpret_cast<PFN_vkVoidFunction>(fake_queue2);
    get_queue2=nullptr;
    auto routed=reinterpret_cast<PFN_vkGetDeviceQueue2>(replacement("vkGetDeviceQueue2",original,{}));VkQueue observed{};VkDeviceQueueInfo2 queue_info{VK_STRUCTURE_TYPE_DEVICE_QUEUE_INFO_2};
    routed(reinterpret_cast<VkDevice>(std::uintptr_t(0x11111111)),&queue_info,&observed);
    if(observed!=reinterpret_cast<VkQueue>(std::uintptr_t(0x12345678)))return 1;
    if(replacement("vkGetDeviceQueue2",nullptr,{})!=nullptr)return 2;
    if(!LoadLibraryExW(L"vulkan-1.dll",nullptr,LOAD_LIBRARY_SEARCH_SYSTEM32))return 3;
    if(detail::install_vulkan_hooks()||created<10||removed||disabled!=created||applied!=1)return 4;
    const auto first_count=created;
    // A second failed activation must reuse, disable, and retain the SAME set.
    if(detail::install_vulkan_hooks()||created!=first_count||removed||disabled!=2*created||applied!=2)return 5;
    fail_apply=false;
    if(!detail::install_vulkan_hooks()||created!=first_count||removed||applied!=3)return 6;
    detail::remove_vulkan_hooks();
    if(removed||disabled!=3*created)return 7;
    std::puts("PASS optional Queue2 passthrough; failed activation retains disabled original-call trampolines; retry reuses set; stop retains in-flight code");
    return 0;
}
