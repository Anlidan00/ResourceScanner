## 5.0.11

- Updated compatibility with Enshrouded 1285601.
- Improved resilience to future updates by removing unnecessary dependencies on the game's internal code.
- Improved detection of map, language, character and learned-item structures.
- Failures in individual optional features have less impact on the others.
- Fixed waypoint handling when closing the map and changing the game context.
- Strengthened checks that map data and the selected save are current.
