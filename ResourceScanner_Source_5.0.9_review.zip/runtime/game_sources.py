"""Active character, appearance and save-store readers."""
import ctypes,ctypes.wintypes as w,struct
from pathlib import Path
from dataclasses import dataclass
@dataclass(frozen=True)
class Hero:
    index: int
    backend: int
    manager: int
    directory: str = ''

@dataclass(frozen=True)
class SaveStore:
    path: Path
    backend: int
    steam_account: int | None
    discovery_source: str
    base: Path | None = None

def pointer(read, address):
    value = struct.unpack('<Q', read(address, 8))[0]
    if not 65536 <= value < 140737488289792:
        raise ValueError('Invalid game pointer')
    return value

def selected_appearance(read, application, layout=None):
    """Current native user-profile display setting; independent of hero slot.

    The verified native UI caller reads this field. Mode0 means unknown; no
    conditional image is admitted until a stable supported profile is known.
    """
    if layout is None:
        layout = dict(manager=1448, profile=218680, slots=2664, stride=776, active=760, value=511)
    manager_offset, profile_offset = layout['manager'], layout['profile']
    manager = pointer(read, application + manager_offset)
    profile = struct.unpack('<I', read(application + profile_offset, 4))[0]
    if not profile:
        return 0
    slot = manager + layout['slots'] + (profile & 15) * layout['stride']
    identity = struct.unpack('<I', read(slot, 4))[0]
    if identity != profile or not read(slot + 8 + layout['active'], 1)[0]:
        return 0
    value = read(slot + 8 + layout['value'], 1)[0]
    if value not in (0, 1):
        return 0
    if pointer(read, application + manager_offset) != manager or struct.unpack('<I', read(application + profile_offset, 4))[0] != profile or struct.unpack('<I', read(slot, 4))[0] != identity or (not read(slot + 8 + layout['active'], 1)[0]) or (read(slot + 8 + layout['value'], 1)[0] != value):
        return 0
    return value + 1

def selected_directory(read, manager):
    address = manager + 1153808
    head = read(address + 8, 8)
    sizes = read(address + 2096, 16)
    length = sum(struct.unpack('<QQ', sizes))
    if length > 4096:
        raise ValueError('Active save directory is too long')
    if not length:
        return ''
    value = struct.unpack('<Q', head)[0]
    if not 65536 <= value < 140737488289792:
        raise ValueError('Invalid save-directory pointer')
    data = read(value, length)
    if read(address + 8, 8) != head or read(address + 2096, 16) != sizes or read(value, length) != data:
        raise ValueError('Save directory changed during selection read')
    text = data.decode('utf-8')
    if not text or '\x00' in text:
        raise ValueError('Invalid active save directory')
    return text

def selected_hero(read, manager):
    selected = read(manager + 1151678, 3)
    slot, backend, valid = selected
    if valid != 1 or not 1 <= slot <= 16 or backend not in (0, 1):
        raise ValueError('Active hero is not selected')
    loaded = read(manager + 1105710, 3)
    if loaded[:2] != selected[:2] or loaded[2] not in (2, 3):
        raise ValueError('Active hero is loading')
    directory = selected_directory(read, manager) if backend == 0 else ''
    if selected != read(manager + 1151678, 3):
        raise ValueError('Hero changed during selection read')
    return Hero(slot - 1, backend, manager, directory)

class MODULEENTRY32W(ctypes.Structure):
    _fields_ = [('size', w.DWORD), ('id', w.DWORD), ('pid', w.DWORD), ('usage', w.DWORD), ('processUsage', w.DWORD), ('base', ctypes.c_void_p), ('bytes', w.DWORD), ('module', w.HMODULE), ('name', w.WCHAR * 256), ('path', w.WCHAR * 260)]

def saved_games_folder():
    """Current (possibly redirected) Windows SavedGames path; never create it."""

    class GUID(ctypes.Structure):
        _fields_ = [('bytes', ctypes.c_ubyte * 16)]
    folder = GUID((ctypes.c_ubyte * 16).from_buffer_copy(bytes.fromhex('ff325c4c9dbbb043b5b42d72e54eaaa4')))
    ole = ctypes.WinDLL('ole32', use_last_error=True)
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    ole.CoInitializeEx.argtypes = [ctypes.c_void_p, w.DWORD]
    ole.CoInitializeEx.restype = ctypes.c_int32
    ole.CoTaskMemFree.argtypes = [ctypes.c_void_p]
    ole.CoTaskMemFree.restype = None
    ole.CoUninitialize.argtypes = []
    ole.CoUninitialize.restype = None
    shell.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), w.DWORD, w.HANDLE, ctypes.POINTER(ctypes.c_void_p)]
    shell.SHGetKnownFolderPath.restype = ctypes.c_int32
    hr = ole.CoInitializeEx(None, 0)
    initialized = hr >= 0
    if hr < 0 and hr != -2147417850:
        raise OSError(hr, 'SavedGames COM initialization failed')
    result = ctypes.c_void_p()
    try:
        hr = shell.SHGetKnownFolderPath(ctypes.byref(folder), 4096, None, ctypes.byref(result))
        if hr < 0 or not result.value:
            raise OSError(hr, 'SavedGames known folder unavailable')
        text = ctypes.wstring_at(result.value)
        path = Path(text)
        if not text or len(text) > 32767 or (not path.is_absolute()):
            raise ValueError('Invalid SavedGames known-folder path')
        return path
    finally:
        if result.value:
            ole.CoTaskMemFree(result)
        if initialized:
            ole.CoUninitialize()

def steam_context():
    import winreg
    roots = []
    account = None
    for hive, key, name in [(winreg.HKEY_CURRENT_USER, 'Software\\Valve\\Steam', 'SteamPath'), (winreg.HKEY_LOCAL_MACHINE, 'SOFTWARE\\WOW6432Node\\Valve\\Steam', 'InstallPath')]:
        try:
            with winreg.OpenKey(hive, key) as h:
                roots.append(Path(winreg.QueryValueEx(h, name)[0]))
        except OSError:
            pass
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Software\\Valve\\Steam\\ActiveProcess') as h:
            value = int(winreg.QueryValueEx(h, 'ActiveUser')[0])
            if 0 < value <= 4294967295:
                account = value
    except (OSError, ValueError, TypeError):
        pass
    return (roots, account)

def save_roots(game_dir, steam_roots, account, *, saved_games=None):
    """Discover local and account-bound Steam character stores."""
    stores = []
    try:
        folder = saved_games_folder() if saved_games is None else Path(saved_games)
        if not folder.is_absolute():
            raise ValueError('SavedGames path is not absolute')
        local = folder / 'Enshrouded'
        stores.append(SaveStore(local.resolve(), 0, None, 'Windows SavedGames', folder.resolve()))
    except (OSError, ValueError):
        pass
    if type(account) is not int or not 0 < account <= 4294967295:
        return stores
    steam = [(Path(p), 'Steam registry') for p in steam_roots]
    for parent in Path(game_dir).parents:
        if (parent / 'userdata').is_dir():
            steam.append((parent, 'game ancestor'))
    seen = set()
    for root, source in steam:
        remote = root / 'userdata' / str(account) / '1203620' / 'remote'
        if remote.is_dir():
            path = remote.resolve()
            if path not in seen:
                seen.add(path)
                stores.append(SaveStore(path, 1, account, source))
    return stores

def character_for(hero, roots):
    if type(hero.index) is not int or not 0 <= hero.index < 16 or hero.backend not in (0, 1):
        raise ValueError('Invalid active hero identity')
    if any((not isinstance(s, SaveStore) for s in roots)):
        raise ValueError('Untyped save stores are not accepted')
    selected = [s for s in roots if s.backend == hero.backend]
    if hero.backend == 0 and hero.directory:
        directory = Path(hero.directory)
        if directory.drive and (not directory.is_absolute()):
            raise ValueError('Drive-relative active save directory is unsupported')
        if directory.is_absolute():
            selected = [SaveStore(directory.resolve(), 0, None, 'active absolute SaveDirectory')]
        else:
            selected = [SaveStore((s.base / directory).resolve(), 0, None, 'active relative SaveDirectory', s.base) for s in selected if s.base is not None]
    if hero.backend == 1:
        accounts = {s.steam_account for s in selected}
        if not selected or len(accounts) != 1 or None in accounts:
            raise ValueError('Steam account of the active hero is unresolved')
    candidates = []
    for store in selected:
        p = store.path / f'character{hero.index}.ksd'
        if p.is_file():
            st = p.stat()
            if not 48 <= st.st_size <= 32 * 1024 * 1024:
                continue
            with p.open('rb') as f:
                head = f.read(48)
            if head[:6] != b'SV2C\x02\x00' or not any(head[12:28]):
                continue
            candidates.append((p, head[12:28], st))
    if not candidates:
        raise ValueError('Save of the active hero is not available in its selected store')
    if len({guid for p, guid, st in candidates}) != 1:
        raise ValueError('Matching active stores contain different heroes in the selected slot')
    return max(candidates, key=lambda item: item[2].st_mtime_ns)[0]

def process_creation_time(owner):
    kernel = owner.k
    kernel.GetProcessTimes.argtypes = [w.HANDLE, ctypes.POINTER(w.FILETIME), ctypes.POINTER(w.FILETIME), ctypes.POINTER(w.FILETIME), ctypes.POINTER(w.FILETIME)]
    kernel.GetProcessTimes.restype = w.BOOL
    created, exited, kernel_time, user_time = (w.FILETIME() for _ in range(4))
    if not kernel.GetProcessTimes(owner.handle, ctypes.byref(created), ctypes.byref(exited), ctypes.byref(kernel_time), ctypes.byref(user_time)):
        raise OSError(ctypes.get_last_error(), 'Parent creation time unavailable')
    return (created.dwLowDateTime, created.dwHighDateTime)
