"""Read-only process access bound to the current game instance."""
import ctypes,ctypes.wintypes as w,struct
from pathlib import Path
from game_sources import MODULEENTRY32W,selected_appearance
from compatibility import Image
class ReadOnlyGameBase:

    def __init__(self, pid, *, validate_hero=True):
        self.pid = pid
        self.k = ctypes.WinDLL('kernel32', use_last_error=True)
        k = self.k
        k.CreateToolhelp32Snapshot.argtypes = [w.DWORD, w.DWORD]
        k.CreateToolhelp32Snapshot.restype = w.HANDLE
        for name in ('Module32FirstW', 'Module32NextW'):
            getattr(k, name).argtypes = [w.HANDLE, ctypes.POINTER(MODULEENTRY32W)]
            getattr(k, name).restype = w.BOOL
        k.CloseHandle.argtypes = [w.HANDLE]
        k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
        k.OpenProcess.restype = w.HANDLE
        k.ReadProcessMemory.argtypes = [w.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
        k.ReadProcessMemory.restype = w.BOOL
        k.GetExitCodeProcess.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
        k.GetExitCodeProcess.restype = w.BOOL
        snapshot = k.CreateToolhelp32Snapshot(24, pid)
        if snapshot == ctypes.c_void_p(-1).value:
            raise OSError(ctypes.get_last_error(), 'Game module unavailable')
        try:
            entry = MODULEENTRY32W()
            entry.size = ctypes.sizeof(entry)
            ctypes.set_last_error(0)
            ok = k.Module32FirstW(snapshot, ctypes.byref(entry))
            found = False
            while ok:
                if entry.name.lower() == 'enshrouded.exe':
                    found = True
                    break
                ctypes.set_last_error(0)
                ok = k.Module32NextW(snapshot, ctypes.byref(entry))
            if not found:
                error=ctypes.get_last_error()
                if error!=18:raise OSError(error,'Game module enumeration unavailable')
                raise ValueError('Parent is not Enshrouded')
            self.path = Path(entry.path)
            self.base = entry.base
        finally:
            k.CloseHandle(snapshot)
        self.handle = k.OpenProcess(4112, False, pid)
        if not self.handle:
            raise OSError(ctypes.get_last_error(), 'Read-only game context unavailable')
        self.application = None
        self._appearance_supported = None
        self._appearance_layout = None
        try:
            self.image=Image(self.path)
            if validate_hero:self.image.verify('hero',self.read,self.base)
        except Exception:
            self.close()
            raise

    def read(self, address, size):
        if not 0 < size <= 4096:
            raise ValueError('Unbounded read refused')
        data = ctypes.create_string_buffer(size)
        got = ctypes.c_size_t()
        if not self.k.ReadProcessMemory(self.handle, address, data, size, ctypes.byref(got)) or got.value != size:
            raise OSError(ctypes.get_last_error(), 'Game context unavailable')
        return data.raw

    def running(self):
        code = w.DWORD()
        return bool(self.k.GetExitCodeProcess(self.handle, ctypes.byref(code))) and code.value == 259

    def appearance(self):
        try:
            if self.application is None:
                return 0
            if self._appearance_supported is None:
                image=getattr(self,'image',None)
                if image is None:return 0
                try:self._appearance_layout=image.appearance_layout(self.read,self.base);self._appearance_supported=True
                except OSError:return 0
                except ValueError:self._appearance_supported=False
            if not self._appearance_supported:
                return 0
            return selected_appearance(self.read, self.application, self._appearance_layout)
        except (OSError, ValueError, struct.error):
            return 0

    def close(self):
        if getattr(self, 'handle', None):
            self.k.CloseHandle(self.handle)
            self.handle = None
