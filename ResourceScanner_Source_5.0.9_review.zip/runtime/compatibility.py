import json,struct
from pathlib import Path

class LayoutUnavailable(ValueError):
    pass

class Image:
    def __init__(self,path):
        path=Path(path);before=path.stat()
        if not 4096<=before.st_size<=512*1024*1024:raise LayoutUnavailable('Module size outside bounds')
        with path.open('rb')as stream:self.data=stream.read(512*1024*1024+1)
        after=path.stat()
        if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns)or len(self.data)!=before.st_size:raise OSError('Module changed while reading')
        self.sections=[];self.cache={}
        try:self._headers()
        except (struct.error,IndexError,OverflowError)as error:raise LayoutUnavailable('Invalid module headers')from error
        file=Path(__file__).with_name('compat_profile.json')
        try:
            with file.open('rb')as stream:raw=stream.read(128*1024+1)
        except OSError as error:raise LayoutUnavailable('Source pattern data unavailable')from error
        if len(raw)>128*1024:raise LayoutUnavailable('Source patterns outside bounds')
        try:
            self.profiles=json.loads(raw)
            if not isinstance(self.profiles,dict):raise ValueError()
            for group in ('hero','appearance','knowledge'):
                rows=self.profiles.get(group)
                if not isinstance(rows,list)or not 1<=len(rows)<=64:raise ValueError()
                keys=[self._pattern(row)[0]for row in rows]
                if len(keys)!=len(set(keys)):raise ValueError()
            if 'controller'not in [row[0]for row in self.profiles['knowledge']]:raise ValueError()
            links=self.profiles.get('knowledge_links')
            if not isinstance(links,list)or not 1<=len(links)<=64:raise ValueError()
            for row in links:
                if not isinstance(row,list)or len(row)!=5:raise ValueError()
                key,caller,offset,data,mask=row
                data=bytes.fromhex(data);mask=bytes.fromhex(mask)
                if not isinstance(key,str)or not isinstance(caller,str)or type(offset)is not int or offset<0 or not 1<=len(data)<=128 or len(mask)!=len(data)or any(b not in (0,255)for b in mask)or not any(mask):raise ValueError()
        except (ValueError,TypeError,KeyError)as error:raise LayoutUnavailable('Invalid source pattern data')from error
    def _headers(self):
        d=self.data
        if d[:2]!=b'MZ':raise LayoutUnavailable('Invalid module format')
        nt=struct.unpack_from('<I',d,60)[0]
        if nt>1024*1024 or d[nt:nt+4]!=b'PE\0\0':raise LayoutUnavailable('Invalid module signature')
        machine,n=struct.unpack_from('<HH',d,nt+4);optional=struct.unpack_from('<H',d,nt+20)[0];at=nt+24
        if machine!=0x8664 or not 1<=n<=96 or optional<240 or struct.unpack_from('<H',d,at)[0]!=0x20B:raise LayoutUnavailable('Unsupported module layout')
        self.preferred_base=struct.unpack_from('<Q',d,at+24)[0];self.size,self.headers=struct.unpack_from('<II',d,at+56)
        if not 4096<=self.size<=1024*1024*1024 or not 0<self.headers<=len(d):raise LayoutUnavailable('Invalid module bounds')
        for i in range(n):
            p=at+optional+i*40;vs,rva,length,offset=struct.unpack_from('<IIII',d,p+8);flags=struct.unpack_from('<I',d,p+36)[0];span=max(vs,length)
            if rva<self.headers or rva>self.size or span>self.size-rva or offset>len(d)or length>len(d)-offset:raise LayoutUnavailable('Invalid module section')
            if any(rva<old[0]+old[1]and old[0]<rva+span for old in self.sections):raise LayoutUnavailable('Overlapping module sections')
            self.sections.append((rva,span,offset,length,flags))
    def read(self,rva,size):
        if type(rva)is not int or type(size)is not int or rva<0 or size<0 or rva>self.size or size>self.size-rva:raise LayoutUnavailable('Module address outside bounds')
        if rva<self.headers and size<=self.headers-rva:return self.data[rva:rva+size]
        for start,span,offset,length,flags in self.sections:
            if start<=rva and rva-start<=length and size<=length-(rva-start):return self.data[offset+rva-start:offset+rva-start+size]
        raise LayoutUnavailable('Module bytes are not file-backed')
    def executable(self,rva,size=1):
        return any(flags&0x20000000 and start<=rva and rva-start<=span and size<=span-(rva-start)for start,span,offset,length,flags in self.sections)
    @staticmethod
    def _pattern(row):
        if not isinstance(row,list)or len(row)!=3:raise LayoutUnavailable('Invalid source pattern')
        key,raw,mask=row
        try:data=bytes.fromhex(raw);mask=bytes.fromhex(mask)
        except (ValueError,TypeError)as error:raise LayoutUnavailable('Invalid source pattern encoding')from error
        if not isinstance(key,str)or not 12<=len(data)<=512 or len(data)!=len(mask)or any(b not in (0,255)for b in mask):raise LayoutUnavailable('Invalid source pattern size')
        runs=[];start=None
        for i,b in enumerate(mask+b'\0'):
            if b==255 and start is None:start=i
            if b!=255 and start is not None:runs.append((i-start,start));start=None
        if not runs or max(runs)[0]<4:raise LayoutUnavailable('Source pattern has no anchor')
        return key,data,mask,max(runs)
    def resolve(self,group):
        if group in self.cache:
            value=self.cache[group]
            if value is None:raise LayoutUnavailable('Source layout unavailable')
            return value
        self.cache[group]=None;result={}
        for row in self.profiles.get(group,[]):
            key,data,mask,(anchor_size,anchor_offset)=self._pattern(row);anchor=data[anchor_offset:anchor_offset+anchor_size];hits=[]
            for rva,span,offset,length,flags in self.sections:
                if not flags&0x20000000:continue
                raw=self.data[offset:offset+length];at=0
                while True:
                    found=raw.find(anchor,at)
                    if found<0:break
                    at=found+1;p=found-anchor_offset
                    if p>=0 and p+len(data)<=len(raw)and all(not m or raw[p+i]==data[i]for i,m in enumerate(mask)):
                        hits.append(rva+p)
                        if len(hits)>1:raise LayoutUnavailable('Source layout is ambiguous')
            if len(hits)!=1 or key in result:raise LayoutUnavailable('Source layout unavailable')
            result[key]=(hits[0],data,mask)
        if not result:raise LayoutUnavailable('Source layout unavailable')
        self.cache[group]=result;return result
    def verify(self,group,read,base):
        values=self.resolve(group)
        for rva,data,mask in values.values():
            actual=read(base+rva,len(data))
            if len(actual)!=len(data)or any(m and actual[i]!=data[i]for i,m in enumerate(mask)):raise LayoutUnavailable('Live module differs from resolved source')
        if group=='knowledge':
            for key,caller,offset,raw,mask in self.profiles.get('knowledge_links',[]):
                if caller not in values or type(offset)is not int or not 0<=offset<=len(values[caller][1])-5:raise LayoutUnavailable('Invalid source call binding')
                at=values[caller][0]+offset;call=read(base+at,5)
                if len(call)!=5 or call[0]!=0xE8:raise LayoutUnavailable('Source call unavailable')
                target=at+5+struct.unpack_from('<i',call,1)[0];data=bytes.fromhex(raw);mask=bytes.fromhex(mask)
                if not 1<=len(data)<=128 or len(mask)!=len(data)or not self.executable(target,len(data)):raise LayoutUnavailable('Source call target unavailable')
                actual=read(base+target,len(data))
                if len(actual)!=len(data)or any(m and actual[i]!=data[i]for i,m in enumerate(mask)):raise LayoutUnavailable('Source call layout differs')
        return values
    def controller(self,read,base):
        rva=self.verify('knowledge',read,base)['controller'][0];actual=read(base+rva,7)
        if len(actual)!=7 or actual[:3]!=b'\x48\x8d\x05':raise LayoutUnavailable('Controller type instruction unavailable')
        table=rva+7+struct.unpack_from('<i',actual,3)[0]
        if table%8 or not any(flags&0x40000000 and not flags&0x20000000 and start<=table and table-start<=length and 64<=length-(table-start)for start,span,offset,length,flags in self.sections):raise LayoutUnavailable('Controller type table unavailable')
        raw=self.read(table,64);targets=struct.unpack('<8Q',raw)
        if any(v<self.preferred_base or not self.executable(v-self.preferred_base)for v in targets):raise LayoutUnavailable('Controller type methods unavailable')
        expected=tuple(base+v-self.preferred_base for v in targets)
        actual=read(base+table,64)
        if len(actual)!=64 or struct.unpack('<8Q',actual)!=expected:raise LayoutUnavailable('Controller type identity changed')
        return table
    def _field(self,values,key,offset,read,base):
        if key not in values or not 0<=offset<=len(values[key][1])-4:raise LayoutUnavailable('Source field witness unavailable')
        rva=values[key][0]+offset;expected=self.read(rva,4);actual=read(base+rva,4)
        if len(actual)!=4 or actual!=expected:raise LayoutUnavailable('Live source field differs')
        return struct.unpack('<I',expected)[0]
    def appearance_layout(self,read,base):
        """Derive fields from the native profile lookup and its actual UI caller."""
        values=self.verify('appearance',read,base)
        stride=self._field(values,'a0',17,read,base);slots=self._field(values,'a0',23,read,base)
        active=self._field(values,'a0',47,read,base);profile=self._field(values,'a1',2,read,base)
        value=self._field(values,'a2',12,read,base)
        if not (16<=stride<=4096 and stride%8==0 and 0<slots<=1024*1024 and slots%8==0 and active==stride-16 and 0<value<active and 0<profile<=4*1024*1024 and profile%4==0):raise LayoutUnavailable('Unsupported appearance field geometry')
        caller=values['a2'][0];call=read(base+caller,5)
        if caller!=values['a1'][0]+29 or len(call)!=5 or call[0]!=0xe8 or caller+5+struct.unpack_from('<i',call,1)[0]!=values['a0'][0]:raise LayoutUnavailable('Appearance lookup caller differs')
        # This instruction remains fixed in a1: mov rcx,[rbx+0x5a8].
        return dict(manager=1448,profile=profile,slots=slots,stride=stride,active=active,value=value)
    def knowledge_layout(self,read,base):
        table=self.controller(read,base);values=self.resolve('knowledge')
        published=self._field(values,'controller',67,read,base);accessed=self._field(values,'controller',78,read,base)
        if published!=accessed or not 0<published<=4*1024*1024 or published%8:raise LayoutUnavailable('Controller publication field differs')
        return table,published
