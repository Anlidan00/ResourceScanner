#pragma once
#include <rs/game/frame.hpp>
namespace rs::game {
Frame sample(void*,std::uint64_t now_ms) noexcept;
bool start_adapter() noexcept;
void stop_adapter() noexcept;
Frame capture_from_commit(const MemoryReader&,std::uintptr_t commit_root,
                          std::uintptr_t backend_builder,std::uintptr_t map_state,
                          std::uintptr_t ui_context_frame,
                          std::uint64_t now_ms,std::uint32_t state_bytes=0x260,std::uint64_t state_key=0x236F8649B9BF0F5BULL) noexcept;
}
