#include "internal.hpp"
#include <rs/platform/paths.hpp>
#include <mutex>
#include <fstream>
#include <string>
#include <nlohmann/json.hpp>
namespace rs::platform {
namespace { HMODULE module{}; std::mutex log_mutex; }
namespace detail { void set_module(HMODULE value) noexcept { module=value; } }
std::filesystem::path module_directory() noexcept {
    try { wchar_t value[32768]{}; const auto n=GetModuleFileNameW(module,value,32768);
        if (!n || n>=32768) return {}; return std::filesystem::path(value).parent_path();
    } catch (...) { return {}; }
}
std::filesystem::path data_directory() noexcept {
    return module_directory();
}
void log(std::string_view phase,std::string_view message) noexcept {
    try { auto root=data_directory(); if(root.empty()||!root.is_absolute())return;
        std::lock_guard lock(log_mutex);
        // Directory is part of the installation; do not create arbitrary fallback paths.
        std::ofstream out(root/L"native.log",std::ios::app|std::ios::binary);
        if(out)out<<nlohmann::json{{"app","resource-scanner"},{"version","5.0.9"},
            {"pid",GetCurrentProcessId()},{"tick",GetTickCount64()},
            {"phase",phase},{"message",message}}.dump()<<'\n';
    } catch (...) {}
}
}
