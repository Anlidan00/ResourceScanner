"""Read, validate and reuse the published payload without running its installer."""
from pathlib import Path
import argparse,hashlib,io,json,struct,subprocess,zipfile

ROOT=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def resources(raw):
    nt=struct.unpack_from('<I',raw,60)[0]
    if raw[:2]!=b'MZ' or raw[nt:nt+4]!=b'PE\0\0':raise ValueError('Not a PE file')
    count=struct.unpack_from('<H',raw,nt+6)[0];opt=nt+24
    if struct.unpack_from('<H',raw,opt)[0]!=0x20b:raise ValueError('Expected PE32+ installer')
    table=opt+struct.unpack_from('<H',raw,nt+20)[0]
    def offset(rva):
        for i in range(count):
            length,start,disk_size,disk=struct.unpack_from('<IIII',raw,table+40*i+8)
            if start<=rva<start+max(length,disk_size):return disk+rva-start
        raise ValueError('RVA is not backed by a section')
    cli_rva=struct.unpack_from('<I',raw,opt+112+14*8)[0]
    rrva,rsize=struct.unpack_from('<II',raw,offset(cli_rva)+24)
    block=raw[offset(rrva):offset(rrva)+rsize];pos=0;values=[]
    while pos+4<=len(block):
        length=struct.unpack_from('<I',block,pos)[0];pos+=4
        if not length or pos+length>len(block):raise ValueError('Invalid managed resource')
        values.append(block[pos:pos+length]);pos=(pos+length+7)&~7
        if len(values)>16:raise ValueError('Unexpected resource count')
    return values

def main():
    parser=argparse.ArgumentParser();parser.add_argument('published_installer',type=Path);parser.add_argument('--output',type=Path,default=ROOT/'build/installer/ResourceScannerSetup.review.exe');args=parser.parse_args()
    raw=args.published_installer.read_bytes()
    expected=json.loads((ROOT/'release/artifact_hashes.json').read_text())['Resource_Scanner_Setup_5.0.9.exe']['sha256']
    if sha(raw)!=expected:raise ValueError('Input is not the published 5.0.9 installer')
    candidates=resources(raw)
    packages=[b for b in candidates if b.startswith(b'PK\x03\x04')]
    translations=[b for b in candidates if sha(b)==sha((ROOT/'installer/strings.json').read_bytes())]
    if len(packages)!=1 or len(translations)!=1:raise ValueError('Expected package and translation resources')
    package=packages[0]
    manifest=json.loads((ROOT/'release/payload_manifest.json').read_text())
    with zipfile.ZipFile(io.BytesIO(package)) as z:
        if set(z.namelist())!={'package.json',*(x['path'] for x in manifest['files'])}:raise ValueError('Unexpected payload members')
        for row in manifest['files']:
            if sha(z.read(row['path']))!=row['sha256']:raise ValueError('Payload hash mismatch: '+row['path'])
    stage=args.output.resolve().parent;stage.mkdir(parents=True,exist_ok=True)
    package_path=stage/'package.zip';package_path.write_bytes(package)
    strings_path=stage/'strings.json';strings_path.write_bytes(translations[0])
    compiler=Path('C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe')
    command=[str(compiler),'/nologo','/optimize+','/target:winexe','/platform:x64','/main:ResourceScanner.Setup.Program','/out:'+str(args.output.resolve()),'/resource:'+str(package_path)+',ResourceScanner.Package.zip','/resource:'+str(strings_path)+',ResourceScanner.Translations.json']
    command+=['/reference:'+name for name in ['System.Web.Extensions.dll','System.Windows.Forms.dll','System.Drawing.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll']]
    command+=[str(ROOT/'installer'/name) for name in ['InstallCore.cs','SetupUi.cs']]
    subprocess.run(command,check=True)
    print('PASS: validated',len(manifest['files']),'published payload files; rebuilt installer from supplied C# source')
    print(args.output.resolve())

if __name__=='__main__':main()
